# Archival identifiers — NOT for the anonymous submission

These resolve to a repository carrying the author's name. They are disclosed on acceptance and are
excluded from the supplementary archive by `scripts/build_supplementary.py`.

| identifier | value |
|---|---|
| snapshot | `swh:1:ANONYMISED` |
| revision, `main` at archival | `swh:1:ANONYMISED` |
| release, `v1.0.0` | `swh:1:ANONYMISED` |
| visit date, third-party stamped | 2026-08-21T13:24:43Z, `visit_status: full` |
| save request | id 2445469, `save_task_status: succeeded` |

Verified: `swh:1:rel:9d64c275…` targets revision `5e6b20dc8ffaf0e201d102a8e338a9fd28c162fe`, which
is exactly the local `v1.0.0` commit.

For the camera-ready, cite the **release** identifier — it pins the tagged state rather than
whatever `main` happened to be at crawl time.
