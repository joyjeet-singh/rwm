<!-- GENERATED FILE — do not edit. Edit docs/BUILD_CHECKS.template.md and run:
     python scripts/build_paper.py -->

# Build checks — the registry, the self-test, and what it caught in itself

Supplementary to the paper's §8. It carries the build's accounting, the paper's record of
verifying its own claims, and the machinery behind both.

Moved here in the revision that cut the paper from 44 pages, on the grounds that a reader
deciding whether to trust the numbers needs the failure modes and the exclusions, and a reader
wanting to run or extend the checks needs what is below. Nothing was deleted. The referee
revision moved the rest: section 8's reproducibility block and all of the paper's former Appendix C are
the first two sections below, and nothing was deleted from them either.

This file is GENERATED from `docs/BUILD_CHECKS.template.md` by `scripts/build_paper.py`,
from the same `results/paper_numbers.json` the paper is built from. A figure quoted here
therefore cannot disagree with the one the paper prints, and the `kind-count` check reads
the enumeration below to assert exactly that.

---

## Reproducibility, and a build that checks its own prose

*Moved from §8 of the paper in the referee revision. The text is as it stood there; only headings
and cross-references that now point the other way were changed.*

**The number of regenerated values that differ and are themselves a measurement, a statistic or
the verdict of a test is 7.**
`./reproduce.sh --quick --force` regenerates 60 artifact files and 18,327
numeric values from a clean clone: 18,315 bitwise identical (99.93%),
0 equal to within the verifier's floating-point tolerance but not bitwise, and
12 differing. Those
three account for the 18,327 exactly. Regeneration does not reproduce 1 of the committed values, in
1 of the files; that count is kept separate, because a value that is not
produced twice cannot be compared twice.
The 12 differing values are partitioned by cause from the per-file record in
`results/verify_reproduction.json`: 0 are in the document-line index
(`results/restatement_index.json`), 0 in the stochastic dilution study
(`results/e5_sigma_dilution.json`), and 12 elsewhere. The document-line index records where each
numeral sits in this paper's source and what it renders to. A clone checks out the same source, so
every position reproduces; the only values it can disagree on are this paper's own statements about
this comparison, which is why the committed index is regenerated whenever those figures are restated. Whether a differing value carries
a scientific result is decided value by value, not file by file: it does only if the value is
itself a measurement, a statistic or the verdict of a test, and a value does not qualify merely
because the file holding it also holds results. `scripts/paper_numbers.py` applies that rule in
code, counts any differing value it does not recognise as scientific, and places these outside the
scientific class: 1 in `results/pdf_channels.json` (the amount of PDF text the anonymity scan read); 1 in `results/pdf_channels.json` (the page count of this document's PDF); 1 in `results/supplementary_manifest.json` (how many commits the archive's anonymised git log carries); 1 in `results/supplementary_manifest.json` (the supplementary archive's own size and file count `bytes`); 1 in `results/supplementary_manifest.json` (the supplementary archive's own size and file count `uncompressed`). **`part_f_gate` still fails.** Its clean-clone check requires
that no regenerated value differ; 12 do, and it is published as failing, with no
tolerance added.
**The claim is narrower than the percentage makes it sound, and we would rather state its size than
have a reader derive it.** A clean clone already contains every committed artifact, so the only
honest test is the subset the run actually rewrites: 18,327 values, or 0.68% of the 2,694,975 numeric values under `results/` that the comparison counts. The other 2,676,648 are carried in, prove
nothing about reproduction, and are never folded into the figure; counting them would overstate the result by about 147-fold. **What "every numeral" means is itself checked.** A paper cannot substitute a section number or an arXiv identifier, so the claim is partitioned: every *measurement* is substituted, and each of the 735 numerals that is not one is classified as an address, a horizon label or a declared constant — 19 classes and 23 declared exceptions, with the build failing on anything left over (`results/typed_numerals.json`). That audit exists because the abstract used to claim no number here was typed, which was false; the count was printed on every build and asserted by nothing. Verifying that every numeral came from an artifact says nothing about the sentence built around it, and defects of exactly that kind sit downstream of correct numerals. The build therefore also verifies **68 comparative claims** across 35 kinds; all pass, and each is run against a deliberately corrupted expectation on every build and must fail, 68 of 68 caught. **The next section gives the failure modes those checks exist for and the two exclusions from the numeric comparison; the sections after it give the registry, the self-test and the four defects the self-test has found in the checker itself.**

---

## Verifying the paper's own claims

*Formerly the paper's Appendix C, moved here in the referee revision. The text is as it stood
there; only headings and cross-references that now point the other way were changed.*

**The nine claims withdrawn on evidence, in order.** In order: a premise about forecast decay that turned out not to exist in the code; a framing of the released checkpoint as "clearly informative" that rested on an n=10 estimate we ourselves showed to be biased low; an aggregation artifact that inverted a published-model comparison in our favour, withdrawn when the gating checks we had written refuted it; a per-dimension comparison that turned out to be unmatched; the claim that σ is input-independent "in all four models", made against a table holding three; the phrase "the released checkpoint's uncertainty output", singular, when the checkpoint emits two and we had measured the one the method discards; the size of the released evaluation's one-step action misalignment, measured on overlapping windows one of which carried most of the effect, withdrawn when intervals over independent trajectories made it small and its sign reversed across the ten episodes (S-20, reclassified by M-82 as withdrawn on evidence); the claim that our own checkpoints barely feel that misalignment, computed through a rollout that scored one trajectory's forecast against every trajectory's truth, withdrawn when the corrected measurement showed their error rising with the stale action at long horizons (S-21, withdrawn on evidence); and the reading that the calibration error is not heavy-tailed in any of 48 cells, which read only ±1σ coverage after rescaling and called its over-coverage over-dispersion, withdrawn when ±2σ coverage under the same rescaling showed the heavy-tail signature (S-22, withdrawn on evidence). **The eight framings withdrawn**, as stated claims rather
than as numbers, and generated from the ledger rather than listed here — a typed
enumeration beside a generated count is the same defect as a typed count. This one was typed
with two entries at a time when the ledger held
two, and the revision that added four more
replaced it with a generated list in the same commit, so it never actually stood wrong. It
appears here as a note rather than above as an entry for that reason, and the reason is luck:
nothing compared the typed enumeration against the count beside it, and had the two changes
landed in separate commits the paper would have said six and enumerated
two. All eight, generated:

- **Task 3's duplication rule was pre-registered** (`S-12`).

- **The binomial P-values attached to every dimension count** (`S-15`).

- **The two largest held-out deviations are in opposite directions** (`S-16`).

- **The eight untested claims are, without exception, about policy learning or hardware** (`S-17`).

- **The per-member σ is worse by three orders of magnitude** (`S-18`).

- **The released checkpoint cannot have come from the released recipe** (`S-19`).

- **The shared state trunk presented as something the follow-up does not state** (`S-23`).

- **The floor it closes onto freezes, and nothing can reopen it** (`S-24`).

The second pre-submission review entered four of them, in a
single commit — which is how that count is established rather than recalled.
`S-16`, `S-17` and `S-18`
are sentences of the 24 August draft that were false. `S-19` is different in kind and worse
in one respect: §7.5 had already narrowed that claim in the paper, and the narrowing was never
entered in the ledger, so the withdrawn version went on standing in the ledger's own
contributions summary and in the public README after the paper had withdrawn it. A
retraction that holds in one document and not in the repository is not a retraction, and
the `retraction-consistency` check now reads all five reader-facing files rather than
three. Each is an entry in `FINDINGS_LEDGER.md` with its evidence and its successor.

`build_paper.py` asserts that every printed number came from a named artifact. That is a
guarantee about *provenance*, and it is silent about *relations between* provenanced numbers.
Six failure modes survive it, and all six occurred in this paper. Five are relations between provenanced numbers; the sixth is not a relation at all and is set out after the list:

- **an interval relation that is not the one asserted** — "the intervals do not overlap",
  where at h=128 they overlap across 0.604–0.643. **This one has now been wrong twice.**
  The correction said the distinction mattered "at exactly one place"; adding h = 100 to
  the grid made it two, and the sentence recording the first error carried the second. A
  stated *frequency* — "at exactly one place", "in all four", "the only" — is a claim
  about a count, and no kind bound one to a recomputed count until `frequency-consistency`;
- **an extremum that is not the extremum** — the worst-calibrated held-out cell named as
  epistemic at h=1, which is third; the largest deviation is aleatoric at
  h=100. **This one has now been wrong twice as well**, and the second time was
  here rather than in §6.7. This sentence named h=128, which was the extremum before h = 100
  entered the evaluation grid; §6.7 was re-derived when the grid changed and the sentence
  describing the *correction* was not. Both now read the same key, and the `extremum` kind
  covers this record and not only the section that computes it;
- **a stated change with the wrong sign** — "a change of **+**0.010", where partialling the
  forecast index out *reduces* the correlation;
- **two prose descriptions of one ratio that disagree** — "nearly three orders of magnitude" in
  the abstract against "two orders" in §12, of the same 600× at
  h = 368;
- **a count attributed to the wrong evaluation arena** — 0 of 45 over all ten episodes asserted
  where the table beside it printed the held-out arena's 20 of 45.

None is a numeral. None appears in `results/paper_numbers.json`. Each was typed.

**A sixth failure mode is not a relation at all, and it defeated the gate rather than
evading it.** `build_paper.py` asserted that no `{{`-delimited placeholder survived
substitution, and none did — while a sentence of §6.6 reached the PDF as an empty
one-column table. The sentence contained `|r_dd|`, the line wrapped so that the pipe began a
line, and the Markdown-to-LaTeX converter read a leading pipe as a table row. Every numeral
in it was correct and provenanced. The gate now refuses three further shapes as well as
unresolved braces: a pipe-led line with no separator row beneath it, a single-braced token
that names a real key, and any key resolving to an empty or null value. The converter
requires the separator row before it will build a table.

**The machinery, and the two lines that matter about it.** `scripts/check_comparative_claims.py`
verifies 68 claims across 35 kinds, each pinning a fragment of this paper's text
and a relation recomputed from the artifacts, and each run against a deliberately corrupted
expectation on every build so that a check which can no longer fail is caught. The registry, the
self-test's mechanics and the four defects it has found in the checker itself
are in the sections below. **The evidence that any of it is
load-bearing is one sentence**: the comparative checks caught three defects in text written
during this revision — two calibration figures that named no horizon, and one numeral quoted
three ways in a single sentence — none of which a human reader had noticed.
**Two exclusions from the numeric comparison**, on the same principle in both cases: the number
measures the machine, not the model. A third category is not an exclusion but a partition, and it
bounds everything in this record: of the 2,694,975 numeric values under `results/` that the comparison counts, a clean clone regenerates 18,327 and carries in 2,676,648. The reproducibility claim covers 0.68% of that counted set and is silent about the rest. We state that fraction because a
reviewer who computes it and finds we did not will reasonably discount everything around it.

*The CPU budget.* `results/step4_5_timing.json` measures the machine, not the model: projected
runtimes for configurations we did not run, peak resident memory, and the standard deviation of
seconds-per-iteration across repeats. None of it can reproduce bitwise on another machine, or on
this one under different load, so the numeric comparison leaves the whole file out, together with
every field elsewhere whose name marks it as a wall-clock timing. The file also records its own
variability, and **we quote none of it**: a sentence arguing that host-dependent numbers should not
be printed as results cannot quietly print its own as though they were stable, and on a second host
the same run reported a different spread on a different worst configuration. For the same reason we
do not print how many values this exclusion sets aside. That count is not a property of the timing
file alone: it also takes in the values of the wall-clock-bounded diagnostic described below, and
the entries of `results/paper_numbers.json` that are read from either of those files or from the
comparison's own record, so it changes from one clean-clone run to the next with that diagnostic's
iteration count. Read `results/step4_5_timing.json` as one machine's account of itself, not as a
property of the code.

**One of the build's own gates fails, and we report it rather than retire it.** The clean-clone
check in `part_f_gate` requires that *no* regenerated value differ. 12 do, so the
check fails, and it is published as failing. We did not give it a tolerance. The differences sit in 4 artifacts, counted from the per-file record in
`results/verify_reproduction.json`: `results/input_set_audit.json` (5), `results/supplementary_manifest.json` (3), `results/pdf_channels.json` (2), `results/pipeline_coverage.json` (2). The stochastic dilution study differs in
0, and the number of differing values that are a measurement, a statistic or a
test verdict, under the rule the previous section states, is 7 — but a partition we believe is benign
is a reason to read the check's output, not to move its threshold. A gate that passes because its criterion was relaxed
tells a reader strictly less than one that fails and says where.

*One wall-clock-bounded diagnostic.* `results/step4_4_overfit_ens1.json` stops on a time budget rather than at its
iteration cap, so its iteration count and terminal losses are a property of the host and none of
them is quoted here; the section on exclusions below gives the mechanism and why
its sibling from the same script is not excluded.

---

## The check kinds and the self-test

**The check kinds.** `scripts/check_comparative_claims.py` verifies 68 claims across
35 kinds: *abstract-budget* (the abstract stays inside its word and numeral budget), *action-caveat* (a paragraph saying our models respond to the action also says that every action in the data comes from one policy), *action-response* (a paragraph quoting our arms' stale-pairing sensitivity also carries rule X2's figure for how they respond to the action), *alignment-arena* (a sentence naming the action-alignment defect and a short-horizon cost has the all-ten-episodes figures, or those words, in its paragraph), *arena_consistency* (every row of the evidence table (Appendix D's second) names an arena and an n_independent that the section owning that claim also states), *arithmetic* (a stated total equals the sum of its stated parts), *cell* (a k-of-45 count is the arena and horizon the text names), *compare* (a stated ordering between two scalars), *compute-claim* (no rendered file says a setting won even when its rival trained longer, and every front-matter sentence that names compute or longer training says the ranking depends on it or names the split), *config-unresolved* (no front-matter sentence naming the winning configurations pairs them with the verdict-level "one reading unresolved"), *count-consistency* (one count asserted in several places, in words, numerals or numeric-string variants, agrees everywhere), *count-dependence* (a clean k-of-k count carries an interval or a not-independent note), *cross-artifact-sync* (the README and model card carry the paper's headline values), *extremum* (a named cell is the max or min of its family), *figure_reference* (every in-text figure number names a figure that exists, and no more distinct figure numbers are cited than the document has figures), *frequency-consistency* (a frequency stated in words -- "at every horizon", "at exactly one place" -- matches a count recomputed from the artifacts), *horizon-consistency* (every horizon-indexed figure in the prose names its horizon, and names the one its artifact cell came from), *horizon-forbidden* (a withdrawn horizon label appears nowhere in the paper), *horizon-label* (a phrase naming a horizon resolves to the horizon the artifact says it is, and the numbers beside it are that horizon's), *interval-required* (a quoted ratio or coverage is accompanied by its interval), *kind-count* (the number of kinds the build accounting claims, this file enumerates and the checker registers are one number), *orders* (a stated count of orders of magnitude matches `round(log10(ratio))`, or a ratio quoted directly appears in the sentence that quotes it), *overlap* (two intervals do or do not overlap), *overstat-reversal* (no sentence says the released evaluation overstates its error beside an alignment figure unless its paragraph names the reversal of sign), *population_partition* (the run populations the paper quotes against one another partition -- the run table's row counts sum to the stated total, every row states the width it trained at, and the collapse family plus the runs excluded from it equal the total), *relvar* (a stated ratio of relative variabilities), *restatement* (no sentence restates a quantity another section owns -- no numeral is typed into the slot a substituted one fills elsewhere, and no section prints two different quantities as the same numeral), *retraction-consistency* (a claim the ledger marks superseded is asserted nowhere reader-facing), *retraction_class_consistency* (every retraction identifier a reader-facing file names resolves to exactly one class, and to the class the ledger gives it), *rule-seed-scope* (a sentence quoting the three-seed headline or its rule-horizon cells near the word rule or pre-register names the one seed the rule ran on, or the three-seed extension), *scope-consistency* (a universal quantifier is checked against the set it quantifies over), *sign* (a stated rise or fall matches the direction of the difference), *stale-interval* (a sentence printing our models' stale-timing change carries N5's interval for each figure, for the same arena and horizon), *table_renders* (every table in the source reaches the LaTeX as a table, with at least one row separator per source row), and *unit-consistency* (every n_independent figure names the evaluation unit it counts -- the revision introduced a second unit length, and 60 units of 33 rows and 4 of 400 are both "n_independent").

That list is generated from the checker's own registry rather than written here. It was
written here, and §8 quoted a generated count beside it; the two had drifted seven kinds
apart, inside the appendix whose subject is count consistency. The `kind-count` check now
asserts that the number the reproducibility section above claims, the number this list enumerates and the number the
checker registers at run time are one number.

Each entry pins two things and requires both: a **fragment of the paper's own text**, so that
rewording a sentence fails the check rather than silently detaching it from the claim it guards,
and a **relation recomputed from the artifacts**. A check that only re-asserts an artifact fact
guards nothing; a check that only matches text guards nothing either.

**The gates for a short paper.** Beside the registry, `scripts/round5_gates.py` runs six gates on the paper as
built, each with its own corrupt-and-catch self-test: `pages` (the main content, read from the compiled PDF, within
ruling Y1's limit), `abstract` (the abstract within ruling Y2's word and numeral budget, counted as the abstract
check above counts it), `ids` (no ledger or rule identifiers, commit labels, capitalised verdict labels or code names
used as labels in the main text, ruling Y3), `once` (each interval at most once in prose and once in tables and
captions, never in the abstract, and any other result at most twice), `sig` (no decimal printed to more than two
significant figures) and `keys` (no number in the record leaves the paper, the supplement and the ledger together
unless it is listed as retired, with its reason). They report rather than fail until the final review makes them
blocking. `scripts/supplement_selftest.py` plants a violation in `docs/SUPPLEMENT.md` for every check that reads it
and requires each to catch it, so text moved out of the PDF stays checked.

**The self-test.** Every assertion is run against a deliberately corrupted expectation on each
build and must fail: the interval relation inverted, the extremum replaced by the *runner-up*
rather than an absent label, the sign flipped, the order of magnitude and the dimension counts
moved by one. 68 of 68 are caught. An assertion that has quietly stopped
being able to fail is worth less than no assertion, because it reads as coverage.

**Four defects the self-test has found in the checker itself**, rather
than in the paper. Each surfaced because the checks were run rather than assumed, and the
last two are the ones a reader should weigh, because both are failures of *coverage* rather
than of arithmetic — an assertion that cannot fail, and a kind with no assertion attached,
both of which read as protection and are not:

- A fixed corruption per kind — `expect: "disjoint"` on every overlap check — which was a no-op for claims that already expected that value, so two of eleven assertions reported as missed when nothing had been corrupted.

- A label helper that prefixed a horizon to family keys already holding model names, producing `h=teacher-forced armB`, which matched nothing and failed two checks whose extrema were correct.

- An assertion that could not be corrupted at all: the `orders` check quoting a ratio directly rather than as an order of magnitude had no `stated_orders` to perturb, so the self-test skipped it and reported 31 of 31 caught beside a claim count of 32. The exemption was real, undocumented, and looked like coverage. A directly-quoted ratio is now asserted to appear in the sentence that quotes it, which is corruptible.

- A `sign` assertion that was never written. §6.8 said the two largest held-out deviations were "in opposite directions" when both are above target; the kind that would have caught it existed and no claim used it. A kind with no claim attached guards nothing, and the self-test cannot report that because there is nothing to corrupt.

Corruptions now invert relative to each claim's own expectation, every registered kind
carries at least one claim, and every claim is corrupted on every build: 68 of
68 caught against 68 claims, with no exemptions. This list is generated from
the checker rather than written here, so a fourth entry cannot be forgotten.

---

## The build gate: four refusals added for converter damage

`scripts/build_paper.py` already refused four shapes — an unresolved `{{`-delimited
placeholder, a pipe-led line with no separator row beneath it, a single-braced token naming a
real key, and a key resolving to an empty or null value. All four look at the resolved text or
at the brace syntax, and a further three classes of damage reached the compiled PDF past them,
with every placeholder resolved. Four more refusals were added, each with the instance that
motivated it:

- **a bare numeral opening a list under an unfinished equation** — section 6.2 wrapped as
  "at n_independent =" then "20." on its own line; the converter read the numeral as an
  ordered-list marker and ate it, so the PDF gave the sentence no sample size at all.
- **an ordered-list marker interrupting a paragraph** — the same damage in the ranking section (now 6.6), where
  "M-43's own" then "4." lost the horizon count. There is no equals sign to spot it by, so the
  rule is the general one: a marker opens a list only after a blank line, or where a numbered
  item is already open in the same block.
- **a Markdown footnote token surviving into the LaTeX** — `[^stepcount]` set as literal text
  in a table cell of the ranking section (now 6.6) and its definition as a literal paragraph, because the
  converter had no footnote rule. It now renders the reference as a superscript number and
  leaves the definition's wording untouched; `\footnote` is not usable at that site, which is
  inside a `tabular` inside a `\resizebox`.
- **a capitalised number-word substituted mid-sentence** — counts render through a capitalised
  word map for sentence-initial use, and dropping one into running prose produced "then named
  Five" in section 4 and "the Four defects it has found" in the former Appendix C (the claim-verification
  section above). The rule reads the
  substitution site rather than the output, so the fix has to be a lower-cased key and cannot
  be undone by the next build.

Each of the four is run against a deliberately corrupted input on every build and must fire,
on the same grounds as the self-test above: a refusal that has quietly stopped being able to
refuse reads as coverage and is not.

## Two refusals added in the pre-submission edit: a checkpoint on every figure that needs one

Both answer one defect, which reached a finished draft. §5 printed an h = 8 gap from one setting
(a single seed) beside a table from another (three seeds pooled), with no label on either, and
the two contradicted each other. Separately, no table said which training checkpoint its arms
were at, so §5's by-horizon table and the head-to-head accuracy table printed different numbers
for the same arm with nothing to say why. `scripts/build_paper.py` now refuses to build when:

- **an h = 8 gap figure in §5 is unlabelled.** Every §5 sentence that prints an h = 8 gap key
  either uses the table's own key, or names its checkpoint with a bound iteration or checkpoint
  key (`check_h8_gap_labels`);
- **a table with an arm row names no training iterations.** Every table with an Arm A, Arm B,
  ensemble or combined-arm row or column must carry a bound iteration or checkpoint key in the
  caption paragraph beside it, or an iterations column (`check_arm_table_captions`). Tables
  generated from a placeholder are expanded before the check, so none escapes. Tables of the
  originals' claims are not arm tables.

Both join the gate's self-test, and each is fed a corrupted input on every build and must fire.

---

## A third refusal: the ledger's withdrawals, counted one way

The introduction said there were thirteen "retractions of our own claims". Section 8 said "six
retractions on our own evidence ... plus seven that withdraw framings" out of twenty superseded
claims. Both were true, both were generated from the ledger, and they counted the same entries in
two vocabularies, so a reader comparing them could not tell whether the paper had retracted six
claims or thirteen.

There is now one vocabulary and one source:
- **claims withdrawn on evidence** (9);
- **framings withdrawn** (8);
- **superseded entries** (24), which also include the early hypotheses closed as
  housekeeping.

`scripts/ledger_check.py` classifies every S- entry into exactly one class and refuses to pass if
any entry fits none. `scripts/paper_numbers.py` reads the three counts from its output
(`results/claims_to_evidence.json`) rather than classifying again, and refuses a stale output.

`scripts/build_paper.py` now refuses to build when **the introduction and section 8 do not each
state all three counts, each phrase directly after the key that counts it, or when either prints
the old combined total** (`check_retraction_counts`). It joins the gate's self-test with a
corrupted introduction.

---

## Exclusions from the numeric comparison: the mechanism

*One wall-clock-bounded diagnostic.* `results/step4_4_overfit_ens1.json` stops after 2,700 seconds
rather than at its 2,000-iteration cap, so it reaches a different iteration count on
every machine — three different values across the three hosts we have run it on. Its iteration
count and terminal losses are therefore a property of the host, and we do not quote any of them
here: a number the build declares host-dependent has no business being printed as a result. **Its
sibling from the same script is not excluded**: that run reaches its cap, and reproduces bitwise.
Excluding by filename rather than by stopping rule would have dropped the reproducible one along
with it, so the verifier decides from the artifact — a run that stopped short of its own cap was
time-bounded.

**Excluding a file is not sufficient on its own.** `results/paper_numbers.json` records the
*source* of every value it holds, and it had copied that diagnostic's iteration count into a key
of its own — so the host-dependence leaked through a file that was not excluded, and the clean
clone duly differed on it. The verifier now drops any key whose recorded source is an excluded
artifact (35 of them), which follows the provenance the file already carries rather
than requiring anyone to remember.

**One further class, excluded by the same mechanism and worth naming because it sounds like an
excuse.** 28 keys in `paper_numbers.json` are sourced from
`verify_reproduction.json` — that is, they are this paper's statements *about this very
comparison*: how many files it regenerated, how many values matched, how many differed. A clean
clone necessarily carries in the **previous** run's figures and is then compared against a tree
holding the **current** run's, so they cannot agree: writing a result into the tree changes the
thing the next run measures. There is no fixed point to converge to, and treating it as a
reproducibility failure would make the reported figure oscillate rather than settle. They are
dropped by provenance like the others and counted in the output rather than hidden — the same
discipline the 60-file figure in the reproducibility section above rests on, since a silent exclusion is exactly how an
earlier version of this claim was inflated fiftyfold.

---

## What the checks caught in this revision's own text

Three defects, in text written during the revision itself and caught before it shipped:

- **two `horizon-consistency` failures** — a calibration figure in the rewritten abstract and
  another in a new section 6.2 paragraph, each quoted without the horizon it was measured at.
  This is the defect class the paper's own section 3.1 exists to prevent, and it recurred twice in one
  session of writing.
- **one `restatement` failure** — a new paragraph quoted a 15-point threshold, a 15.0% median
  and a 15% share in a single sentence, leaving the bare numeral ambiguous.

They are recorded as a count in the claim-verification section above rather than enumerated
there, because the count is the argument and the enumeration is this page.

---

## The negative lead-time bar, and the timezone it used to depend on

Moved verbatim from section 8, which keeps one sentence and this pointer.

The log records wall clock with no date and no offset, so both are taken from the commit that introduced that line — which makes the figure reproducible outside this machine's timezone, and it was not: the same arithmetic gave a different answer in every timezone until the offset stopped coming from the reader's clock.

---

## The glob collision, and the sweep of every pattern-based input discovery

Moved verbatim from Appendix B, which keeps one sentence and this pointer.

it did neither until the first
capacity-matched run walked into the family through a glob. **That fix reached
`paper_numbers.py` and `paper_figures.py` and not every script**: a second unguarded glob
survived in the ensemble-5 comparison until this revision found it, moving two published
values (`M-66`). A sweep of the pattern-based input discoveries in `scripts/` and `src/`
classifies each as an open population or frozen at write time. It found 1
frozen, the ensemble-5 glob, since replaced by an explicit seed list and retired from the sweep;
of the 31 discoveries in the code now, 0 are frozen. Artifacts that
discover their inputs now record the file list they were computed over.

*Round 2, T8: from "A sweep" to "frozen." this is no longer verbatim. It read "A sweep of all
N … M was frozen", filled from the audit's live counts, so once the audit began retiring fixed
discoveries (`results/input_set_audit.json`, `retired`) it read as if the sweep had found none.*

---

## Section numbers before round 2 (ruling U6)

Round 2 merged three subsections of §6 and renumbered it; §1–§5 and §7 onward are unchanged. The ledger, the rule texts in `docs/APPENDIX_G_RULES.md` and every document written before round 2 use the old numbers. Old → new: §6.5 → §6.3 (folded in), §6.6 → §6.5, §6.7 → §6.6, §6.8 → §6.7, §6.9 → §6.5 (folded in), §6.10 → §6.8, §6.11 → §6.8 (merged; the detail of both rules is in Appendices O and P).

## Moved from the paper body (pre-submission edit)

The pre-submission edit cut the paper body by moving its drafting history here rather than
deleting it: what an earlier draft said, how a check came to exist, and what a sweep found. Each
item is labelled with the section it left. Nothing below is a claim the paper no longer makes; the
claims stayed, and only their history moved.

- **[§3.1]** Every `file:line` citation in §3.1 is read back and checked against its own source
  text on every build (20 of them).
- **[§3.1]** The section exists because two metrics in this project once disagreed in *direction*
  at h = 1, and because a choice between two aggregations of the same metric once inverted a
  comparison against the released model (Appendix G).
- **[§3.1]** Three properties of the coverage statistic — pooled over all three axes, cumulative
  over steps 1..h, and two-sided — were missing from the prose until the referee revision.
- **[§3.1]** Earlier drafts called h = 368 a "deployment horizon". It is the upstream's
  open-loop diagnostic length, and the label is withdrawn.
- **[§4]** Both counts and both lists of untested claims are generated from a classification tag
  carried in Appendix D's verdict column, so the enumeration cannot disagree with the count beside
  it. It did once: an earlier draft of that sentence, itself the replacement for the withdrawn
  framing `S-17` (a count defect in the same place), said six and then named
  five, and called all of them claims about policy learning or hardware when one
  of them is not. The framing `S-17` withdrew a universal quantifier; its replacement got the arithmetic wrong
  instead, the worse failure of the two because the sentence had just been rewritten under
  scrutiny.
- **[§4]** The generated counts and lists replace the withdrawn framing `S-17`, that every untested claim
  concerns policy learning or hardware.
- **[§5]** That the rule M-23 is anchored at the diagnostic horizon rather than the deployment one
  is recorded in the ledger as `M-46`; nothing in §5's by-horizon table discharges or re-opens M-23.
- **[§5]** The hold-last floor's win at one step is stated in §5 because an earlier §5 quoted the
  h = 368 margin over the floor with no indication that it does not hold everywhere.
- **[§5]** M-23 is anchored at h = 368, where the claim is actually about, because M-16,
  anchored at the training horizon, returned "cannot be settled". That change of anchor was made
  before the runs, not after them (§8).
- **[§7.2]** An earlier version of §7.2 printed our models' stale-pairing figures computed with a scoring bug; they are withdrawn, and the record keeps them.
- **[§8]** §8 said: "One of the build's own gates, the clean-clone check in `part_f_gate`, requires that no regenerated value differ at all; 12 do, so it fails, and it is published as failing rather than given a tolerance. The accounting behind these figures, the registry of checks the build runs on this paper's own prose, and the paper's record of verifying its own claims are in `docs/BUILD_CHECKS.md`, shipped as supplementary."
- **[§6.2]** The epistemic ratio at h = 368 (34.4×) barely differs
  from the one at h = 100 (33.4×). That is why re-anchoring the
  paper's calibration claims from the diagnostic horizon to the deployment one changed the reading
  and not the conclusion.
- **[§6.2]** An earlier draft stated that the one-step row is measured on data the checkpoint
  trained on, and declined to draw the inference that the figure is therefore an upper bound on its
  calibration. The paper now draws it.
- **[§6.2]** An earlier draft said rule M-63's finding, that no state dimension is exempt from the
  one-step coverage failure, "is what §6.3's mechanism predicts: an objective whose optimum is σ = 0
  has no reason to spare any dimension". M-63 decomposes the epistemic term's coverage, and §6.3
  explains only the aleatoric head, so the clause is withdrawn (round 2, T6 review).
- **[§6.2]** At n_independent = 4 the short-horizon epistemic ordering looked like chance,
  and an earlier draft told a more interesting-sounding horizon story from it. At
  n_independent = 20 that result proved an artifact of four trajectories, and it is
  recorded as one.
- **[§6.3]** That the collapse would happen on any dataset was, until the synthetic experiment,
  only asserted from the derivation; the experiment was run to test it.
- **[§6.4]** Every source citation behind §6.4's topology argument is read back from the pinned
  upstream and checked on every build (21 of them, `results/v1_ensemble_topology.json`).
- **[§6.5]** The teacher-forced arm was trained for §5 but was missing from the first three
  calibration tables of earlier drafts; §6.5 adds it.
- **[§6.5]** The epistemic horizon story an earlier draft told, strongest at long horizon, was
  backwards: it rested on the smallest arena. When h = 100 was added to the evaluation
  grid, its permutation P fell between the neighbouring horizons' values, where the existing reading
  said it should, which was not guaranteed in advance.
- **[§6.5]** The section's claim is narrower than the one first written: the ordering is
  directionally consistent but not established at conventional significance once the dependence
  between dimensions is respected.
- **[§6.6]** An earlier draft described the within-step control as "the decisive one". It is a mean
  of between-trajectory correlations, not a within-rollout test, and that description is withdrawn;
  the double-demeaned statistic is the decisive one.
- **[§6.6]** §9 once called the one-step figure a ranking of realised error without qualification;
  it now says it ranks whole rollouts at one step ahead.
- **[§6.6]** Per-episode difficulty, the covariate Appendix N partials out at one forecast step, was once the mean
  of the released checkpoint's per-episode error at the released evaluation's action timing and at the causal one, because the script that
  built it took the two timings for two seeds; that mean spans 0.562 to 1.591. It is now the
  causal timing alone (ledger D-39); no verdict and no sign changed.
- **[§6.6]** The released checkpoint's six-horizon count and the ensemble-5 rule's five-horizon
  count are kept in separate keys, so the build cannot print one where the other belongs.
- **[§6.8]** An earlier draft gave the range of the σ gain as its values at the two shortest
  horizons, which do not span it: the weakest gain lies at another horizon, below the stated floor.
  The horizon sweep found it, flagging the sentence for carrying two horizons' figures while naming
  two others.
- **[§7.2]** The 75% (nRMSE) and 9.5% (relative-L1) this paper reported before came
  from 10 overlapping windows sampled as the upstream samples them, one of which (starting at row
  8,375) carries most of the effect; they are withdrawn on evidence (S-20, reclassified by M-82).
- **[§7.4]** The duplication control was run only because the first version of the splice finding
  inferred the mechanism (content rather than count) without it.
- **[§8]** The duplication-control rule's lead time is dated from the commit that introduced the
  log line, because the log records wall clock with no date and no offset; that is what makes
  Figure 3 reproducible outside this machine's timezone. Before that change the figure used the
  local timestamp.
- **[§8]** `S-15` was named by position in §8 ("the second framing retraction") until the second
  pre-submission review entered four more framing retractions and moved it.
- **[Appendix B]** The runtime split was rounded to whole hours in an earlier draft, so its parts did
  not sum to the stated total; the `arithmetic` check now asserts that a stated total equals the sum
  of its stated parts. An earlier version of the appendix also gave a longest-run figure that
  predated the ten-thousand-iteration runs added for the three-seed headline.
- **[Appendix B]** `paper_numbers.py` selected the collapse family by filename until the first
  capacity-matched run walked into it through a glob; that collision and the second unguarded glob
  the fix did not reach are recorded above (`M-66`), with the sweep of every pattern-based
  input discovery in `scripts/` and `src/` that followed.
- **[Appendix D]** The epistemic ranking row read "weaker per-dimension than we first reported".
- **[Appendix E]** The table once omitted `M-52`: the selector matched entry titles, and M-52's
  title does not contain the word, so the row a sceptical reader most wants was silently absent.
- **[Appendix C]** The pricing table has one row per untested claim. Until the assertion that counts
  its rows against Appendix D's was written, it listed two fewer, and the two it omitted were the
  two whose cost was hardest to state honestly. Those two (the configuration sweep and the
  architecture baselines) have since been run (§5.2, §5.3).
- **[§2]** §2 closed with a note: every entry cited there and in §5.3 was checked against the paper
  itself, title, full author list and year from the arXiv record, venue from the record or, where it
  names none, from the paper's own first page, and every sentence attributed matched verbatim against
  the paper's text; 33 of 33 entries and 19 of 19
  fragments, 3 of them single common words. The References note now says the same once.
- **[Data and code]** The anonymity paragraph said that a reviewer who chooses to look can identify the author, and argued that making the repository private would remove the identifying link and also the checkability §8 depends on, the worse trade. Ruling V7 (round 3) cut it to two sentences; the reasoning is in `docs/DOUBLE_BLIND_DECISION.md`.
- **[References]** The bibliography is generated from `results/t1_bibliography_verified.json` rather
  than listed by hand because a hand-maintained list of what a paper cites drifts exactly as a
  hand-typed count does, and this one had: six entries cited in §2's prose appeared in no reference
  entry while the note claimed all of them verified.

- **[Appendices, framing moved by G9 item 13]** **What §6.3 and §6.4 keep, and what is here.** §6.3 keeps its derivation, the synthetic-noise verdict and the objective's two effects; §6.4 keeps the 89.15% sharing in its parameter counts and the mechanism. The passages below stood there as follows; the first two summarise sections of this appendix that state them in full.
- **[Appendices, framing moved by G9 item 13]** **What §6.5 keeps, and what is here.** §6.5 keeps the teacher-forced arm's finding, the epistemic term's, its claim and the structural-excuse result. Its two tables and the paragraphs around them stood there as follows.
- **[Appendices, framing moved by G9 item 13]** **What §6.2 keeps, and what is here.** §6.2 keeps its released-checkpoint table's h = 1 and h = 100 rows and two sentences on the ensemble-5 arms. The rest stood there as follows; §6.2's note on the permutation column read: "The last column of the released checkpoint's table gives permutation P-values over whole trajectories; none survives Holm–Bonferroni across the arena's 30 cells, so it is a consistency check on direction (Appendix M)."
- **[Appendices, framing moved by G9 item 13]** **What §6.6 keeps, and what is here.** §6.6 keeps the counter table, the paired test, the free-baselines verdict and rule X6, with every verdict. The passages below stood there as follows; rule M-43's is stated in full again later in this appendix.
- **[Appendices, framing moved by G9 item 13]** **What §6.7 keeps, and what is here.** §6.7 keeps the two senses of unseen, its verdicts, the cautions and rule X7. The passages below stood there as follows.
- **[Appendices, framing moved by G9 item 13]** **What §7.2 keeps, and what is here.** §7.2 keeps the defect, its cost to the released checkpoint in both metrics and arenas, the fix, and rule X2's verdict with its caveat. The passages below stood there as follows.
- **[Appendices, framing moved by G9 item 13]** **§6.8's table for rule M-44.** §6.8 keeps the verdict and the h = 100 figures; the table stood there as follows.
- **[Appendices, framing moved by G9 item 13]** **§6.8's table for rule M-68.** §6.8 keeps the verdict; the table stood there as follows.
- **[Appendices, framing moved by G9 item 13]** **The metrics' formulas (§3.1).** §3.1 states each metric in words. Its formulas, as implemented, and the check on the coverage nominal stood there as follows.
- **[Appendices, framing moved by G9 item 13]** **Three passages of §5 in full.** §5 keeps two sentences of each of the next three paragraphs, which stood there as follows.
- **[Appendices, framing moved by G9 item 13]** **Two passages of §5.3 in full.** §5.3 keeps a short summary of each, with every verdict; they stood there as follows.
