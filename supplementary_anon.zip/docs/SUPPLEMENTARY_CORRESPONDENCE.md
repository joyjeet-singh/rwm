# Supplementary — correspondence with the first author, 21 August 2026

**Status of consent.** This transcript is prepared for submission as supplementary material.
Explicit consent from the first author to quote this correspondence on the record is a human
action outside the build, and the paper states whether it was given. If this line still reads
CONSENT NOT YET RECORDED at submission, the quotations must be removed from the paper and
replaced with a statement that the authors were contacted, because a quotation from private
correspondence without permission is not ours to publish.

> **CONSENT NOT YET RECORDED.**

**Conflict of interest.** The authors of both papers under reproduction are aware that this work
exists, having been written to on 21 August 2026. None of them should be assigned to review it.
Declaring this to the Action Editor is a human action outside the build.

**Anonymisation.** The first author is referred to as "the first author" throughout; his name,
address and affiliation do not appear. Identifying details of the reproducing author are likewise
removed. Nothing else is altered: the quoted passages are verbatim, including their original
spelling and phrasing.

**What this file is for.** §6.1 and §8 of the paper each quote this exchange. A quotation from
private correspondence is the one class of evidence in that paper which a reviewer cannot check
against anything else, so the exchange is reproduced here in full rather than only where it is
convenient. Where a quotation is used in the paper, the section is named beside it.

---

The first author of both papers, written to on 21 August 2026 (E4), replied the same day. Recorded
here because it settles two open items, softens a third, and supplies one fact not obtainable from
the released artifacts. Quoted with the sender's words; permission to cite has been requested and
this entry will be updated with the outcome.

### 1. The aleatoric head is not used downstream — confirmed by the author
*Quoted in §6.1 of the paper. The figure number is the first author's and follows arXiv:2504.16680v1, where the MOPO-PPO training figure is Fig. 3; in the current v3 it is Fig. 4. See `results/original_paper_figures.json`.*

> "The aleatoric term is not used in downstream training. It is reported in Fig. 3 (right) as an
> analysis of the model behavior."

C-14 was established independently from the paper and the code. It is now confirmed by the person
who wrote both, and the intent is explicit: the head exists to shape training and to be reported,
not to be consumed. That removes any reading of C-14 as an implementation slip.

### 2. The standard deviation is the intended quantity; Eq. 4 is a simplification
*Quoted in §6.1 of the paper.*

> "The lambda is applied to the standard deviation in the implementation as intended, in contrast
> to Eq. 4 being more of a high-level explanation."

C-15 asked which of the two forms was meant. The answer is the code. Eq. 4 is a high-level
description rather than the operative definition, so this is a notational gap in the paper and not
an implementation error. C-15 is restated accordingly.

### 3. The iteration count, and the released repository
*Quoted in §8 of the paper.*

> "I could not really remember how I obtained the checkpoint. But I do think it is likely that it
> was trained for 5000 iterations as I always did. I believe the released config with
> max_iterations: 500 is a typo. Please forgive me that the checkpoint was released after a few
> iterations of the repo than the setup I used for the submission."

Three things follow, and only the first two are settled. The `500` is a **typo**, so C-13's
three-way disagreement is really a two-way one. The author's belief is **5,000**, consistent with
the checkpoint tag. And — the fact not otherwise obtainable — **the released repository is several
revisions removed from the setup that produced the checkpoint.**

That last point matters more than the first two. §6 extrapolates from *the released
initialisation* at *the configured learning rate*. If the training setup differed from the
released one, the initialisation and the learning rate the extrapolation assumes may not be the
ones used, and E5 already lists a different `log_delta_logstd` initialisation as the assumption it
cannot rule out. The author does not recall a warm start and does not rule one out either.

**What is NOT settled.** The arithmetic stands: at the released initialisation and learning rate,
the checkpoint's variance state is unreachable in 5,000 iterations. What the reply supplies is a
plausible and author-supplied mechanism for why the released artifacts would not reproduce it — a
drifted repository — rather than a confirmation that they should. §6 is narrowed again to say so,
and its framing moves from an inconsistency in the release to a documentation gap between the
release and the run.

---

## What the paper draws from this, and what it does not

**Settled by the correspondence.** That the aleatoric term is discarded by design rather than by
oversight (§6.1), and that the standard deviation in the code is the intended quantity while Eq. 4
is a high-level description (§6.1). Both were established independently from the code before the
exchange; the reply confirms the *intent*, which the code alone cannot show.

**Softened by the correspondence.** §8's extrapolation assumes the released initialisation and the
released learning rate. The first author's statement that the checkpoint was released some
repository revisions after the setup that trained it means those may not be the values that
produced it. That reframes §8 from an inconsistency in the release into a documentation gap
between a release and a run, which is what §8 now says.

**Not settled.** The arithmetic itself. At the released initialisation and learning rate the
checkpoint's variance state remains unreachable at any of the three stated iteration counts. The
reply supplies a plausible, author-supplied reason why the released artifacts would not reproduce
it; it does not supply a configuration that does.

**Evidence class.** `EXT`. Correspondence cannot substitute for a measurement and is not used as
one anywhere in the paper — every finding it bears on carries its own measured evidence
(C-13, C-14, C-15, O-12 in `FINDINGS_LEDGER.md`). It corroborates and explains; it does not
establish.
