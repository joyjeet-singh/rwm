"""Build PAPER.md from PAPER.template.md by substituting values read from artifacts.

The point of the indirection: no number in the paper is typed. Every {{key}} resolves
from results/paper_numbers.json, which scripts/paper_numbers.py derives from the run
artifacts. The build fails if any placeholder is unresolved, so a paper that mentions
a quantity we no longer measure cannot be produced.
"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "src"))
import rwm_data as R  # noqa: E402

TEMPLATE = "PAPER.template.md"
OUT = "PAPER.md"

# ---------------------------------------------------------------------------
# Session 2 gate rules. Three classes of Markdown-to-LaTeX damage reached the
# compiled PDF while every {{key}} resolved, so the brace gate saw nothing. Each
# rule below is a separate function so a deliberately corrupted input can be fed
# to it directly, the way check_comparative_claims.py corrupts its own
# expectations.
# ---------------------------------------------------------------------------

# The capitalised renderings scripts/paper_numbers.py substitutes from WORDS.
_NUMBER_WORDS = {"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight",
                 "Nine", "Ten", "Eleven", "Twelve", "Thirteen"}


def check_orphan_ordinal_after_equals(lines):
    """A bare "N." line right after a line ending in "=" or "~=".

    S6.2 wrapped as "... at n_independent =" / "20. **Both are correct", the
    converter read "20." as an ordered-list marker, and the 20 was eaten. The
    equals sign is the tell: nothing legitimate in this paper opens a list under
    a line that ends mid-equation.
    """
    bad = []
    for n, ln in enumerate(lines):
        if n == 0 or not re.match(r"^\d+\.(\s|$)", ln):
            continue
        prev = lines[n - 1].rstrip()
        if prev.endswith("=") or prev.endswith("≈"):
            bad.append(f"line {n + 1}: {prev[-48:]!r} then {ln[:48]!r}")
    return bad


def check_ordinal_interrupting_paragraph(lines):
    """A numbered marker that opens mid-paragraph rather than at a block boundary.

    The same damage as above with no equals sign to spot it: S6.7's "M-43's own"
    / "4. The released checkpoint's table" ate the 4. A marker is a list only if
    a blank line precedes it, or a numbered item is already open in the same
    blank-line-delimited block (a wrapped reference entry).
    """
    bad = []
    open_here = False
    for n, ln in enumerate(lines):
        if not ln.strip():
            open_here = False
            continue
        if not re.match(r"^\d+\.\s", ln):
            continue
        if n > 0 and lines[n - 1].strip() and not open_here:
            bad.append(f"line {n + 1}: {lines[n - 1][-48:]!r} then {ln[:48]!r}")
        open_here = True
    return bad


def check_footnote_tokens(tex):
    """A Markdown footnote token surviving into the LaTeX.

    "[^stepcount]" set as literal text in a table cell of S6.7, and its
    definition as a literal paragraph, because the converter had no footnote
    rule. esc() turns the caret into \\textasciicircum{}, so both spellings are
    checked.
    """
    pat = r"\[(?:\^|\\textasciicircum\{\})([A-Za-z0-9_-]+)\]"
    return sorted(set(re.findall(pat, tex)))


def check_number_word_case(template, values):
    """A capitalised number-word substituted mid-sentence.

    paper_numbers.py renders counts through WORDS, which is capitalised for
    sentence-initial use. Dropped into running prose it produced "then named
    Five" in S4 and "the Four defects it has found" in Appendix C, which read as
    proper nouns. The fix belongs at the substitution site -- a `_lower` key --
    so the next build cannot reintroduce it.
    """
    bad = []
    for m in re.finditer(r"\{\{([A-Za-z0-9_]+)\}\}", template):
        k = m.group(1)
        if k not in values or str(values[k]["value"]) not in _NUMBER_WORDS:
            continue
        pre = template[:m.start()].rstrip(" \t*_`>")
        if pre == "" or pre[-1] in "\n.!?:":
            continue
        line = template[:m.start()].count("\n") + 1
        bad.append(f"line {line}: {{{{{k}}}}} = {values[k]['value']!r} after {pre[-40:]!r}")
    return bad


# Pre-submission S3. Two refusals for a defect that reached a finished draft: §5 printed an
# h = 8 gap from one setting (one seed) beside a table from another (three seeds), with no
# label on either, and they contradicted each other; and no table said which training
# checkpoint its arms were at, so §5's 10,000-iteration table and the 2,500-iteration
# head-to-head table printed different numbers for the same arm with nothing to say why.
_CKPT_KEY = re.compile(r"\{\{[a-z0-9_]*(?:iters|ckpts?)[a-z0-9_]*\}\}")
_H8_GAP_KEY = re.compile(r"\{\{(?:m23_h8_[a-z]+|ab_short_[a-z]+|a1_(?:gap|gap_ci|excl)_h8)\}\}")
_ARM_CELL = re.compile(r"\b(Arm [AB]|faithful|corrected|teacher[- ]forced|autoregressive)\b", re.I)
_ARM_HEADER = re.compile(r"\b(autoregressive|teacher forcing|independent|shared-trunk|combined|"
                         r"ensemble)\b", re.I)


def check_h8_gap_labels(template):
    """Every §5 sentence that prints an h = 8 gap figure either uses the table's own key
    ({{a1_gap_h8}}) or names its checkpoint with a bound iteration or checkpoint key."""
    m = re.search(r"\n## 5\.(.*?)\n## 6\.", template, re.S)
    if not m:
        return ["§5 not found"]
    prose = " ".join(ln for ln in m.group(1).split("\n") if not ln.startswith("|"))
    bad = []
    for sent in re.split(r"(?<=[.!?])\s+(?=[A-Z*(])", prose):
        if _H8_GAP_KEY.search(sent) and "{{a1_gap_h8}}" not in sent and not _CKPT_KEY.search(sent):
            bad.append(sent.strip()[:110])
    return bad


def _paragraph(lines, i, step):
    """The paragraph adjacent to line i, walking in direction step past blank lines."""
    j = i + step
    while 0 <= j < len(lines) and lines[j].strip() == "":
        j += step
    out = []
    while 0 <= j < len(lines) and lines[j].strip() and not lines[j].startswith(("|", "#")):
        out.append(lines[j])
        j += step
    return " ".join(out)


def check_arm_table_captions(template, values):
    """Every table with an arm row, or arm columns, names its training iterations: a bound
    iteration or checkpoint key in the caption paragraph beside it (before or after), or an
    iterations column. Placeholder-generated tables are expanded first so none escapes;
    tables of the originals' claims are not arm tables."""
    lines = []
    for ln in template.split("\n"):
        k = re.fullmatch(r"\{\{([A-Za-z0-9_]+)\}\}", ln.strip())
        v = str(values.get(k.group(1), {}).get("value", "")) if k else ""
        lines += v.split("\n") if v.lstrip().startswith("|") else [ln]
    bad, i = [], 0
    while i < len(lines):
        if (lines[i].startswith("|") and i + 1 < len(lines) and lines[i + 1].startswith("|")
                and set(lines[i + 1].replace("|", "").strip()) <= set("-: ")):
            j = i + 2
            while j < len(lines) and lines[j].startswith("|"):
                j += 1
            header = lines[i]
            first_head = header.split("|")[1].strip().lower()
            firsts = [r.split("|")[1] for r in lines[i + 2:j] if r.count("|") > 1]
            arm = (_ARM_HEADER.search(header) or any(_ARM_CELL.search(c) for c in firsts))
            if (arm and not first_head.startswith("claim")
                    and not re.search(r"\biterations\b", header, re.I)
                    and not _CKPT_KEY.search(_paragraph(lines, i, -1))
                    and not _CKPT_KEY.search(_paragraph(lines, j - 1, +1))):
                bad.append(f"table at line {i + 1}: {header[:70]}")
            i = j
        else:
            i += 1
    return bad


# S5 (item 8): one vocabulary for the ledger's withdrawals, and the same count everywhere.
# The introduction said "13 retractions of our own claims" while section 8 said "six ... plus
# seven": both true, counted two ways. The three counts are ledger_check.py's classes, and
# each phrase must sit directly after its own key in both places.
_RETRACT_VOCAB = {"claims withdrawn on evidence": "n_retractions",
                  "framings withdrawn": "n_retract_framing",
                  "superseded entries": "n_superseded"}
_RETRACT_PH = re.compile(r"\{\{(n_[a-z_]+)\}\}\s+(" + "|".join(_RETRACT_VOCAB) + r")\b")


def _key_family(k):
    return re.sub(r"(_word_lower|_word_cap|_word|_lower|_cap)$", "", k)


def check_retraction_counts(template):
    """The introduction and section 8 each state all three withdrawal counts, each phrase
    directly after the key that counts it, and neither uses the old total."""
    secs = {"introduction": re.search(r"\n## 1\. (.*?)\n## 2\. ", template, re.S),
            "section 8": re.search(r"\n## 8\. (.*?)\n## 9\. ", template, re.S)}
    bad, found = [], {}
    for name, m in secs.items():
        if not m:
            bad.append(f"{name} not found")
            continue
        body = m.group(1)
        if "{{n_retract_total}}" in body:
            bad.append(f"{name} prints {{{{n_retract_total}}}}, a fourth way of counting")
        got = {}
        for km in _RETRACT_PH.finditer(body):
            got.setdefault(km.group(2), set()).add(_key_family(km.group(1)))
        for phrase, fam in _RETRACT_VOCAB.items():
            if phrase not in got:
                bad.append(f"{name} does not state {phrase!r} after its count")
            elif got[phrase] != {fam}:
                bad.append(f"{name} counts {phrase!r} with {sorted(got[phrase])}, not {fam}")
        found[name] = got
    return bad


def selftest_gates():
    """Run each gate rule against a deliberately corrupted input; each must fire.

    Same discipline as check_comparative_claims.py's corrupted expectations: a
    refusal that has quietly stopped being able to refuse reads as coverage and
    is not. Returns the number of rules that caught their corruption.
    """
    caught = 0
    caught += bool(check_orphan_ordinal_after_equals(
        ["cumulative to h = 100, at n_independent =", "20. **Both are correct**"]))
    caught += bool(check_ordinal_interrupting_paragraph(
        ["The verdict above is over M-43's own", "4. The released checkpoint's table"]))
    caught += bool(check_footnote_tokens(
        r"median +0.737[\textasciicircum{}stepcount] and [^stepcount]: adjacent steps"))
    caught += bool(check_number_word_case(
        "and then named {{n_word_probe}}, and", {"n_word_probe": {"value": "Five"}}))
    # S3: an unlabelled h = 8 gap in §5, and an arm table whose caption names no checkpoint.
    caught += bool(check_h8_gap_labels(
        "x\n## 5. T\nAt h = 8 the gap is {{m23_h8_gap}} and its interval {{m23_h8_excl}}.\n## 6. U"))
    caught += bool(check_arm_table_captions(
        "A caption naming nothing.\n\n| model | x |\n|---|---|\n| faithful Arm A | 1 |\n\nAfter.",
        {}))
    # S5: the introduction counts claims withdrawn on evidence with the old total.
    _v = ("{{n_superseded}} superseded entries, {{n_retractions_word}} claims withdrawn on "
          "evidence and {{n_retract_framing_word}} framings withdrawn")
    caught += bool(check_retraction_counts(
        "x\n## 1. I\n" + _v.replace("n_retractions_word", "n_retract_total") + "\n## 2. R\n"
        + "y\n## 8. M\n" + _v + "\n## 9. L\n"))
    return caught


N_GATE_RULES = 7


def main():
    N = json.load(open(os.path.join(R.RESULTS, "paper_numbers.json")))
    text = open(TEMPLATE).read()

    used, missing = set(), []

    def sub(m):
        k = m.group(1)
        if k not in N:
            missing.append(k)
            return m.group(0)
        used.add(k)
        return str(N[k]["value"])

    # {{FIGURES}} is a placement marker, not a value: it is substituted after the
    # numeric pass, so exclude it from both the missing and leftover checks.
    text_marked = text.replace("{{FIGURES}}", "\x00FIGURES\x00")
    out = re.sub(r"\{\{([A-Za-z0-9_]+)\}\}", sub, text_marked)
    out = out.replace("\x00FIGURES\x00", "{{FIGURES}}")

    assert not missing, ("placeholders with no value in paper_numbers.json: "
                         + ", ".join(sorted(set(missing))))
    leftover = [x for x in re.findall(r"\{\{[^}]*\}\}", out) if x != "{{FIGURES}}"]
    assert not leftover, f"unresolved placeholders remain: {sorted(set(leftover))}"

    # C3(rev2), 3.2 -- the gate widened past {{...}} syntax.
    #
    # §9 claims zero unresolved placeholders and the claim was true, yet a whole
    # sentence of §6.7 reached the PDF as a one-column table: "|r_dd| >= 0.183"
    # wrapped onto its own line, the converter read a leading pipe as a table
    # row, and the prose vanished into a booktabs box. Every placeholder had
    # resolved. The gate could not see it because it only ever looked at brace
    # syntax.
    #
    # Three further failure shapes, each of which reached a PDF at some point in
    # this project or would have:
    #   1. a stray table row -- a pipe-led line with no separator row under it;
    #   2. a placeholder written with one brace, {key}, which substitutes to
    #      nothing and reads as prose;
    #   3. an empty or literal-None value reaching the text.
    lines = out.split("\n")
    stray = []
    in_code = False
    for n, ln in enumerate(lines):
        if ln.strip().startswith("```"):
            in_code = not in_code
        if in_code or not ln.startswith("|"):
            continue
        # a row belongs to a table if it or an earlier contiguous pipe-line is
        # followed by the |---| separator
        j = n
        while j > 0 and lines[j - 1].startswith("|"):
            j -= 1
        sep = (j + 1 < len(lines) and lines[j + 1].startswith("|")
               and set(lines[j + 1].replace("|", "").strip()) <= set("-: "))
        if not sep:
            stray.append(f"line {n + 1}: {ln[:80]}")
    assert not stray, ("pipe-led lines that are not table rows -- these render as "
                       "one-column tables and swallow the sentence:\n  "
                       + "\n  ".join(stray[:5]))

    # Only a single-braced token that IS a known key is a mis-typed placeholder;
    # \mathrm{Var} and \mathrm{erf} are not, and matching brace shape alone
    # flags every one of them.
    single = [k for k in re.findall(r"(?<!\{)\{([A-Za-z][A-Za-z0-9_]{2,})\}(?!\})", out)
              if k in N]
    assert not single, f"single-brace placeholders that substituted nothing: {sorted(set(single))[:5]}"

    empties = sorted(k for k in used if str(N[k]["value"]).strip() in ("", "None", "nan", "[]"))
    assert not empties, f"placeholders that resolved to an empty or null value: {empties}"

    # Session 2. Three more failure shapes that reached the compiled PDF with
    # every placeholder resolved, plus the generalisation of the first that
    # catches the instance the equals-sign form misses.
    _orphan = check_orphan_ordinal_after_equals(lines)
    assert not _orphan, ("a bare numeral opens a list under an unfinished equation -- the "
                         "converter eats it as an \\item marker:\n  " + "\n  ".join(_orphan[:5]))
    _interrupt = check_ordinal_interrupting_paragraph(lines)
    assert not _interrupt, ("an ordered-list marker interrupts a paragraph -- the numeral is "
                            "eaten and the sentence loses it:\n  " + "\n  ".join(_interrupt[:5]))
    _wordcase = check_number_word_case(text, N)
    assert not _wordcase, ("a capitalised number-word substituted mid-sentence -- use the "
                           "matching _lower key:\n  " + "\n  ".join(_wordcase[:5]))
    _h8 = check_h8_gap_labels(text)
    assert not _h8, ("an h = 8 gap figure in §5 names neither the table's key nor its checkpoint "
                     "-- bind a checkpoint label (S3 item 1):\n  " + "\n  ".join(_h8[:5]))
    _cap = check_arm_table_captions(text, N)
    assert not _cap, ("a table with an arm row names no training iterations in its caption -- "
                      "bind one, e.g. {{iters_main}} (S3 item 2):\n  " + "\n  ".join(_cap[:8]))
    _rc = check_retraction_counts(text)
    assert not _rc, ("the introduction and section 8 must state the ledger's three withdrawal "
                     "counts in one vocabulary, from ledger_check.py (S5 item 8):\n  "
                     + "\n  ".join(_rc[:6]))
    _gate_caught = selftest_gates()
    assert _gate_caught == N_GATE_RULES, (
        f"gate self-test: only {_gate_caught} of {N_GATE_RULES} rules caught their corruption")

    unused = sorted(set(N) - used)

    # Typed-number check. The paper claims no number in it is typed by hand, and a
    # hand-typed retraction count ("Four claims...") once contradicted the derived
    # count in the same PDF. Everything numeric that is NOT a placeholder is listed
    # here every build, so a typed number has to be looked at rather than assumed
    # benign. Section numbers, arXiv ids and defined constants are expected.
    prose = re.sub(r"\{\{[A-Za-z0-9_]+\}\}", "", text)
    prose = re.sub(r"```.*?```", "", prose, flags=re.S)
    prose = re.sub(r"^ {4}.*$", "", prose, flags=re.M)
    prose = prose.split("## References")[0]
    WORDS = r"\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|" \
            r"thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)\b"
    typed_words = sorted({m.group(0).lower() for m in re.finditer(WORDS, prose, re.I)})
    typed_nums = sorted({m.group(1) for m in
                         re.finditer(r"(?<![\w.])(\d[\d,]*\.?\d*)(?![\w])", prose)},
                        key=lambda x: (len(x), x))

    figs = sorted(f for f in os.listdir(R.FIGURES) if f.startswith("paper_fig"))
    header = (
        "<!-- GENERATED FILE — do not edit.\n"
        "     Prose lives in PAPER.template.md; every number is substituted from\n"
        "     results/paper_numbers.json by scripts/build_paper.py. Edit the template,\n"
        "     then run: python scripts/build_paper.py\n"
        f"     {len(used)} values substituted from {len(set(N[k]['source'] for k in used))} artifacts. -->\n\n")
    # Captions. The body makes numbered references ("Figure 1", "Figure 3b"), so
    # the figures must actually carry numbers; without \caption LaTeX assigns
    # none and every one of those references dangles.
    # C3(rev2), 3.9. The caption had 68.3 typed into it while 3.1 derives 68.27,
    # so the figure's own caption disagreed with the section that defines the
    # constant. It comes from the same key the prose uses.
    NOMINAL1 = str(N["v3_cov_nominal1"]["value"])
    # Same reason, Session 3. Figure 4's own panel title reads "all N runs
    # superimposed" while §6.3 said the panel showed the project's full run count,
    # which is a larger number: the panel plots the collapse family only. The
    # caption states which population it is, from the key §6.3 states it with.
    N_COLLAPSE = str(N["n_runs"]["value"])
    CAPS = {
        "paper_fig1_calibration.png":
            "Calibration of all four models on the held-out pair's " + str(N["b2_nind"]["value"])
            + " independent 400-step trajectories, our arms at " + str(N["iters_main"]["value"])
            + " training iterations. The released checkpoint trained "
            "on these episodes, so for it this arena is in-sample (\\S3). "
            "(a) reliability: observed against predicted coverage, with the calibrated diagonal; "
            "the inset repeats the same points with observed coverage on a log scale, where the "
            "four models separate. "
            "(b) coverage at $\\pm1\\sigma$ against forecast horizon, log scale, against the "
            + NOMINAL1 + "\\% a calibrated Gaussian gives. Every curve sits far below the "
            "diagonal and falls further with horizon. "
            "(c) the overconfidence factor for each model: mean absolute error divided by mean "
            "predicted $\\sigma$, log scale, with the dashed line where error equals $\\sigma$.",
        "paper_fig2_sigma_profile.png":
            "Why the coverage collapse is a horizon effect. Both panels are normalised to "
            "forecast step 1, on the " + str(N["sig_arena"]["value"]) + ", n\\_independent = "
            + str(N["sig_nind"]["value"]) + " 400-step trajectories; our arms at "
            + str(N["iters_main"]["value"]) + " training iterations, the released checkpoint "
            "as released; it trained on these episodes, so for it this arena is in-sample "
            "(\\S3). (a) predicted $\\sigma$ barely moves, and for the faithful arm it "
            "declines. (b) realised error grows " + str(N["err_growth_lo"]["value"]) + "× to "
            + str(N["err_growth_hi"]["value"]) + "× over the same steps, across the four models. "
            "The gap between the panels is the collapse.",
        "paper_fig3_collapse.png":
            "The variance collapse is objective-driven. (a) mean "
            "$\\log\\Delta_{\\log\\sigma}$ against training iteration for each of the "
            + N_COLLAPSE + " runs of the collapse family, which is every run of §5–§7 at the released "
            "width outside §5.2's sweep (Appendix J). The runs are drawn individually but are visually coincident within each "
            "objective, so the " + N_COLLAPSE + " read as two lines, one falling and one rising "
            "-- which is the point: the trajectory does not vary visibly from run to run. "
            "(b) the fitted per-iteration slope for each run, grouped by objective: negative and "
            "tightly clustered under sampled MSE, positive under \\texttt{gaussian\\_nll}. The "
            "sign flip is the evidence that the objective, not the optimiser or the data, "
            "produces it.",
        "paper_fig4_prereg_timeline.png":
            "Pre-registration lead time for each decision rule, from git commit timestamps. "
            "Positive is a rule committed before the data that tested it existed; negative is a "
            "rule written afterwards. The one negative bar is the Task 3 duplication rule, "
            "retracted as a pre-registration in this paper.",
        "paper_fig6_ab_by_horizon.png":
            "The autoregressive-versus-teacher-forcing advantage as a function of forecast "
            "horizon, out-of-sample over three seeds at " + str(N["iters_long"]["value"])
            + " training iterations, on the held-out pair's " + str(N["a1_nind"]["value"])
            + " independent 400-step trajectories. (a) the ratio, which grows monotonically "
            "with depth: h = 368 is the end of a trend rather than a selected point, and the "
            "method's own rollout length of h = 100 sits partway along it. (b) the same "
            "comparison as a gap with its 95\\% cluster-bootstrap interval over whole "
            "trajectories; the interval spans zero only at h = 1, where teacher forcing is "
            "ahead -- a lead a shorter evaluation unit resolves as real, not nominal "
            "(\\S5, M-64). Rule M-23 was run at h = 368 on seed " + str(N["m23_seed"]["value"])
            + " of each arm; these three-seed values, and every other horizon, were computed afterwards.",
        "paper_fig5_three_way.png":
            "The contamination control. (a) outcome across " + str(N["tw_cells"]["value"])
            + " cells for each arm pair (" + str(N["tw_design"]["value"]).replace("_", "\\_") + "), naive "
            "bootstrap on the left of each position and cluster bootstrap on the right; the "
            "duplication control is inert. (b) a different family, the " + str(N["bu_cells"]["value"])
            + " cells of \\S5's A/B gap at the " + str(N["bu_ckpts"]["value"])
            + "-iteration checkpoints (\\S8): distribution of the ratio of cluster to naive "
            "confidence-interval width, with the mean marked. Resampling pooled seed × trajectory "
            "values rather than whole trajectories narrows " + str(N["bu_n_narrowed"]["value"])
            + " of the " + str(N["bu_cells"]["value"]) + " intervals.",
    }
    missing = [f for f in figs if f not in CAPS]
    assert not missing, f"figures with no caption: {missing}"
    # PLACEMENT AT FIRST REFERENCE (Session 5 addendum B.3).
    #
    # The figures used to be emitted as one block under an "Appendix C — figures"
    # heading at the {{FIGURES}} marker. LaTeX floats them, so with every figure
    # declared in one place at the end of the document they drifted past section 14 and
    # left the Appendix C heading standing over nothing -- a heading with no
    # content under it, and eleven figures a reader had to hunt for.
    #
    # Each figure is now inserted immediately after the paragraph that first
    # refers to it by number, so the float has somewhere near its reference to
    # land. The number a figure carries in the rendered document is its order of
    # appearance, which is not the digit in its filename: paper_fig4_* is the
    # first figure the prose refers to and so renders as Figure 1. The prose
    # cites rendered numbers, so placement resolves through INTEXT rather than
    # through the filename (Session 1). Filename order and rendered order are
    # different orders and conflating them is what made every in-text reference
    # point at the wrong figure.
    #
    # A figure whose number is never referenced in the prose has nowhere to be
    # placed, and that is a defect in the prose rather than something to paper
    # over -- it is asserted rather than silently appended.
    INTEXT = {
        "paper_fig4_prereg_timeline.png": "1",
        "paper_fig6_ab_by_horizon.png": "2",
        "paper_fig1_calibration.png": "3",
        "paper_fig3_collapse.png": "4",
        "paper_fig2_sigma_profile.png": "5",
        "paper_fig5_three_way.png": "6",
    }
    assert sorted(INTEXT) == sorted(figs), (
        f"INTEXT does not cover the figures on disk: {sorted(INTEXT)} vs {sorted(figs)}")
    body = out
    unplaced = []
    for f in figs:
        _n = INTEXT.get(f)
        assert _n, f"cannot read a figure number from {f}"
        _img = f"![{CAPS[f]}](figures/{f})"
        # "(?!\\d)" rather than "\\b": the prose refers to sub-panels as "Figure 5a",
        # where \\b fails between the digit and the letter, and a bare \\d+ would let
        # a search for Figure 1 match Figure 15.
        _m = re.search(r"Figure~?\s*" + _n + r"(?!\d)", body)
        if not _m:
            unplaced.append(f)
            continue
        # after the end of the paragraph holding the first reference
        _end = body.find("\n\n", _m.end())
        _end = len(body) if _end == -1 else _end + 2
        body = body[:_end] + _img + "\n\n" + body[_end:]
    assert not unplaced, (
        f"figures never referenced by number in the prose, so they have no home: "
        f"{unplaced}. Reference them or remove them.")
    # Appendix C was the container for the block and is retired with it. The
    # marker is removed rather than left to render an empty heading.
    body = body.replace("{{FIGURES}}\n\n", "").replace("{{FIGURES}}", "")
    body = body.rstrip() + "\n"
    open(OUT, "w").write(header + body)

    # docs/BUILD_CHECKS.md — supplementary, generated from the same values.
    # Appendix D kept the failure modes and the exclusions; the registry, the
    # self-test and the checker's own defects moved here (Session 5a, B.2). It is
    # substituted rather than hand-maintained so a count quoted here cannot drift
    # from the one section 8 prints, which is the drift kind-count exists to catch.
    # docs/APPENDIX_G_VARIANCE_ARITHMETIC.md joined it in Session 9, when 7.5's
    # extrapolation and Appendix G's five-assumption table moved out of the body.
    for _stem in ("BUILD_CHECKS", "APPENDIX_G_VARIANCE_ARITHMETIC"):
        _bct = os.path.join("docs", _stem + ".template.md")
        if not os.path.exists(_bct):
            continue
        _bc_missing, _bc_used = [], set()

        def _bcsub(m):
            k = m.group(1)
            if k not in N:
                _bc_missing.append(k)
                return m.group(0)
            _bc_used.add(k)
            return str(N[k]["value"])

        _bc_out = re.sub(r"\{\{([A-Za-z0-9_]+)\}\}", _bcsub, open(_bct).read())
        assert not _bc_missing, (
            f"{_bct} has placeholders with no value: "
            f"{sorted(set(_bc_missing))}")
        _bc_left = re.findall(r"\{\{[^}]*\}\}", _bc_out)
        assert not _bc_left, f"{_stem} unresolved: {sorted(set(_bc_left))}"
        open(os.path.join("docs", _stem + ".md"), "w").write(_bc_out)
        print(f"  wrote docs/{_stem}.md ({len(_bc_used)} values substituted)")

    # LaTeX for submission, from the same resolved text -- one source, two outputs.
    import md_to_tex
    title = re.search(r"^# (.+)$", out, re.M).group(1)
    # No author string: the submission is double-blind and tmlr.sty renders
    # "Anonymous authors" in submission mode. Keeping the name out of the source
    # keeps it out of the supplementary archive too (A3).
    # D1: the LaTeX is the submission (tmlr.sty with no option is its anonymous
    # submission mode), so commit hashes render as their anonymous labels here and
    # only here; PAPER.md keeps the real ones. Without git history -- an unpacked
    # bundle, whose copies already carry labels -- the map is empty and nothing moves.
    # The map file is written by the bundle builder, not here: a map that included
    # the latest commit could never be committed current, so a rebuild would dirty it.
    try:
        import make_anon_bundle as AB
        _cmap = AB.COMMIT_LABELS
    except ImportError:
        AB, _cmap = None, {}
    _sub_text = AB.apply_commit_labels(header + body, _cmap) if AB else header + body
    tex, unhandled = md_to_tex.convert(_sub_text, title, "")
    _fn = check_footnote_tokens(tex)
    assert not _fn, ("Markdown footnote tokens survived into the LaTeX and set as literal "
                     f"text: {_fn[:5]}")
    open("PAPER.tex", "w").write(tex)
    assert not unhandled, f"converter did not handle: {unhandled[:5]}"

    print("PAPER BUILD")
    print("=" * 72)
    print(f"  template            : {TEMPLATE} ({len(text.splitlines())} lines)")
    print(f"  placeholders filled : {len(used)}")
    print(f"  distinct artifacts  : {len(set(N[k]['source'] for k in used))}")
    print(f"  figures attached    : {len(figs)}")
    print(f"  gate self-test: {_gate_caught} of {N_GATE_RULES} rules caught their corruption")
    print(f"  numerals typed in prose : {len(typed_nums)}  "
          f"(section numbers, arXiv ids and constants expected)")
    print(f"  number-words in prose   : {len(typed_words)}  {', '.join(typed_words)}")
    if unused:
        print(f"  collected but unused: {len(unused)}")
        print("    " + ", ".join(unused))
    print(f"  wrote {OUT} ({len(body.splitlines())} lines)")
    print(f"  wrote PAPER.tex ({len(tex.splitlines())} lines)")
    print("\n  every number in the paper traces to:")
    for s in sorted(set(N[k]["source"] for k in used)):
        print(f"    {s}")


if __name__ == "__main__":
    main()
