"""Collect every number the paper quotes, from the artifacts, into one keyed file.

The paper is written as PAPER.template.md with {{key}} placeholders. build_paper.py
substitutes from results/paper_numbers.json and refuses to emit a paper if any
placeholder is unresolved or any key here is unused. No number in the paper is typed.
"""
import glob
import json
import os
import re
import subprocess
import sys
from math import comb

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "src"))
import rwm_data as R  # noqa: E402


def J(n):
    return json.load(open(os.path.join(R.RESULTS, n)))


# Number words, at module scope because keys derived near the top of main() need
# them too. This lived inside main() below the ledger block and the first caller
# above it raised UnboundLocalError.
WORDS = {1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven",
         8: "Eight", 9: "Nine", 10: "Ten", 11: "Eleven", 12: "Twelve", 13: "Thirteen"}


def main():
    N = {}
    def put(k, v, src):
        N[k] = {"value": v, "source": src}

    cal = J("task1_calibration.json")
    sig = J("task2_sigma_profile.json")
    s6 = J("step6_analysis.json")
    t5 = J("task5_analysis.json")
    t3 = J("task3_control_arm.json")
    tw = J("task3_three_way.json")
    bu = J("review_bootstrap_unit.json")
    ver = J("verify_reproduction.json")
    w = J("step0_regimes.json")["window_accounting"]
    man = J("manifest.json")
    dif = J("step4_3_differential.json")

    # --- dataset -----------------------------------------------------------
    put("rows", f'{w["rows"]:,}', "results/step0_regimes.json")
    put("win_naive", f'{w["naive_windows_reference_builder_marks_valid"]:,}',
        "results/step0_regimes.json")
    put("win_cross", f'{w["boundary_crossing_windows"]:,}', "results/step0_regimes.json")
    put("win_usable", f'{w["usable_episode_respecting_windows"]:,}', "results/step0_regimes.json")
    put("win_tail", w["tail_rows_that_cannot_start_a_window"], "results/step0_regimes.json")
    put("contam_pct", round(100 * w["boundary_crossing_windows"]
                            / w["naive_windows_reference_builder_marks_valid"], 2),
        "results/step0_regimes.json")
    # B6/B7. The window LENGTH -- §5.1 said 33 where the config says 32 history +
    # 8 forecast = 40, which is the only length consistent with 10,000 - 39 =
    # 9,961 -- and the ROW STRUCTURE that makes the counts above derivable. §3
    # said "ten concatenated 20-second episodes"; taken literally that is ten
    # segments of 1,000, which gives 351 crossing and 9,610 usable and makes the
    # paper look off by one.
    put("win_len", w["window"], "results/step0_regimes.json")
    put("win_hist", w["history_horizon"], "results/step0_regimes.json")
    put("win_fore", w["forecast_horizon"], "results/step0_regimes.json")
    put("ep0_rows", f'{w["episode_lengths"][0]:,}', "results/step0_regimes.json")
    put("ep_rest_rows", f'{w["episode_lengths"][1]:,}', "results/step0_regimes.json")
    put("n_ep_rest", len(w["episode_lengths"]) - 1, "results/step0_regimes.json")
    put("n_ep_rest_word", WORDS.get(len(w["episode_lengths"]) - 1,
                                    str(len(w["episode_lengths"]) - 1)).lower(),
        "results/step0_regimes.json")
    put("orphan_rows", w["orphan_rows"], "results/step0_regimes.json")
    put("row_structure", w["row_structure"], "results/step0_regimes.json")
    put("reset_rows_first", f'{w["reset_rows"][0]:,}', "results/step0_regimes.json")
    put("reset_rows_second", f'{w["reset_rows"][1]:,}', "results/step0_regimes.json")
    put("reset_rows_last", f'{w["reset_rows"][-1]:,}', "results/step0_regimes.json")

    # --- calibration (contribution 1) -------------------------------------
    lab = {"faithful (mse)": "faithA", "corrected (nll)": "nll",
           "teacher-forced armB": "armB", "released ckpt": "rel"}
    for k, tag in lab.items():
        m = cal[k]
        # render as a reader would write it: 7,878x not 7878.1x, 315x not 315.0x
        rr = m["ratio_err_over_sigma"]
        put(f"cal_{tag}_ratio", f"{rr:,.0f}" if rr >= 100 else f"{rr:.1f}",
            "results/task1_calibration.json")
        put(f"cal_{tag}_cov1", round(100 * m["coverage"]["1"]["pm1"], 2), "results/task1_calibration.json")
        put(f"cal_{tag}_cov368", round(100 * m["coverage"]["368"]["pm1"], 2), "results/task1_calibration.json")
        # A1 -- every ratio and coverage in the 6.2 table now carries a 95%
        # cluster-bootstrap interval over whole trajectories. The paper declares
        # that standard for itself in section 3 and was not applying it here.
        _rc = m["ratio_err_over_sigma_ci"]
        _f = (lambda v: f"{v:,.0f}") if rr >= 100 else (lambda v: f"{v:.1f}")
        put(f"cal_{tag}_ratio_ci", f"{_f(_rc[0])}, {_f(_rc[1])}",
            "results/task1_calibration.json")
        put(f"cal_{tag}_cov100", round(100 * m["coverage"]["100"]["pm1"], 2),
            "results/task1_calibration.json")
        for _h in ("1", "100", "368"):
            _cc = m["coverage"][_h]["pm1_ci"]
            put(f"cal_{tag}_cov{_h}_ci", f"{100*_cc[0]:.2f}, {100*_cc[1]:.2f}",
                "results/task1_calibration.json")
        put(f"cal_{tag}_cov", round(m["cov_of_sigma_across_batch"], 4), "results/task1_calibration.json")
        put(f"cal_{tag}_npos", m["sigma_err_corr_n_positive"], "results/task1_calibration.json")
        put(f"cal_{tag}_ndim", m["n_finite_corr"], "results/task1_calibration.json")
        put(f"cal_{tag}_p", f"{m['sigma_err_corr_sign_p_two_sided']:.2e}", "results/task1_calibration.json")
        put(f"cal_{tag}_r", round(m["sigma_err_corr_mean"], 3), "results/task1_calibration.json")
    put("cal_armB_over_faithA_cov",
        round(cal["teacher-forced armB"]["cov_of_sigma_across_batch"]
              / cal["faithful (mse)"]["cov_of_sigma_across_batch"], 1),
        "results/task1_calibration.json")

    slab = {"faithful armA (mse)": "faithA", "corrected armA (nll)": "nll",
            "teacher-forced armB": "armB", "released checkpoint": "rel"}
    for k, tag in slab.items():
        put(f"sig_{tag}_growth", round(sig[k]["sigma_growth_1_to_8"], 4), "results/task2_sigma_profile.json")
        put(f"err_{tag}_growth", round(sig[k]["err_growth_1_to_8"], 2), "results/task2_sigma_profile.json")

    # --- the A/B claim -----------------------------------------------------
    put("t5_seeds", t5["provenance"]["n_seeds"], "results/task5_analysis.json")
    g = t5["gaps"]["out-of-sample|10000|h368"]
    put("m23_A", f'{g["A"]:.4f}', "results/task5_analysis.json")
    put("m23_B", f'{g["B"]:.4f}', "results/task5_analysis.json")
    put("m23_gap", round(g["gap"], 4), "results/task5_analysis.json")
    put("m23_ratio", f'{g["B"] / g["A"]:.1f}', "results/task5_analysis.json")
    put("m23_nind", g["n_ind"], "results/task5_analysis.json")
    if "ci" in g:
        put("m23_ci_lo", round(g["ci"][0], 2), "results/task5_analysis.json")
        put("m23_ci_hi", round(g["ci"][1], 2), "results/task5_analysis.json")
    put("m23_c1", "holds" if t5["m23"]["c1"] else "FAILS", "results/task5_analysis.json")
    put("m23_c2", "holds" if t5["m23"]["c2"] else "FAILS", "results/task5_analysis.json")
    put("m23_c3", "holds" if t5["m23"]["c3"] else "FAILS", "results/task5_analysis.json")
    put("m23_sign_h368", t5["sign_consistent_h368"], "results/task5_analysis.json")
    put("m23_n_episodes_positive",
        sum(1 for e in t5["per_episode"].values() if e["h368"] > 0), "results/task5_analysis.json")
    put("m23_n_episodes", len(t5["per_episode"]), "results/task5_analysis.json")
    g8 = t5["gaps"]["out-of-sample|10000|h8"]
    put("m23_h8_gap", round(g8["gap"], 4), "results/task5_analysis.json")
    put("m23_h8_excl", "excludes zero" if g8["excludes_zero"] else "includes zero",
        "results/task5_analysis.json")
    put("q4_implied_A", f"{t5['q4']['A']['implied_iters']:,.0f}", "results/task5_analysis.json")
    put("q4_implied_B", f"{t5['q4']['B']['implied_iters']:,.0f}", "results/task5_analysis.json")

    # --- collapse / iteration counts --------------------------------------
    put("collapse_pooled_rate", f"{s6['collapse']['rate']:.4e}" if "rate" in s6["collapse"]
        else f"{s6['collapse'].get('slope_per_iter', float('nan')):.4e}", "results/step6_analysis.json")
    put("implied_iters", f"{s6['collapse']['iters_to_checkpoint']:,.0f}", "results/step6_analysis.json")

    # --- contamination -----------------------------------------------------
    put("dup_cost_pct", f'{t3["verdict"]["duplication_cost_pct_tail250"]:.2f}',
        "results/task3_control_arm.json")
    put("contam_cost_pct", f'{t3["verdict"]["contamination_cost_pct_tail250"]:.2f}',
        "results/task3_control_arm.json")
    b = t3["bootstrap_over_iterations"]["duplicated_minus_clean"]
    put("dup_ci_lo", round(b["lo"], 4), "results/task3_control_arm.json")
    put("dup_ci_hi", round(b["hi"], 4), "results/task3_control_arm.json")
    clean_n = J("step5_armA_seed0.json")["hyperparameters"]["n_train_windows"]
    con_n = J("step5_armA_seed0_contam.json")["hyperparameters"]["n_train_windows"]
    put("arm_clean_windows", f"{clean_n:,}", "results/step5_armA_seed0.json")
    put("arm_contam_windows", f"{con_n:,}", "results/step5_armA_seed0_contam.json")
    put("arm_splices", con_n - clean_n, "results/step5_armA_seed0_contam.json")
    put("arm_contam_pct", round(100 * (con_n - clean_n) / con_n, 2),
        "results/step5_armA_seed0_contam.json")

    S = tw["_summary"]
    for pair, tag in (("contaminated_minus_clean", "cc"), ("duplicated_minus_clean", "dc"),
                      ("contaminated_minus_duplicated", "cd")):
        for unit in ("naive", "cluster"):
            for out in ("hurt", "helped", "no_effect"):
                put(f"tw_{tag}_{unit}_{out}", S[pair][unit][out], "results/task3_three_way.json")
    put("tw_cells", len([k for k in tw if k != "_summary"]), "results/task3_three_way.json")

    # --- bootstrap unit ----------------------------------------------------
    put("bu_mean_ratio", round(bu["_summary"]["width_ratio_mean"], 2),
        "results/review_bootstrap_unit.json")
    put("bu_min_ratio", round(bu["_summary"]["width_ratio_min"], 2), "results/review_bootstrap_unit.json")
    put("bu_max_ratio", round(bu["_summary"]["width_ratio_max"], 2), "results/review_bootstrap_unit.json")
    put("bu_cells", bu["_summary"]["n_cells"], "results/review_bootstrap_unit.json")
    oos = {k: v for k, v in bu.items()
           if k != "_summary" and k.startswith("out-of-sample")}
    longh = [v for k, v in oos.items() if "h368" in k or "h168" in k]
    short = [v for k, v in oos.items() if "h8" in k]
    put("ab_long_cells", len(longh), "results/review_bootstrap_unit.json")
    put("ab_long_excl", sum(1 for v in longh if v["cluster"]["excludes_zero"]),
        "results/review_bootstrap_unit.json")
    put("ab_short_cells", len(short), "results/review_bootstrap_unit.json")
    put("ab_short_excl", sum(1 for v in short if v["cluster"]["excludes_zero"]),
        "results/review_bootstrap_unit.json")
    put("bu_changes", bu["_summary"]["n_verdict_changes"], "results/review_bootstrap_unit.json")

    # --- verification ------------------------------------------------------
    put("ver_files", len(ver["regenerated_files"]), "results/verify_reproduction.json")
    put("ver_values", f"{ver['values_compared']:,}", "results/verify_reproduction.json")
    put("ver_identical", f"{ver['bitwise_identical']:,}", "results/verify_reproduction.json")
    put("ver_pct", f"{100*ver['bitwise_identical']/ver['values_compared']:.2f}",
        "results/verify_reproduction.json")
    put("ver_differing", ver["differing"], "results/verify_reproduction.json")
    put("ver_keys_lost", ver["keys_lost"], "results/verify_reproduction.json")
    # The three outcome classes account for values_compared exactly, so the paper can
    # print them as a partition rather than as five numbers a reader must trust. The
    # near-identical class is the one that was missing: a bitwise-only recount lands on
    # 205 differing because it folds these 27 in, which is what made the figures look
    # as though they did not add up.
    put("ver_close", ver["identical_to_1e-9"], "results/verify_reproduction.json")
    # The size of the claim. A clean clone already contains every committed artifact, so
    # the comparison covers only what the run rewrites. Stating the fraction is cheaper
    # than having a reviewer compute it and conclude we hid it.
    _all = ver["values_compared"] + ver["copied_file_values"]
    put("ver_copied", f"{ver['copied_file_values']:,}", "results/verify_reproduction.json")
    put("ver_all", f"{_all:,}", "results/verify_reproduction.json")
    put("ver_claim_pct", f"{100*ver['values_compared']/_all:.2f}",
        "results/verify_reproduction.json")
    put("ver_keys_lost_files", len(ver["keys_lost_files"]),
        "results/verify_reproduction.json")
    put("ver_timing", f'{ver["timing_excluded"]:,}', "results/verify_reproduction.json")
    put("ver_machine", ver["machine_file_values_excluded"], "results/verify_reproduction.json")
    _tb = ver.get("time_bounded_files_excluded", [])
    put("ver_timebound_n", len(_tb), "results/verify_reproduction.json")
    put("ver_timebound", ", ".join(f"`results/{x}`" for x in _tb) or "none",
        "results/verify_reproduction.json")
    put("ver_selfref", len(ver.get("self_referential_keys_excluded", [])),
        "results/verify_reproduction.json")
    put("ver_hostkeys", len(ver.get("host_sourced_keys_excluded", [])),
        "results/verify_reproduction.json")
    # the committed iteration count of the wall-clock-bounded diagnostic, and the
    # cap it never reached -- both read from the artifact rather than typed
    if _tb:
        _ov = J(_tb[0])
        put("ver_tb_ran", _ov["iterations_run"], f"results/{_tb[0]}")
        put("ver_tb_cap", f'{_ov["config"]["iters"]:,}', f"results/{_tb[0]}")
        put("ver_tb_budget", f'{_ov["config"]["max_seconds"]:,.0f}', f"results/{_tb[0]}")

    # Part C: the count of COMPARATIVE claims verified, reported in section 8
    # beside the numeral count. A build that verifies its own interpretive claims
    # is a stronger reproducibility statement than one that verifies only numerals.
    CC = J("comparative_claims.json")
    put("cc_n", CC["n_claims"], "results/comparative_claims.json")
    put("cc_pass", CC["n_pass"], "results/comparative_claims.json")
    # Assert, do not default. check_comparative_claims.py writes the self_test
    # block only when run with --self-test; running it without leaves the block
    # absent, and .get(..., 0) turned that into "0 of 0 corruptions caught" in the
    # paper -- a sentence claiming the self-test found nothing, which is exactly
    # what it would say if the self-test had silently stopped running. Same shape
    # as M-36's "0 defects". reproduce.sh stage 28a always passes --self-test.
    assert "self_test" in CC, (
        "results/comparative_claims.json has no self_test block: re-run "
        "scripts/check_comparative_claims.py --self-test")
    _st = CC["self_test"]
    assert _st["n"] > 0, "self-test ran zero corruptions"
    put("cc_st_n", _st["n"], "results/comparative_claims.json")
    put("cc_st_caught", _st["caught"], "results/comparative_claims.json")
    put("cc_kinds", len({c["kind"] for c in CC["claims"]}), "results/comparative_claims.json")
    # B8. What the abstract is now allowed to claim about its own numbers, from
    # the audit that enforces it rather than from a sentence that asserted it.
    TN = J("typed_numerals.json")
    assert TN["n_unclassified"] == 0, (
        f"{TN['n_unclassified']} typed numerals are unclassified; the paper may not "
        "claim its numerals are all addresses or declared constants until they are")
    put("tn_typed", TN["n_typed"], "results/typed_numerals.json")

    # D3. Appendix F, generated from the ledger. Ledger identifiers ran through the
    # body with no table behind them, so an identifier was either decoration or an
    # instruction to open a 330 KB file. With the table, the identifier can stay
    # only where a pre-registered verdict is reported and come out elsewhere.
    # E4. All seven loss terms and what each does to sigma, MEASURED. §6.3's
    # derivation addresses two of them; its completeness rests on the other five
    # being inert with respect to sigma, and that was asserted rather than shown.
    E4 = J("e4_sigma_gradients.json")
    put("e4_n_terms", E4["n_terms"], "results/e4_sigma_gradients.json")
    put("e4_n_live", E4["n_live"], "results/e4_sigma_gradients.json")
    put("e4_n_touch", E4["n_touching_sigma"], "results/e4_sigma_gradients.json")
    put("e4_n_inert", E4["n_terms"] - E4["n_touching_sigma"],
        "results/e4_sigma_gradients.json")
    put("e4_touching", " and ".join(f"`{t}`" for t in E4["touching"]),
        "results/e4_sigma_gradients.json")
    def _g(v):
        return "0" if v == 0 else f"{v:.3g}"
    put("e4_table", "".join(
        "| `{t}` | {live} | {w:.2f} | `{where}` | {gs} | {gd} | {gm} |\n".format(
            t=r["term"], live=("live" if not r["identically_zero"] else "**dead**"),
            w=r["weight"], where=r["where"],
            gs=_g(r["grad_logstd_tower_norm"]), gd=_g(r["grad_log_delta_logstd_abs"]),
            gm=_g(r["grad_min_logstd_abs"]))
        for r in E4["terms"]).rstrip(),
        "results/e4_sigma_gradients.json")

    # Appendix F's reason for existing quotes the ledger's size, so it is read
    # from the file rather than typed -- the ledger grows every revision.
    put("ledger_kb", f'{os.path.getsize("FINDINGS_LEDGER.md") / 1024:.0f}',
        "FINDINGS_LEDGER.md, on disk")

    # E5 / M-50 -- the synthetic sigma demonstration.
    E5 = J("e5_synthetic_sigma.json")
    _a5, _b5 = E5["arms"]["mse"], E5["arms"]["gaussian_nll"]
    _t5 = E5["thresholds"]
    put("e5s_verdict", E5["verdict"], "results/e5_synthetic_sigma.json")
    put("e5s_span", f'{E5["config"]["true_sigma_span_factor"]:.0f}',
        "results/e5_synthetic_sigma.json")
    put("e5s_seeds", len(E5["config"]["seeds"]), "results/e5_synthetic_sigma.json")
    put("e5s_iters", f'{E5["config"]["iters"]:,}', "results/e5_synthetic_sigma.json")
    put("e5s_n_train", f'{E5["config"]["n_train"]:,}', "results/e5_synthetic_sigma.json")
    put("e5s_mse_ratio", f'{_a5["ratio_mean"]:.4f}', "results/e5_synthetic_sigma.json")
    # ONE DECIMAL, not zero. At zero it printed 22, and once the combined arm's
    # two runs joined the collapse family e2_fitted_runs printed 22 as well --
    # the same numeral twice in §6.3, once as a factor and once as a count of
    # runs, which is the `restatement` check's ambiguous-numeral kind and the
    # defect it exists to catch (the abstract's 4.61× beside 4.61%). The
    # disambiguation is more precision on the measurement, not a note beside it.
    put("e5s_mse_under", f'{1 / _a5["ratio_mean"]:.1f}', "results/e5_synthetic_sigma.json")
    put("e5s_mse_spread", f'{_a5["spread_max"]:.3f}', "results/e5_synthetic_sigma.json")
    put("e5s_mse_slope", f'{_a5["slope_mean"]:+.6f}', "results/e5_synthetic_sigma.json")
    put("e5s_nll_ratio", f'{_b5["ratio_mean"]:.4f}', "results/e5_synthetic_sigma.json")
    put("e5s_nll_pct_off", f'{abs(1 - _b5["ratio_mean"]) * 100:.0f}',
        "results/e5_synthetic_sigma.json")
    # spread_max is the BEST of three seeds, and using it for the recovering arm
    # while using it for the collapsing arm too is generous in one direction and
    # conservative in the other: the mse spreads are 1.002/1.002/1.003 (max is the
    # worst case for a collapse claim) and the gaussian_nll spreads are
    # 3.668/1.137/1.023 (max is the best case for a recovery claim). The table now
    # prints the RANGE for the recovering arm, so a reader sees that two of three
    # seeds barely clear the 1.01x detection floor.
    _nll_spreads = sorted(r["sigma_hat_spread_factor"] for r in _b5["runs"])
    put("e5s_nll_spread", f'{_b5["spread_max"]:.2f}', "results/e5_synthetic_sigma.json")
    put("e5s_nll_spread_lo", f'{_nll_spreads[0]:.2f}', "results/e5_synthetic_sigma.json")
    put("e5s_nll_spread_range", f'{_nll_spreads[0]:.2f}\u2013{_nll_spreads[-1]:.2f}',
        "results/e5_synthetic_sigma.json")
    _nll_slopes = sorted(r["slope_log_sigma"] for r in _b5["runs"])
    put("e5s_nll_slope_lo", f'{_nll_slopes[0]:.4f}', "results/e5_synthetic_sigma.json")
    put("e5s_nll_slope_range", f'{_nll_slopes[0]:.4f}\u2013{_nll_slopes[-1]:.4f}',
        "results/e5_synthetic_sigma.json")
    put("e5s_nll_slope_spread_factor", f'{_nll_slopes[-1] / _nll_slopes[0]:.0f}',
        "results/e5_synthetic_sigma.json")
    _mse_spreads = sorted(r["sigma_hat_spread_factor"] for r in _a5["runs"])
    put("e5s_mse_spread_range", f'{_mse_spreads[0]:.3f}\u2013{_mse_spreads[-1]:.3f}',
        "results/e5_synthetic_sigma.json")
    put("e5s_nll_slope", f'{_b5["slope_mean"]:+.4f}', "results/e5_synthetic_sigma.json")
    put("e5s_slope_thr", f'{_t5["slope_threshold"]:.5f}', "results/e5_sigma_dilution.json")
    put("e5s_collapse_thr", _t5["collapse_ratio_threshold"], "results/e5_sigma_dilution.json")
    put("e5s_recovery_thr", f'{_t5["recovery_factor_threshold"]:.0f}',
        "results/e5_sigma_dilution.json")
    _D5 = J("e5_sigma_dilution.json")
    put("e5s_fp_rate", f'{_D5["mde"]["false_positive_rate_at_dilution_0"] * 100:.0f}',
        "results/e5_sigma_dilution.json")
    put("e5s_null_slope_p95", f'{_D5["null"]["slope_abs_p95"]:.1g}',
        "results/e5_sigma_dilution.json")
    put("e5s_null_spread", f'{_D5["null"]["spread_max"]:.4f}',
        "results/e5_sigma_dilution.json")
    put("e5s_null_ratio_lo", f'{_D5["null"]["ratio_median_min"]:.3f}',
        "results/e5_sigma_dilution.json")
    put("e5s_null_r_max", f'{_D5["null"]["r_abs_max"]:.2f}', "results/e5_sigma_dilution.json")
    put("e5s_span_floor", f'{_D5["mde"]["span_floor"]}', "results/e5_sigma_dilution.json")

    # E7 / M-51 -- three free ranking baselines.
    E7 = J("e7_free_baselines.json")
    _bl = {r["baseline"]: r for r in E7["baselines"]}
    put("e7_verdict", E7["verdict"], "results/e7_free_baselines.json")
    put("e7_nind", E7["design"]["n_independent"], "results/e7_free_baselines.json")
    put("e7_r_dis", f'{_bl["step-size"]["r_disagreement_error"]:+.4f}',
        "results/e7_free_baselines.json")
    put("e7_mde_margin", f'{E7["thresholds"]["margin"]:.4f}',
        "results/e7_free_baselines_power.json")
    put("e7_mde_partial", f'{E7["thresholds"]["partial"]:.4f}',
        "results/e7_free_baselines_power.json")
    for _k, _tag in (("step-size", "step"), ("entry-res", "entry"),
                     ("forecast-index", "index")):
        _r = _bl[_k]
        put(f"e7_{_tag}_r", f'{_r["r_baseline_error"]:+.4f}', "results/e7_free_baselines.json")
        put(f"e7_{_tag}_margin", f'{_r["margin"]:+.4f}', "results/e7_free_baselines.json")
        put(f"e7_{_tag}_partial", f'{_r["partial_disagreement_given_baseline"]:+.4f}',
            "results/e7_free_baselines.json")
        put(f"e7_{_tag}_beaten", "yes" if (_r["margin_beats_mde"] and _r["partial_beats_mde"])
            else "no", "results/e7_free_baselines.json")
        _ws = _r["within_step_r_baseline"]
        put(f"e7_{_tag}_ws", "undefined" if not (_ws == _ws) else f"{_ws:+.4f}",
            "results/e7_free_baselines.json")
    put("e7_ws_dis", f'{_bl["step-size"]["within_step_r_disagreement"]:+.4f}',
        "results/e7_free_baselines.json")
    put("e7_n_beaten", E7["n_beaten"], "results/e7_free_baselines.json")
    put("e7_n_new", E7["n_new_baselines"], "results/e7_free_baselines.json")

    # M-49's design, so §11 can name it rather than describe it.
    P2 = J("p2_capacity_power.json")
    put("m49_width", P2["capacity"]["matched_hidden_size"], "results/p2_capacity_power.json")
    put("m49_matched_params", f'{P2["capacity"]["matched_total_params"]:,}',
        "results/p2_capacity_power.json")
    put("m49_matched_ratio", f'{P2["capacity"]["matched_ratio"]:.4f}',
        "results/p2_capacity_power.json")
    put("m49_mde_ratio", f'{P2["mde_80pct_power"]["overconfidence_ratio_multiplicative"]:.2f}',
        "results/p2_capacity_power.json")
    put("m49_mde_cov", f'{P2["mde_80pct_power"]["coverage_pts"]:.2f}',
        "results/p2_capacity_power.json")

    # M-49 discharged. The capacity-matched arm.
    M49 = J("m49_capacity_matched.json")
    _m49 = M49["m44"]           # the block name is R2's; the rule is M-49's
    put("m49_verdict", _m49["verdict"], "results/m49_capacity_matched.json")
    put("m49_verdict_short", _m49["verdict"].split("\u2014")[0].strip(),
        "results/m49_capacity_matched.json")
    put("m49_ratio_gain", f'{_m49["mean_ratio_improvement"]:.2f}',
        "results/m49_capacity_matched.json")
    put("m49_cov_gain", f'{_m49["mean_coverage_gain_pts"]:+.2f}',
        "results/m49_capacity_matched.json")
    put("m49_n_conditions", len(_m49["conditions"]), "results/m49_capacity_matched.json")
    put("m49_n_conditions_met", sum(1 for v in _m49["conditions"].values() if v),
        "results/m49_capacity_matched.json")
    put("m49_shrink",
        f'{J("r2_independent_ensemble.json")["m44"]["mean_ratio_improvement"] - _m49["mean_ratio_improvement"]:.2f}',
        "results/m49_capacity_matched.json + r2_independent_ensemble.json")

    AG = J("appendix_g_rules.json")
    put("appG_n_rules", AG["n_rules"], "results/appendix_g_rules.json")
    put("appG_n_lead", AG["n_with_lead_time"], "results/appendix_g_rules.json")
    _pos = [r for r in AG["rules"] if (r["lead_hours"] or 0) > 0]
    _neg = [r for r in AG["rules"] if r["lead_hours"] is not None and r["lead_hours"] < 0]
    put("appG_n_positive", len(_pos), "results/appendix_g_rules.json")
    put("appG_n_negative", len(_neg), "results/appendix_g_rules.json")
    def _lead(r):
        if r["lead_hours"] is None:
            return "not computed"
        v = r["lead_hours"]
        return f"{v * 60:+.0f} min" if abs(v) < 1 else f"{v:+.1f} h"
    _rows = "".join(
        "| `{id}` | {title} | {commit} | {lead} | {tested} | {verdict} |\n".format(
            id=r["id"], title=r["title"].replace("|", "/"),
            commit=(f'`{r["rule_commit"]}` {r["commit_subject"]}'
                    if r["rule_commit"] else "—"),
            lead=_lead(r), tested=r["tested_by"] or "—",
            verdict=r["verdict"].replace("|", "/"))
        for r in AG["rules"])
    put("appG_table", _rows.rstrip(), "results/appendix_g_rules.json")
    # B.1: the body no longer carries rule texts. They ship in full in
    # docs/APPENDIX_G_RULES.md, written by scripts/appendix_g_rules.py.
    put("tn_classes", TN["n_classes"], "results/typed_numerals.json")
    put("tn_exceptions", TN["n_exceptions"], "results/typed_numerals.json")
    # C5(rev2), 3.5. Section 8 said "N kinds" from this key while appendix D
    # enumerated eight by hand, and the two had drifted seven apart. The
    # enumeration is generated from the same set the count comes from, so the
    # `kind-count` check has something to compare and the two cannot disagree.
    # The defects the self-test found in the checker rather than in the paper.
    # Appendix C said "Two" and listed two; there are more, and a typed count in
    # the appendix about count consistency is not defensible.
    _cd = CC.get("checker_defects", [])
    put("cc_selfdefects", len(_cd), "results/comparative_claims.json")
    put("cc_selfdefects_word", WORDS.get(len(_cd), str(len(_cd))), "results/comparative_claims.json")
    put("cc_selfdefects_lower",
        WORDS.get(len(_cd), str(len(_cd))).lower(), "results/comparative_claims.json")
    put("cc_selfdefect_list",
        "".join(f"\n\n- {d[0].upper()}{d[1:]}." for d in _cd),
        "results/comparative_claims.json")
    _kinds = sorted({c["kind"] for c in CC["claims"]})
    _blurb = {
        "overlap": "two intervals do or do not overlap",
        "extremum": "a named cell is the max or min of its family",
        "figure_reference": "every in-text figure number names a figure that exists, and no "
                            "more distinct figure numbers are cited than the document has "
                            "figures",
        "sign": "a stated rise or fall matches the direction of the difference",
        "orders": "a stated count of orders of magnitude matches `round(log10(ratio))`, "
                  "or a ratio quoted directly appears in the sentence that quotes it",
        "cell": "a k-of-45 count is the arena and horizon the text names",
        "compare": "a stated ordering between two scalars",
        "relvar": "a stated ratio of relative variabilities",
        "count-consistency": "one count asserted in several places, in words, numerals or "
                             "numeric-string variants, agrees everywhere",
        "horizon-label": "a phrase naming a horizon resolves to the horizon the artifact says "
                         "it is, and the numbers beside it are that horizon's",
        "horizon-forbidden": "a withdrawn horizon label appears nowhere in the paper",
        "horizon-consistency": "every horizon-indexed figure in the prose names its horizon, "
                               "and names the one its artifact cell came from",
        "count-dependence": "a clean k-of-k count carries an interval or a not-independent note",
        "retraction-consistency": "a claim the ledger marks superseded is asserted nowhere "
                                  "reader-facing",
        "retraction_class_consistency": "every retraction identifier a reader-facing file names "
                                        "resolves to exactly one class, and to the class the "
                                        "ledger gives it",
        "cross-artifact-sync": "the README and model card carry the paper's headline values",
        "abstract-budget": "the abstract stays inside its word and numeral budget",
        "interval-required": "a quoted ratio or coverage is accompanied by its interval",
        "arithmetic": "a stated total equals the sum of its stated parts",
        "population_partition": "the run populations the paper quotes against one another "
                                "partition -- the run table's row counts sum to the stated "
                                "total, every row states the width it trained at, and the "
                                "collapse family plus the runs excluded from it equal the "
                                "total",
        "unit-consistency": "every n_independent figure names the evaluation unit it counts -- the revision introduced a second unit length, and 60 units of 33 rows and 4 of 400 are both \"n_independent\"",
        "kind-count": "the number of kinds section 8 claims, appendix D enumerates and the "
                      "checker registers are one number",
        "scope-consistency": "a universal quantifier is checked against the set it quantifies "
                             "over",
        "frequency-consistency": "a frequency stated in words -- \"at every horizon\", \"at "
                                 "exactly one place\" -- matches a count recomputed from the "
                                 "artifacts",
        "table_renders": "every table in the source reaches the LaTeX as a table, with at "
                         "least one row separator per source row",
        "arena_consistency": "every row of section 3.2's evidence table names an arena and an "
                             "n_independent that the section owning that claim also states",
        "restatement": "no sentence restates a quantity another section owns -- no numeral is "
                       "typed into the slot a substituted one fills elsewhere, and no section "
                       "prints two different quantities as the same numeral",
    }
    _missing = [k for k in _kinds if k not in _blurb]
    assert not _missing, f"check kinds with no appendix D description: {_missing}"
    put("cc_kind_list",
        ", ".join(f"*{k}* ({_blurb[k]})" for k in _kinds[:-1])
        + f", and *{_kinds[-1]}* ({_blurb[_kinds[-1]]})",
        "results/comparative_claims.json")
    put("diff_terms", dif.get("n_terms", 7), "results/step4_3_differential.json")
    t5d = J("task5_differential.json")
    import re as _re
    _m = _re.search(r'"max_abs_diff_full_rollout":\s*([0-9.eE+-]+)', json.dumps(t5d))
    th = J("task3_hardening.json")
    zd = th["3c_zero_delta"]
    _k = next((k for k in zd if isinstance(zd[k], (int, float)) and 0 < zd[k] < 1e-5), None)
    put("zero_delta_resid", f"{zd[_k]:.3e}" if _k else "n/a", "results/task3_hardening.json")
    ov = J("step4_4_overfit_b32lr1e3.json")
    put("overfit_reduction", f'{ov["first"]["state"] / ov["last"]["state"]:,.0f}',
        "results/step4_4_overfit_b32lr1e3.json")
    put("wiring_max_diff", f"{float(_m.group(1)):.3e}" if _m else "0.000e+00",
        "results/task5_differential.json")
    put("diff_grad_max", f'{dif["grad"]["fixed"]["worst_max_abs"]:.3e}',
        "results/step4_3_differential.json")
    put("diff_n_params", dif["grad"]["fixed"]["n_params"], "results/step4_3_differential.json")
    # "agreeing within X%": derived, not asserted
    a = t5["q4"]["A"]["implied_iters"]; b = t5["q4"]["B"]["implied_iters"]
    pooled = s6["collapse"]["iters_to_checkpoint"]
    put("implied_spread_pct", f'{100*(max(a,b,pooled)-min(a,b,pooled))/min(a,b,pooled):.1f}',
        "results/task5_analysis.json + results/step6_analysis.json")

    # --- run inventory -----------------------------------------------------
    # Counted from the COMMITTED run artifacts, not from a listing of runs/.
    # runs/ is gitignored, so in a clean clone the listing is empty and this
    # silently became 0 -- building a paper that said "Across 0 runs the collapse
    # is linear". Same failure as n_defects (M-36): a derived number whose source
    # can vanish without the derivation failing. The assert makes it fail loudly.
    runs_all = sorted(glob.glob("results/step5_arm*.json"))
    assert runs_all, "no results/step5_arm*.json -- cannot count training runs"

    # M-49 added five runs at a REDUCED hidden width, and every consumer of this
    # glob is a claim about the released architecture: §6.3's "the collapse rate
    # is nearly identical across runs", the run table a reader is invited to
    # count, the sigma-collapse rate fits. A different architecture entering any
    # of those through a glob is silent contamination of a headline statistic,
    # and nothing could have caught it because the width was recorded nowhere in
    # the run artifact. It is recorded now (scripts/step5_train.py).
    #
    # Runs written before that change carry no width. They are all at the
    # released width -- --hidden did not exist -- and that is asserted rather
    # than assumed: a run with no recorded width must also carry no M-49 tag.
    _released_w = R.load_reference_config(R.repo_paths()["lite"])[
        "architecture_config"]["rnn_hidden_size"]

    def _width(path):
        h = json.load(open(path)).get("hyperparameters", {})
        w = h.get("rnn_hidden_size")
        if w is None:
            assert "_m49" not in path, (
                f"{path} carries an M-49 tag and no recorded width; it cannot be "
                f"assumed to be the released architecture")
            return _released_w
        return int(w)

    runs = [f for f in runs_all if _width(f) == _released_w]
    runs_offwidth = [f for f in runs_all if _width(f) != _released_w]
    assert runs, "no runs at the released architecture width"
    put("n_runs", len(runs), "results/step5_arm*.json")
    put("n_runs_offwidth", len(runs_offwidth), "results/step5_arm*.json")
    put("released_width", _released_w, "the reference architecture_config")
    put("n_entries", len(subprocess.run(
        ["grep", "-c", "^### [A-Z]-", "FINDINGS_LEDGER.md"],
        capture_output=True, text=True).stdout.strip() or "0") and int(subprocess.run(
        ["grep", "-c", "^### [A-Z]-", "FINDINGS_LEDGER.md"],
        capture_output=True, text=True).stdout.strip()), "FINDINGS_LEDGER.md")

    # Pre-registration lead times, from the figure's own recorded values, so the
    # paragraph in §7 that is ABOUT discipline does not itself contain typed numbers.
    pf = os.path.join(R.RESULTS, "paper_figures.json")
    if os.path.exists(pf):
        f4 = json.load(open(pf)).get("fig4", {})
        def fmt(h):
            return f"{h*60:.0f} minutes" if abs(h) < 1 else f"{h:.1f} hours"
        keymap = {"M-16 the A/B decision rule": "lead_m16",
                  "flip pattern interpretation": "lead_flip",
                  "M-22 difficulty-bias rule": "lead_m22",
                  "M-23 long-horizon rule": "lead_m23",
                  "Task 3 duplication rule": "lead_task3"}
        for label, key in keymap.items():
            if label in f4:
                put(key, fmt(abs(f4[label]["lead_hours"])), "results/paper_figures.json")

    # Retractions, counted rather than asserted. An earlier draft said "four" and the
    # ledger had six by then -- exactly the drift this indirection exists to stop.
    led = open("FINDINGS_LEDGER.md").read()
    TPL = open("PAPER.template.md").read()
    sup = re.findall(r"^### (S-\d+) ", led, re.M)
    retr = []
    for sid in sup:
        blk = led[led.index("### " + sid + " "):]
        blk = blk[:blk.find("\n### ", 5)] if "\n### " in blk[5:] else blk
        m = re.search(r"^\*\*Retracts\*\* (.+)$", blk, re.M)
        if m and not m.group(1).lstrip().startswith("\u2014"):
            retr.append(sid)
    # Framing retractions split two ways. S-01..S-07 withdraw early hypotheses that
    # were never numbered claims -- routine housekeeping. S-12 and S-15 withdraw
    # something the paper had asserted (a pre-registration status; an inference
    # from counts to P-values). The abstract and section 8 count the second group
    # separately, and an earlier draft typed "a seventh" for what is now two.
    fram = []
    for sid in sup:
        blk = led[led.index("### " + sid + " "):]
        blk = blk[:blk.find("\n### ", 5)] if "\n### " in blk[5:] else blk
        m = re.search(r"^\*\*Retracts\*\* (.+)$", blk, re.M)
        if m and m.group(1).lstrip().startswith("\u2014") \
                and "early hypothesis" not in m.group(1):
            fram.append(sid)
    put("n_superseded", len(sup), "FINDINGS_LEDGER.md")
    put("n_retractions", len(retr), "FINDINGS_LEDGER.md")
    put("n_retract_framing", len(fram), "FINDINGS_LEDGER.md")
    # Section 8 and appendix D each ENUMERATED the framing retractions in prose
    # ("the claim that a pre-registration was pre-registered, and the binomial
    # inference of 6.6"). Two more were entered by the second revision and a
    # third recorded a narrowing the paper had made without ever entering it, so
    # a typed enumeration beside a generated count is a count-consistency defect
    # waiting to happen. The list is built from the entry titles.
    def _title(sid):
        blk = led[led.index("### " + sid + " "):]
        line = blk[:blk.find("\n")]
        t = line.split("—", 1)[1] if "—" in line else line
        return t.split("·")[0].strip().strip('"')
    _ftitles = [_title(x) for x in fram]
    put("n_retract_framing_list",
        "".join(f"\n\n- **{t}** (`{sid}`)." for sid, t in zip(fram, _ftitles)),
        "FINDINGS_LEDGER.md")
    put("n_retract_framing_ids", ", ".join(f"`{x}`" for x in fram), "FINDINGS_LEDGER.md")
    put("n_retractions_word", WORDS.get(len(retr), str(len(retr))), "FINDINGS_LEDGER.md")
    put("n_retractions_lower", WORDS.get(len(retr), str(len(retr))).lower(), "FINDINGS_LEDGER.md")
    put("n_retractions_word_lower", WORDS.get(len(retr), str(len(retr))).lower(), "FINDINGS_LEDGER.md")
    put("n_retract_framing_word", WORDS.get(len(fram), str(len(fram))).lower(), "FINDINGS_LEDGER.md")
    put("n_retract_framing_word_cap", WORDS.get(len(fram), str(len(fram))), "FINDINGS_LEDGER.md")
    ORD = {1: "a seventh", 2: "two further", 3: "three further", 4: "four further"}
    put("n_retract_framing_phrase", ORD.get(len(fram), f"{len(fram)} further"), "FINDINGS_LEDGER.md")
    put("n_retract_total", len(retr) + len(fram), "FINDINGS_LEDGER.md")

    # B4/B5. Which review entered which framing retraction, from git rather than
    # from memory.
    #
    # §8 said "the second pre-submission review entered three more framing
    # retractions"; appendix D said "The last four were entered by the second
    # pre-submission review", and enumerated four. Both sentences restate a
    # quantity that neither of them computes, and one of them was wrong: the
    # commit that entered S-16, S-17, S-18 and S-19 is a single commit and it
    # entered four.
    #
    # A framing retraction's COHORT is the commit that first introduced its
    # ledger heading. Cohorts are ordered by commit time; the last cohort is the
    # most recent review's, which is what both sentences are about.
    _sha = {}
    for sid in fram:
        _out = subprocess.run(
            ["git", "log", "--format=%H\t%ct", "-S", "### " + sid + " \u2014",
             "--", "FINDINGS_LEDGER.md"],
            capture_output=True, text=True).stdout.strip().split("\n")
        assert _out and _out[-1], f"no commit introduces the ledger heading for {sid}"
        _h, _t = _out[-1].split("\t")
        _sha[sid] = (_h, int(_t))
    _cohorts = {}
    for sid, (h, t) in _sha.items():
        _cohorts.setdefault(h, {"t": t, "ids": []})["ids"].append(sid)
    _ordered = sorted(_cohorts.values(), key=lambda c: c["t"])
    _last = _ordered[-1]["ids"]
    _earlier = [x for c in _ordered[:-1] for x in c["ids"]]
    put("n_framing_last_cohort", len(_last), "FINDINGS_LEDGER.md + git log")
    put("n_framing_last_cohort_word", WORDS.get(len(_last), str(len(_last))).lower(),
        "FINDINGS_LEDGER.md + git log")
    put("n_framing_before_last", len(_earlier), "FINDINGS_LEDGER.md + git log")
    put("n_framing_before_last_word", WORDS.get(len(_earlier), str(len(_earlier))).lower(),
        "FINDINGS_LEDGER.md + git log")
    put("n_framing_cohorts", len(_ordered), "FINDINGS_LEDGER.md + git log")
    put("framing_last_cohort_ids", ", ".join(f"`{x}`" for x in sorted(_last)),
        "FINDINGS_LEDGER.md + git log")
    # The last cohort's entries, less the final one, which appendix D describes
    # separately because it is different in kind: "`S-16`, `S-17` and `S-18` are
    # sentences of the 24 August draft that were false. `S-19` is different..."
    put("framing_last_cohort_ids_but_last",
        ", ".join(f"`{x}`" for x in sorted(_last)[:-1][:-1])
        + " and " + f"`{sorted(_last)[:-1][-1]}`" if len(_last) > 2 else "",
        "FINDINGS_LEDGER.md + git log")
    put("framing_last_cohort_final", f"`{sorted(_last)[-1]}`",
        "FINDINGS_LEDGER.md + git log")
    assert len(_last) + len(_earlier) == len(fram)

    # E2 -- the residual factor between the implied iteration count and the one
    # the checkpoint's author recalls. The abstract said only "not reachable",
    # which reads as nearly reconciled; it is a factor of ~30.
    _rec = 5000        # docs/E4_AUTHOR_CONTACT.md: checkpoint tag, and the count
                       # the author recalls in his reply of 2026-08-21
    # Use the SAME estimate the body leads with (step6_analysis), not the
    # task5 refits. Quoting 158,000 in the abstract against section 7's 153,270
    # put two numbers for one quantity in one document; the refits are
    # corroboration and section 7 reports them as such.
    _imp = J("step6_analysis.json")["collapse"]["iters_to_checkpoint"]
    put("unreach_recalled_iters", f"{_rec:,}", "docs/E4_AUTHOR_CONTACT.md")
    put("unreach_factor", f"{_imp / _rec:.0f}", "results/step6_analysis.json")

    # --- D3: the ensemble-5 arms (M-43) ------------------------------------
    E5 = J("task_d3_ens5.json")
    P5 = J("task_d3b_ens5_power.json")
    put("e5_nind", E5["design"]["n_independent"], "results/task_d3_ens5.json")
    put("e5_seeds", len(E5["design"]["seeds"]), "results/task_d3_ens5.json")
    put("e5_verdict", E5["m43_verdict"]["verdict"], "results/task_d3_ens5.json")
    put("e5_leads_all", str(E5["m43_verdict"]["leads_at_every_horizon"]).lower(),
        "results/task_d3_ens5.json")
    put("e5_n_excl", E5["m43_verdict"]["n_excluding_zero"], "results/task_d3_ens5.json")
    put("e5_n_horizons", len(E5["m43_verdict"]["horizons_tested"]), "results/task_d3_ens5.json")
    _cells = [(h, r) for h in ("8", "32", "128", "368")
              for r in E5["governing"][h]["per_seed"]]
    put("e5_lead_cells", sum(1 for _, r in _cells if r["r_disagreement"] > r["r_index"]),
        "results/task_d3_ens5.json")
    put("e5_total_cells", len(_cells), "results/task_d3_ens5.json")
    put("e5_diff_lo", f'{min(r["paired_diff"] for _, r in _cells):+.3f}',
        "results/task_d3_ens5.json")
    put("e5_diff_hi", f'{max(r["paired_diff"] for _, r in _cells):+.3f}',
        "results/task_d3_ens5.json")
    for h in (1, 8, 32, 100, 128, 368):
        c = E5["calibration"][str(h)]
        put(f"e5_ratio_h{h}", f'{c["mean_ratio"]:.1f}', "results/task_d3_ens5.json")
        put(f"e5_cov1_h{h}", f'{100*c["mean_cov1"]:.2f}', "results/task_d3_ens5.json")
        put(f"e5_cov2_h{h}", f'{100*c["mean_cov2"]:.2f}', "results/task_d3_ens5.json")
        put(f"e5_npos_h{h}", f'{c["mean_npos"]:.1f}', "results/task_d3_ens5.json")
        put(f"e5_ratio_ci_h{h}", f'{c["ratio_ci"][0]:.1f}, {c["ratio_ci"][1]:.1f}',
            "results/task_d3_ens5.json")
        put(f"e5_cov1_ci_h{h}", f'{100*c["cov1_ci"][0]:.2f}, {100*c["cov1_ci"][1]:.2f}',
            "results/task_d3_ens5.json")
        put(f"e5_cov2_ci_h{h}", f'{100*c["cov2_ci"][0]:.2f}, {100*c["cov2_ci"][1]:.2f}',
            "results/task_d3_ens5.json")
    put("e5_collapse", f'{E5["collapse"]["ens5_mean"]:.4e}', "results/task_d3_ens5.json")
    put("e5_collapse_ens1", f'{E5["collapse"]["ens1_mean"]:.4e}', "results/task_d3_ens5.json")
    put("e5_collapse_pct", f'{100*E5["collapse"]["relative_difference"]:+.2f}',
        "results/task_d3_ens5.json")
    _cov = [v["cov_across_batch"] for v in E5["input_dependence"].values()]
    _sg = [v["sigma_growth_1_to_8"] for v in E5["input_dependence"].values()]
    _eg = [v["err_growth_1_to_8"] for v in E5["input_dependence"].values()]
    put("e5_cov_lo", f"{min(_cov):.3f}", "results/task_d3_ens5.json")
    put("e5_cov_hi", f"{max(_cov):.3f}", "results/task_d3_ens5.json")
    put("e5_sg_lo", f"{min(_sg):.2f}", "results/task_d3_ens5.json")
    put("e5_sg_hi", f"{max(_sg):.2f}", "results/task_d3_ens5.json")
    put("e5_eg_lo", f"{min(_eg):.1f}", "results/task_d3_ens5.json")
    put("e5_eg_hi", f"{max(_eg):.1f}", "results/task_d3_ens5.json")
    for h in (8, 368):
        a_ = E5["accuracy_vs_ens1"][str(h)]
        put(f"e5_acc_h{h}", f'{a_["ens5_over_ens1"]:.3f}', "results/task_d3_ens5.json")
    # power and the in-sample companion
    put("e5_power_mean", f'{100*P5["power_summary"]["mean_power_at_n4"]:.0f}',
        "results/task_d3b_ens5_power.json")
    put("e5_power_worst", f'{100*P5["power_summary"]["worst_power"]:.0f}',
        "results/task_d3b_ens5_power.json")
    put("e5_power_worst_h", P5["power_summary"]["worst_horizon"],
        "results/task_d3b_ens5_power.json")
    put("e5_comp_nind", P5["design"]["n_independent"], "results/task_d3b_ens5_power.json")
    put("e5_comp_excl", P5["companion_summary"]["n_excluding_zero"],
        "results/task_d3b_ens5_power.json")
    put("e5_comp_n", P5["companion_summary"]["n_horizons"], "results/task_d3b_ens5_power.json")
    put("e5_comp_pass", str(P5["companion_summary"]["would_have_passed_m43"]).lower(),
        "results/task_d3b_ens5_power.json")
    _ci = P5["power_summary"]["in_sample_effect_range"]
    _co = P5["power_summary"]["out_of_sample_effect_range"]
    put("e5_eff_ins", f"{_ci[0]:+.3f} to {_ci[1]:+.3f}", "results/task_d3b_ens5_power.json")
    put("e5_eff_oos", f"{_co[0]:+.3f} to {_co[1]:+.3f}", "results/task_d3b_ens5_power.json")

    # --- C2: the data budget ----------------------------------------------
    C2 = J("task_c2_data_budget.json")
    put("c2_trans", f'{C2["ours"]["distinct_transitions"]:,}', "results/task_c2_data_budget.json")
    put("c2_rows", f'{C2["ours"]["rows_in_training_episodes"]:,}',
        "results/task_c2_data_budget.json")
    put("c2_windows", f'{C2["ours"]["training_windows"]:,}', "results/task_c2_data_budget.json")
    put("c2_bounds", C2["ours"]["boundaries_excluded"], "results/task_c2_data_budget.json")
    put("c2_ref", f'{C2["reference"]["value"]:,}', "results/task_c2_data_budget.json")
    put("c2_ratio", f'{C2["ratio_reference_over_ours"]:,.0f}', "results/task_c2_data_budget.json")
    put("c2_pct", f'{100*C2["ours_as_fraction_of_reference"]:.3f}',
        "results/task_c2_data_budget.json")
    put("c2_draws", f'{C2["ours"]["window_draws_per_run"]:,}', "results/task_c2_data_budget.json")

    # --- D1/D2/D4: the released checkpoint at n_independent = 20 -----------
    D = J("task_d_nind20.json")
    put("d1n_nind", D["design"]["n_independent"], "results/task_d_nind20.json")
    put("d1n_ntraj", D["design"]["trajectories"], "results/task_d_nind20.json")
    put("d1n_eps", len(D["design"]["episodes"]), "results/task_d_nind20.json")
    for h in (1, 8, 32, 100, 128, 368):
        r = D["d1_by_horizon"][str(h)]
        for q, tg in (("aleatoric", "alea"), ("epistemic", "epi"), ("total", "tot")):
            m = r[q]
            rr = m["ratio_err_over_sigma"]
            put(f"d1n_{tg}_ratio_h{h}", f"{rr:,.0f}" if rr >= 100 else f"{rr:.1f}",
                "results/task_d_nind20.json")
            put(f"d1n_{tg}_cov1_h{h}", f'{100*m["coverage_pm1"]:.2f}',
                "results/task_d_nind20.json")
            _rc = m["ratio_err_over_sigma_ci"]
            _f = (lambda v: f"{v:,.0f}") if rr >= 100 else (lambda v: f"{v:.1f}")
            put(f"d1n_{tg}_ratio_ci_h{h}", f"{_f(_rc[0])}, {_f(_rc[1])}",
                "results/task_d_nind20.json")
            for _q, _k in (("cov1", "coverage_pm1_ci"), ("cov2", "coverage_pm2_ci")):
                _cc = m[_k]
                put(f"d1n_{tg}_{_q}_ci_h{h}", f"{100*_cc[0]:.2f}, {100*_cc[1]:.2f}",
                    "results/task_d_nind20.json")
            put(f"d1n_{tg}_cov2_h{h}", f'{100*m["coverage_pm2"]:.2f}',
                "results/task_d_nind20.json")
            put(f"d1n_{tg}_npos_h{h}", m["n_positive"], "results/task_d_nind20.json")
            put(f"d1n_{tg}_ndim_h{h}", m["n_finite_corr"], "results/task_d_nind20.json")
            put(f"d1n_{tg}_r_h{h}", f'{m["corr_mean"]:+.3f}', "results/task_d_nind20.json")
    _e1, _e368 = D["d1_by_horizon"]["1"], D["d1_by_horizon"]["368"]
    # A5: quote the ratio itself rather than an orders-of-magnitude phrase. It is
    # exact and generated; "two orders" and "nearly three orders" disagreed with
    # each other across the abstract and section 12 while both described this value.
    #
    # C1(rev2): it is HORIZON-DEPENDENT, and only the h=368 form existed, so the
    # abstract, 6.2 and 13 all paired an h=368 ratio (600x) with an h=100 figure in
    # the same sentence. The ratio at the deployment horizon is 350x. Generated at
    # every horizon so that a sentence can quote the one it is scoped to.
    for _h in (1, 8, 32, 100, 128, 368):
        _r = D["d1_by_horizon"][str(_h)]
        put(f"d1n_epi_over_alea_h{_h}",
            f'{_r["aleatoric"]["ratio_err_over_sigma"]/_r["epistemic"]["ratio_err_over_sigma"]:,.0f}',
            "results/task_d_nind20.json")

    # D2 -- the forecast-index baseline
    #
    # C1(rev2): h=100 was absent from this table while 3.1 declares it part of the
    # grid and the abstract is anchored to it. The rollouts already carried it.
    for h in ("1", "8", "32", "100", "128", "368", "all"):
        r = D["d2_forecast_index"][h]
        k = h if h == "all" else f"h{h}"
        for nm, tg in (("r_index", "idx"), ("r_epistemic", "epi"), ("r_partial", "par")):
            v = r[nm]
            put(f"d2b_{tg}_{k}", "n/a" if v is None else f"{v:+.3f}",
                "results/task_d_nind20.json")
        for nm, tg in (("index", "idx"), ("epistemic", "epi"), ("partial", "par")):
            c = r["ci"][nm]
            put(f"d2b_{tg}_ci_{k}",
                "n/a" if c["lo"] is None else f'[{c["lo"]:+.3f}, {c["hi"]:+.3f}]',
                "results/task_d_nind20.json")
    # A2: the PAIRED difference r(disagreement) - r(index), bootstrapped over whole
    # trajectories with both correlations recomputed inside each draw. Replaces the
    # marginal-overlap comparison, which is not the right test for two correlations
    # measured on the same trajectories -- and which the artifact shows is false at
    # h=128 anyway.
    for h in ("8", "32", "100", "128", "368", "all"):
        r = D["d2_forecast_index"][h]
        k = h if h == "all" else f"h{h}"
        put(f"d2p_diff_{k}", f'{r["paired_diff"]:+.3f}', "results/task_d_nind20.json")
        put(f"d2p_ci_{k}", f'[{r["paired_ci_lo"]:+.3f}, {r["paired_ci_hi"]:+.3f}]',
            "results/task_d_nind20.json")
    # The horizons at which the forecast index is DEFINED. h=1 has one forecast
    # step, so the index is constant there and its correlation does not exist.
    # This set is fixed by M-43's own text and must NOT follow the reporting grid:
    # moving it would retroactively change a discharged pre-registration. It is
    # read from the artifact -- where task_d3_ens5.py records it as
    # index_defined_at -- rather than typed here, so it is derived AND fixed.
    _IDX = [str(h) for h in J("task_d3_ens5.json")["design"]["index_defined_at"]]
    assert all(h in D["d2_forecast_index"] for h in _IDX), \
        "an index-defined horizon is missing from the n=20 table"
    # ...and the RELEASED CHECKPOINT's own table follows the reporting grid, which
    # now carries h=100. These are two different sets and were one key. Keeping
    # them one would have made "N of 4" sit under a five-row table, or -- worse --
    # silently widened a discharged pre-registration to a horizon it never named.
    # Derived from the artifact both times: a horizon is in the released
    # checkpoint's set exactly when its index correlation exists.
    _IDX_REL = [h for h in ("1", "8", "32", "100", "128", "368")
                if D["d2_forecast_index"][h]["r_index"] is not None]
    assert set(_IDX) <= set(_IDX_REL), \
        "M-43's index_defined_at is not a subset of the reporting grid"
    _sep = [h for h in _IDX_REL if D["d2_forecast_index"][h]["paired_excludes_zero"]]
    _ovl = [h for h in _IDX_REL if D["d2_forecast_index"][h]["marginal_ci_overlap"]]
    put("d2p_n_separating", len(_sep), "results/task_d_nind20.json")
    put("d2p_n_horizons", len(_IDX_REL), "results/task_d_nind20.json")
    put("d2p_overlap_h", " and ".join(f"h={x}" for x in _ovl) or "none",
        "results/task_d_nind20.json")
    put("d2p_n_overlap", len(_ovl), "results/task_d_nind20.json")
    _narrow = min(_IDX_REL,
                  key=lambda h: D["d2_forecast_index"][h]["paired_ci_lo"])
    put("d2p_narrowest_h", _narrow, "results/task_d_nind20.json")
    put("d2p_narrowest_lo", f'{D["d2_forecast_index"][_narrow]["paired_ci_lo"]:+.3f}',
        "results/task_d_nind20.json")
    # B: h=1, the strongest correlation anywhere in this project's data
    _h1 = D["d2_forecast_index"]["1"]
    put("d2_epi_h1", f'{_h1["r_epistemic"]:+.3f}', "results/task_d_nind20.json")
    put("d2_epi_ci_h1", f'[{_h1["ci"]["epistemic"]["lo"]:+.3f}, '
                        f'{_h1["ci"]["epistemic"]["hi"]:+.3f}]',
        "results/task_d_nind20.json")
    _dw = [h for h in _IDX_REL if D["d2_forecast_index"][h]["index_wins"]]
    put("d2b_n_index_wins", len(_dw), "results/task_d_nind20.json")
    put("d2b_n_horizons_tested", len(_IDX_REL), "results/task_d_nind20.json")
    # The horizon at which the counter is strongest, so 6.7's sentence naming it
    # cannot go stale the way "at h=128 the intervals overlap" did when a second
    # overlapping horizon appeared.
    _idxmax = max(_IDX_REL, key=lambda h: D["d2_forecast_index"][h]["r_index"])
    put("d2b_idx_strongest_h", f"h={_idxmax}", "results/task_d_nind20.json")
    _all = D["d2_forecast_index"]["all"]
    put("d2b_shrink_all", f'{_all["r_epistemic"] - _all["r_partial"]:+.3f}',
        "results/task_d_nind20.json")
    put("d2b_shrink_all_abs", f'{abs(_all["r_epistemic"] - _all["r_partial"]):.3f}',
        "results/task_d_nind20.json")

    # D4 -- the penalty correlation, with an interval and an n at last
    _p4 = D["d4_penalty"]
    put("d4_r", f'{_p4["corr_with_total_abs_error"]:+.3f}', "results/task_d_nind20.json")
    put("d4_ci", f'[{_p4["ci_lo"]:+.3f}, {_p4["ci_hi"]:+.3f}]', "results/task_d_nind20.json")
    put("d4_nind", _p4["n_independent"], "results/task_d_nind20.json")
    put("d4_npoints", f'{_p4["n_points"]:,}', "results/task_d_nind20.json")

    # --- D3: the per-horizon scalar ---------------------------------------
    D3 = J("task_d3_perhorizon.json")
    for q, tg in (("aleatoric", "ale"), ("epistemic", "epi")):
        v = D3["quantities"][q]["verdict"]
        put(f"d3_{tg}_ok", v["per_horizon_cells_calibrated"], "results/task_d3_perhorizon.json")
        put(f"d3_{tg}_cells", v["n_cells"], "results/task_d3_perhorizon.json")
        put(f"d3_{tg}_const_ok", v["constant_cells_calibrated"],
            "results/task_d3_perhorizon.json")
        put(f"d3_{tg}_cspread", f'{v["c_ratio_max_over_min"]:.3g}',
            "results/task_d3_perhorizon.json")
        put(f"d3_{tg}_worst_h", v["worst_cell"]["h"], "results/task_d3_perhorizon.json")
        put(f"d3_{tg}_worst_cov", f'{100*v["worst_cell"]["coverage_after"]:.2f}',
            "results/task_d3_perhorizon.json")
        _cs = sorted(f["c"] for f in D3["quantities"][q]["fits"])
        put(f"d3_{tg}_c_lo", f"{_cs[0]:.4g}", "results/task_d3_perhorizon.json")
        put(f"d3_{tg}_c_hi", f"{_cs[-1]:.4g}", "results/task_d3_perhorizon.json")
    put("d3_target", f'{100*D3["target_coverage"]:.2f}', "results/task_d3_perhorizon.json")
    # A4: the worst cell over ALL held-out cells, not the worst within one quantity.
    # The per-quantity verdict blocks each name their own worst; the paper quoted
    # the epistemic one as if it were the overall worst, and it is third.
    _all_cells = [(abs(f["coverage_after"] - D3["target_coverage"]), q, f)
                  for q in D3["quantities"]
                  for f in D3["quantities"][q]["fits"]]
    _all_cells.sort(key=lambda x: -x[0])
    _w = _all_cells[0]
    put("d3_ncells_all", len(_all_cells), "results/task_d3_perhorizon.json")
    put("d3_worst_q", _w[1], "results/task_d3_perhorizon.json")
    put("d3_worst_h", _w[2]["h"], "results/task_d3_perhorizon.json")
    put("d3_worst_ep", _w[2]["fit_episode"], "results/task_d3_perhorizon.json")
    put("d3_worst_cov", f'{100*_w[2]["coverage_after"]:.2f}', "results/task_d3_perhorizon.json")
    put("d3_worst_dev", f'{100*_w[0]:.2f}', "results/task_d3_perhorizon.json")
    put("d3_second_cov", f'{100*_all_cells[1][2]["coverage_after"]:.2f}',
        "results/task_d3_perhorizon.json")
    # C3(rev2), 3.1. 6.8 said the two largest deviations were "both at h=100 on the
    # aleatoric term, in opposite directions". Neither half was true: the second
    # largest is at h=128, and both sit ABOVE the target. The sentence is now
    # assembled from the artifact -- horizon, quantity and side -- so the only way
    # to state it wrongly is for the artifact to be wrong.
    _sd = _all_cells[1]
    put("d3_second_h", _sd[2]["h"], "results/task_d3_perhorizon.json")
    put("d3_second_q", _sd[1], "results/task_d3_perhorizon.json")
    put("d3_second_dev", f'{100*_sd[0]:.2f}', "results/task_d3_perhorizon.json")
    _side = lambda c: "above" if c["coverage_after"] > D3["target_coverage"] else "below"
    put("d3_worst_side", _side(_w[2]), "results/task_d3_perhorizon.json")
    put("d3_second_side", _side(_sd[2]), "results/task_d3_perhorizon.json")
    put("d3_top2_same_side",
        "both above" if _side(_w[2]) == _side(_sd[2]) == "above" else
        ("both below" if _side(_w[2]) == _side(_sd[2]) == "below" else
         "in opposite directions"),
        "results/task_d3_perhorizon.json")
    _tp = D3["design"]["trajectories_per_episode"]
    put("d3_neps", len(_tp), "results/task_d3_perhorizon.json")
    put("d3_nind_fit", min(_tp.values()), "results/task_d3_perhorizon.json")
    put("d3_nind_tot", sum(_tp.values()), "results/task_d3_perhorizon.json")
    # T2.4 -- the "N of N held-out cells" count is horizons x fold directions on
    # the SAME trajectories, not N independent successes. The caption states the
    # decomposition, so the horizon count has to be derived rather than typed.
    _d3h = sorted({f["h"] for f in D3["quantities"]["epistemic"]["fits"]})
    put("d3_nhoriz", len(_d3h), "results/task_d3_perhorizon.json")

    # --- D3 cross-model: does 6.8's lookup table transfer between MODELS? ----
    # M-69, pre-registered in fad7db7 before any of this existed. Section 6.8's
    # own values are read from its own artifact above and are untouched here;
    # everything below comes from the new one.
    DX = J("task_d3_cross_model.json")
    P4 = J("p4_transfer_power.json")
    _vb = DX["verdict"]["both_directions"]
    put("d3x_verdict", _vb["verdict"], "results/task_d3_cross_model.json")
    put("d3x_branch", _vb["branch"], "results/task_d3_cross_model.json")
    put("d3x_ncells", _vb["n_cells"], "results/task_d3_cross_model.json")
    put("d3x_n_out", _vb["n_intervals_outside_band"], "results/task_d3_cross_model.json")
    put("d3x_n_in", _vb["n_intervals_inside_band"], "results/task_d3_cross_model.json")
    put("d3x_n_strad", _vb["n_intervals_straddling_edge"],
        "results/task_d3_cross_model.json")
    put("d3x_worst_delta", f'{_vb["largest_abs_delta_pts"]:.1f}',
        "results/task_d3_cross_model.json")
    for _d, _tg in (("armA_to_released", "a2r"), ("released_to_armA", "r2a")):
        put(f"d3x_verdict_{_tg}", DX["verdict"][_d]["verdict"],
            "results/task_d3_cross_model.json")
        put(f"d3x_n_out_{_tg}", DX["verdict"][_d]["n_intervals_outside_band"],
            "results/task_d3_cross_model.json")
        put(f"d3x_ncells_{_tg}", DX["verdict"][_d]["n_cells"],
            "results/task_d3_cross_model.json")
    for q, tg in (("aleatoric", "ale"), ("epistemic", "epi")):
        put(f"d3x_{tg}_ok", DX["absolute_column"][q]["cells_within_tolerance"],
            "results/task_d3_cross_model.json")
        put(f"d3x_{tg}_cells", DX["absolute_column"][q]["n_cells"],
            "results/task_d3_cross_model.json")
        put(f"d3x_own_{tg}_ok", DX["armA_own_model"][q]["cells_within_tolerance"],
            "results/task_d3_cross_model.json")
        put(f"d3x_own_{tg}_cells", DX["armA_own_model"][q]["n_cells"],
            "results/task_d3_cross_model.json")
    put("d3x_nseeds", len(DX["seeds"]), "results/task_d3_cross_model.json")
    put("d3x_ens", DX["design"]["ensemble"], "results/task_d3_cross_model.json")
    put("d3x_nind", DX["design"]["n_independent"], "results/task_d3_cross_model.json")
    put("d3x_band", f'{DX["band_pts"]:.0f}', "results/task_d3_cross_model.json")
    put("d3x_ratio_lo", f'{DX["multipliers"]["ratio_min"]:.3g}',
        "results/task_d3_cross_model.json")
    put("d3x_ratio_hi", f'{DX["multipliers"]["ratio_max"]:.3g}',
        "results/task_d3_cross_model.json")
    # The MDE the two columns are read against. The paired one governs; the
    # absolute one does not, and its own figures are why.
    _pm = [v for q in P4["paired_binding_mde_pts"].values() for v in q.values()]
    _um = [v for q in P4["binding_mde_pts"].values() for v in q.values()]
    put("d3x_pmde_hi", f"{max(_pm):.2f}", "results/p4_transfer_power.json")
    put("d3x_umde_lo", f"{min(_um):.2f}", "results/p4_transfer_power.json")
    put("d3x_umde_hi", f"{max(_um):.2f}", "results/p4_transfer_power.json")
    put("d3x_tol_res", P4["summary"]["quantity_horizon_pairs_where_tolerance_resolvable"],
        "results/p4_transfer_power.json")
    put("d3x_tol_pairs", P4["summary"]["quantity_horizon_pairs"],
        "results/p4_transfer_power.json")

    # The lessons section opens by counting its own lessons. It said "Four" while
    # carrying a different number after Part D added two; count the bold leads
    # instead.
    #
    # Bound to the section's TITLE, not its number — exactly as n_defects is, and
    # for exactly the same reason. This used to split on the literal "## 9.", and
    # when Related Work was inserted and the section moved to 10, that split
    # silently returned the METHOD section instead and put its bold-lead count in
    # the lessons sentence. It was caught by the same comment n_defects carries,
    # which is the argument for writing such comments down.
    _lsec = re.search(r"^## (\d+)\. Actionable lessons\s*$", TPL, re.M)
    assert _lsec, "no section titled 'Actionable lessons'"
    _s9 = TPL[_lsec.end():]
    _s9 = _s9[:_s9.find("\n## ")] if "\n## " in _s9 else _s9
    _n9 = len(re.findall(r"^\*\*[A-Z]", _s9, re.M))
    assert _n9 > 0, "the lessons section has no bold-led lessons"
    put("n_lessons", _n9, "PAPER.template.md, Actionable lessons")
    put("n_lessons_word", WORDS.get(_n9, str(_n9)), "PAPER.template.md, Actionable lessons")

    # E4 -- appendix B claimed "roughly 22 hours" for a full run. Recomputed from
    # the top-level wall_clock_s of every training run. (The per-checkpoint
    # wall_clock_s inside `collapse` is elapsed-so-far, not per-interval; summing
    # those inflates the total about 15-fold.)
    import glob as _glob
    _runs = []
    _runs_m49 = []
    for _f in sorted(_glob.glob("results/step5_*.json")):
        _d = json.load(open(_f))
        if _d.get("wall_clock_s"):
            _rec = (_d["hyperparameters"]["iterations"], _d["wall_clock_s"])
            _runs.append(_rec)
            # The CPU budget DOES include these -- they are hours this project
            # spent -- but appendix B says how many of them are the capacity-
            # matched arm rather than the main experiment, so the budget and the
            # experiment are not confused for each other.
            if _d["hyperparameters"].get("rnn_hidden_size", _released_w) != _released_w:
                _runs_m49.append(_rec)
    _t = sum(w for _, w in _runs)
    _t10 = sum(w for i, w in _runs if i == 10000)
    put("rt_runs", len(_runs), "results/step5_*.json")
    put("rt_runs_10k", sum(1 for i, _ in _runs if i == 10000), "results/step5_*.json")
    # C3(rev2), 3.4. These were rounded to whole hours independently, and appendix
    # B then read "46 hours ... 20 for the 6 ten-thousand-iteration runs and 27 for
    # the remaining 20". 20 + 27 = 47. Neither figure was typed and neither was
    # wrong; the presentation was. One decimal makes the parts sum to the total,
    # and the `arithmetic` check asserts that they do on every build.
    put("rt_hours", f"{_t/3600:.1f}", "results/step5_*.json")
    put("rt_hours_10k", f"{_t10/3600:.1f}", "results/step5_*.json")
    put("rt_hours_short", f"{(_t-_t10)/3600:.1f}", "results/step5_*.json")
    put("rt_runs_short", sum(1 for i, _ in _runs if i != 10000), "results/step5_*.json")
    put("rt_runs_m49", len(_runs_m49), "results/step5_*.json")
    put("rt_hours_m49", f"{sum(w for _, w in _runs_m49) / 3600:.1f}", "results/step5_*.json")
    # The capacity-matched hours are a SUBSET of the total, not a further part of
    # it, so the only arithmetic that can pin them is total = matched + released.
    # Appendix B stated the total, its iteration-length split and the matched
    # hours as three independent figures, and nothing asserted that the third sat
    # inside the first. The remainder is put here so the `arithmetic` check has
    # both parts of that partition to add up.
    # THE REMAINDER OF THE DISPLAYED TOTAL, not the rounded true remainder. The
    # paper's sentence says the two parts make the total; rounding each of the
    # three independently does not guarantee that, and once the combined arm's
    # two runs were added it stopped being true -- 1.9 + 48.0 = 49.9 against a
    # stated 49.8, an `arithmetic` failure produced by nothing but rounding. The
    # subtraction is done at the precision the paper prints, so the partition it
    # asserts holds by construction rather than by luck.
    put("rt_hours_released",
        f'{float(N["rt_hours"]["value"]) - float(N["rt_hours_m49"]["value"]):.1f}',
        "results/step5_*.json")

    # B8. Three measured quantities that were TYPED in prose, found by classifying
    # every numeral the template carries rather than by reading (see
    # scripts/typed_numeral_audit.py). "roughly 17 CPU-hours" and "about 1.2 h
    # each" describe runs whose wall clock this project records to the second, and
    # the first was not close: five ens-1 seeds at the iteration count R2 uses cost
    # about a fifth of it.
    _R2d = J("r2_independent_ensemble.json")["design"]
    _r2_iters = _R2d["iterations"]
    _r2_seeds = _R2d["independent_seeds"]
    _r2_shared = _R2d["shared_trunk_seeds"]
    _r2_added = [x for x in _r2_seeds if x not in _r2_shared]
    _seed_h = {}
    for _sd in _r2_seeds:
        _f = f"results/step5_armA_seed{_sd}.json"
        _d = json.load(open(_f))
        assert _d["hyperparameters"]["iterations"] == _r2_iters, (
            f"{_f} ran {_d['hyperparameters']['iterations']} iterations; R2's design "
            f"says {_r2_iters}, so its wall clock does not price R2's ensemble")
        _seed_h[_sd] = _d["wall_clock_s"] / 3600.0
    _mean_h = sum(_seed_h.values()) / len(_seed_h)
    put("r2_n_added", len(_r2_added), "results/r2_independent_ensemble.json")
    put("r2_n_added_word", WORDS.get(len(_r2_added), str(len(_r2_added))).lower(),
        "results/r2_independent_ensemble.json")
    put("r2_added_h", f"{sum(_seed_h[s] for s in _r2_added) / len(_r2_added):.1f}",
        "results/step5_armA_seed*.json")
    put("r2_scratch_h", f"{_mean_h * len(_r2_seeds):.1f}", "results/step5_armA_seed*.json")
    put("r2_added_h_total", f"{sum(_seed_h[s] for s in _r2_added):.1f}",
        "results/step5_armA_seed*.json")

    # Section 8 illustrated the host-dependence of step4_5_timing.json with a
    # typed anecdote ("46.5 s idle took 109.7 s under load") that appears in no
    # artifact. The file records its own across-repeat standard deviation, which
    # makes the same point and is readable from disk.
    _tm = J("step4_5_timing.json")["results"]
    _rel = {k: v["std"] / v["s_per_iter"] for k, v in _tm.items()
            if isinstance(v, dict) and v.get("s_per_iter")}
    _wk = max(_rel, key=_rel.get)
    put("time_cfgs", len(_rel), "results/step4_5_timing.json")
    put("time_rel_hi", f"{100*_rel[_wk]:.0f}", "results/step4_5_timing.json")
    put("time_rel_lo", f"{100*min(_rel.values()):.0f}", "results/step4_5_timing.json")
    put("time_worst_cfg", _wk, "results/step4_5_timing.json")
    put("rt_longest", f"{max(w for _, w in _runs)/3600:.1f}", "results/step5_*.json")

    # Section 5.2 claims the n=4 table "agrees in direction" with the n=20 one.
    # Checked rather than asserted: it does for the epistemic column at all five
    # horizons, and does NOT for the aleatoric column at one of them.
    _B4 = J("task_b2_epistemic.json")
    _agree_e = _agree_a = 0
    # Derived from the horizons BOTH artifacts actually carry, not a typed list.
    # The list was hard-coded to the pre-revision grid and did not follow h=100
    # in, so the sentence said "5 of 5" over a six-horizon table.
    _agree_hs = [_h for _h in D["d1_by_horizon"] if _h in _B4["by_horizon"]]
    _agree_hs.sort(key=int)
    for _h in _agree_hs:
        for _q, _c in (("epistemic", "e"), ("aleatoric", "a")):
            _x = (_B4["by_horizon"][_h][_q]["n_positive"]
                  > _B4["by_horizon"][_h][_q]["n_finite_corr"] / 2)
            _y = (D["d1_by_horizon"][_h][_q]["n_positive"]
                  > D["d1_by_horizon"][_h][_q]["n_finite_corr"] / 2)
            if _x == _y:
                if _c == "e":
                    _agree_e += 1
                else:
                    _agree_a += 1
    put("agree_epi", _agree_e, "results/task_b2_epistemic.json + task_d_nind20.json")
    put("agree_alea", _agree_a, "results/task_b2_epistemic.json + task_d_nind20.json")
    put("agree_nh", len(_agree_hs), "results/task_b2_epistemic.json + task_d_nind20.json")
    # Which horizons the aleatoric column disagrees at, so the sentence naming them
    # cannot go stale the way "it flips sign at h=8" did when h=100 was added.
    _dis = []
    for _h in _agree_hs:
        _x = (_B4["by_horizon"][_h]["aleatoric"]["n_positive"]
              > _B4["by_horizon"][_h]["aleatoric"]["n_finite_corr"] / 2)
        _y = (D["d1_by_horizon"][_h]["aleatoric"]["n_positive"]
              > D["d1_by_horizon"][_h]["aleatoric"]["n_finite_corr"] / 2)
        if _x != _y:
            _dis.append(_h)
    put("agree_alea_dis", " and ".join("h=" + x for x in _dis),
        "results/task_b2_epistemic.json + task_d_nind20.json")
    put("d3_tol", f'{100*D3["quantities"]["epistemic"]["verdict"]["tolerance"]:.0f}',
        "results/task_d3_perhorizon.json")

    # --- D2b: is the forecast-index control adequate? ---------------------
    RB = J("task_d2b_robustness.json")
    for _m, _t in (("linear", "lin"), ("log", "log"), ("cubic", "cub"),
                   ("spearman", "spr"), ("within_step", "win")):
        c = RB["controls"][_m]
        put(f"d2r_{_t}", f'{c["r_disagreement_given_index"]:+.3f}',
            "results/task_d2b_robustness.json")
        put(f"d2r_{_t}_ci", f'[{c["ci_lo"]:+.3f}, {c["ci_hi"]:+.3f}]',
            "results/task_d2b_robustness.json")
    _w = RB["controls"]["within_step"]
    put("d2r_win_pos", _w["steps_positive"], "results/task_d2b_robustness.json")
    put("d2r_win_n", _w["n_steps"], "results/task_d2b_robustness.json")
    put("d2r_win_med", f'{_w["median"]:+.3f}', "results/task_d2b_robustness.json")
    put("d2r_weakest", f'{RB["verdict"]["weakest_partial"]:+.3f}',
        "results/task_d2b_robustness.json")
    put("d2r_ncontrols", len(RB["controls"]), "results/task_d2b_robustness.json")


    # B2 -- the uncertainty the method actually consumes (C-14, R-58)
    B = J("task_b2_epistemic.json")
    for h in (1, 8, 32, 100, 128, 368):
        rec = B["by_horizon"][str(h)]
        for q, tag in (("aleatoric", "alea"), ("epistemic", "epi"), ("total", "tot")):
            m = rec[q]
            rr = m["ratio_err_over_sigma"]
            put(f"b2_{tag}_ratio_h{h}", f"{rr:,.0f}" if rr >= 100 else f"{rr:.1f}",
                "results/task_b2_epistemic.json")
            put(f"b2_{tag}_cov1_h{h}", f'{100*m["coverage_pm1"]:.2f}',
                "results/task_b2_epistemic.json")
            put(f"b2_{tag}_cov2_h{h}", f'{100*m["coverage_pm2"]:.2f}',
                "results/task_b2_epistemic.json")
            put(f"b2_{tag}_npos_h{h}", m["n_positive"], "results/task_b2_epistemic.json")
            put(f"b2_{tag}_ndim_h{h}", m["n_finite_corr"], "results/task_b2_epistemic.json")
            put(f"b2_{tag}_p_h{h}", f'{m["sign_p_two_sided"]:.1e}',
                "results/task_b2_epistemic.json")
            put(f"b2_{tag}_r_h{h}", f'{m["corr_mean"]:+.3f}',
                "results/task_b2_epistemic.json")
    e1 = B["by_horizon"]["1"]; e368 = B["by_horizon"]["368"]
    put("b2_epi_over_alea_h1",
        f'{e1["epistemic"]["mean_sigma"]/e1["aleatoric"]["mean_sigma"]:.0f}',
        "results/task_b2_epistemic.json")
    put("b2_epi_over_alea_h368",
        f'{e368["epistemic"]["mean_sigma"]/e368["aleatoric"]["mean_sigma"]:.0f}',
        "results/task_b2_epistemic.json")
    put("b2_epi_sigma_growth",
        f'{e368["epistemic"]["mean_sigma"]/e1["epistemic"]["mean_sigma"]:.2f}',
        "results/task_b2_epistemic.json")
    put("b2_epi_err_growth",
        f'{e368["epistemic"]["mean_abs_err"]/e1["epistemic"]["mean_abs_err"]:.2f}',
        "results/task_b2_epistemic.json")
    put("b2_penalty_corr", f'{B["released_scalar_penalty"]["corr_with_total_abs_error"]:+.3f}',
        "results/task_b2_epistemic.json")
    put("b2_nind", B["design"]["n_independent"], "results/task_b2_epistemic.json")
    put("b2_members", B["design"]["ensemble_size"], "results/task_b2_epistemic.json")

    # --- B: permutation over trajectories (R-61, S-15) ---------------------
    # Every dimension-count P-value in the paper comes from here now. The
    # binomial values are retained under _binom keys so the paper can quote the
    # size of the correction without either number being typed.
    PM = J("task_b_permutation.json")
    _ptag = {"faithful (mse)": "faithA", "corrected (nll)": "nll",
             "teacher-forced armB": "armB", "released aleatoric": "relale",
             "released EPISTEMIC": "epi"}
    _big = None
    for _ar, _pre in (("out-of-sample", "oos"), ("in-sample", "ins"),
                      ("all-episodes", "all")):
        A = PM["arenas"][_ar]
        put(f"perm_{_pre}_nind", A["n_independent"], "results/task_b_permutation.json")
        put(f"perm_{_pre}_floor", f'{A["p_floor"]:.4g}', "results/task_b_permutation.json")
        H = A["holm"]
        put(f"perm_{_pre}_holm_n", H["family_size"], "results/task_b_permutation.json")
        put(f"perm_{_pre}_holm_rej", H["n_rejected"], "results/task_b_permutation.json")
        put(f"perm_{_pre}_holm_thr", f'{H["smallest_threshold"]:.4g}',
            "results/task_b_permutation.json")
        put(f"perm_{_pre}_holm_min_p", f'{H["steps"][0]["p"]:.4f}',
            "results/task_b_permutation.json")
        put(f"perm_{_pre}_holm_min_cell", H["steps"][0]["cell"],
            "results/task_b_permutation.json")
        # C2(rev2), 2.3. This was a typed (1, 8, 32, 128, 368) while the artifact
        # carried the grid, so when h=100 -- the horizon the abstract is anchored
        # to -- was added to the measurement, the paper's permutation column would
        # still have printed "--" for it. Follow the artifact.
        _PH = sorted((int(k) for k in A["models"][next(iter(_ptag))]))
        for _lab, _tg in _ptag.items():
            for _h in _PH:
                r = A["models"][_lab][str(_h)]
                put(f"perm_{_pre}_{_tg}_p_h{_h}", f'{r["p_permutation"]:.4f}',
                    "results/task_b_permutation.json")
                put(f"perm_{_pre}_{_tg}_null_h{_h}", f'{r["null_mean"]:.1f}',
                    "results/task_b_permutation.json")
                put(f"perm_{_pre}_{_tg}_grp_h{_h}", r["group_count"],
                    "results/task_b_permutation.json")
                put(f"perm_{_pre}_{_tg}_npos_h{_h}", r["observed"],
                    "results/task_b_permutation.json")
                put(f"perm_{_pre}_{_tg}_ndim_h{_h}", r["n_dims"],
                    "results/task_b_permutation.json")
                put(f"perm_{_pre}_{_tg}_binom_h{_h}", f'{r["p_binomial_two_sided"]:.2e}',
                    "results/task_b_permutation.json")
                # Only cells the paper ever cited as evidence, i.e. where the
                # count is a positive-direction majority. The largest ratio
                # overall belongs to released aleatoric at h=32 in-sample (0/45,
                # binomially "significant" in the NEGATIVE direction), which no
                # claim here rests on; quoting it would overstate the correction
                # by pointing at a cell nobody used.
                _rat = r["p_permutation"] / max(r["p_binomial_two_sided"], 1e-300)
                if r["observed"] > r["n_dims"] / 2 and (_big is None or _rat > _big[0]):
                    _big = (_rat, _ar, _lab, _h, r)
    # A1: the released aleatoric head's direction is arena-dependent and the paper
    # asserted the all-episodes result while its table printed the out-of-sample
    # one. Both are surfaced here so each citation can name its arena.
    _ra = PM["arenas"]
    for _pre, _ar in (("oos", "out-of-sample"), ("ins", "in-sample"), ("all", "all-episodes")):
        _r = _ra[_ar]["models"]["released aleatoric"]["368"]
        put(f"relale_{_pre}_pos_h368", _r["observed"], "results/task_b_permutation.json")
        put(f"relale_{_pre}_neg_h368", _r["n_dims"] - _r["observed"],
            "results/task_b_permutation.json")
    put("relale_all_nind", _ra["all-episodes"]["n_independent"],
        "results/task_b_permutation.json")
    put("relale_oos_nind", _ra["out-of-sample"]["n_independent"],
        "results/task_b_permutation.json")
    # C5(rev2), 3.3 / scope-consistency. Section 4 said the eight untested claims
    # were "without exception" about policy learning or hardware, while appendix E
    # says of two of them "no simulator needed" and puts both within CPU reach.
    # Both counts are now derived from the two tables that carry them, so the
    # quantifier in 4 cannot outrun the enumeration two appendices later.
    def _table_rows(section_title):
        """The data rows of the first Markdown table under a section heading."""
        m = re.search(r"^## " + re.escape(section_title) + r".*$", TPL, re.M)
        assert m, f"no section titled {section_title!r}"
        body = TPL[m.end():]
        nxt = body.find("\n## ")
        body = body[:nxt] if nxt > 0 else body
        rows = [ln.strip() for ln in body.split("\n") if ln.strip().startswith("|")]
        # drop the header and the |---| separator
        return [r for r in rows[2:] if set(r.replace("|", "").strip()) - set("-: ")]

    _appF = _table_rows("Appendix E")
    _appE = _table_rows("Appendix D")
    _f_tested = [r for r in _appF if re.split(r"(?<!\\)\|", r.strip("|"))[1].strip()
                 .lower().strip("* ") == "yes"]
    _f_untested = [r for r in _appF if r not in _f_tested]
    put("appF_n_claims", len(_appF), "PAPER.template.md, Appendix E table")
    put("n_untested", len(_f_untested), "PAPER.template.md, Appendix E table")
    put("n_untested_word", WORDS.get(len(_f_untested), str(len(_f_untested))).lower(),
        "PAPER.template.md, Appendix E table")
    _e_cpu = [r for r in _appE if "no simulator needed" in r]
    put("appE_n_cpu", len(_e_cpu), "PAPER.template.md, Appendix D table")
    put("appE_n_cpu_word", WORDS.get(len(_e_cpu), str(len(_e_cpu))).lower(),
        "PAPER.template.md, Appendix D table")

    # B3. §4 stated a count of six and then ENUMERATED five. The count came from
    # here; the list was typed. That sentence is the replacement for retracted
    # claim S-17, which was itself a count defect in the same place, so a second
    # count defect in the replacement is worse than the first.
    #
    # Both now come from a `[tag]` at the head of each untested row's verdict cell
    # in Appendix E. The tags also settle a question the enumeration was hiding:
    # "generality across quadruped, humanoid, manipulation" is tagged `model`, not
    # `policy` or `hardware`. It needs a simulator and datasets from other robots,
    # but it is a claim about the MODEL, so the sentence saying all six are about
    # policy learning or hardware was false about one of them even once the count
    # was right.
    def _cell(row, i):
        return re.split(r"(?<!\\)\|", row.strip("|"))[i].strip()

    def _tag(row):
        """`[class, class: short name]` at the head of an untested row's verdict.

        The classes drive §4's counts; the short name is what §4 calls the claim.
        Both live beside the claim rather than in prose, so the enumeration and
        the count cannot disagree with the table or with each other.
        """
        m = re.match(r"`\[([^\]]+)\]`", _cell(row, 3))
        if not m:
            return None
        classes, _, name = m.group(1).partition(":")
        return ([c.strip() for c in classes.split(",")], name.strip())

    def _tags(row):
        t = _tag(row)
        return t[0] if t else []

    def _label(row):
        t = _tag(row)
        assert t and t[1], f"no short name in the tag for: {_cell(row, 0)[:60]}"
        return t[1]

    _untagged = [_label(r) for r in _f_untested if not _tags(r)]
    assert not _untagged, (
        "untested Appendix E rows with no `[tag]` in their verdict cell, so §4's "
        f"count and enumeration cannot be derived from them: {_untagged}")
    _f_cpu = [r for r in _f_untested if "cpu" in _tags(r)]
    _f_sim = [r for r in _f_untested if "cpu" not in _tags(r)]
    assert len(_f_cpu) == len(_e_cpu), (
        f"Appendix E tags {len(_f_cpu)} untested claims `cpu` while Appendix D "
        f"prices {len(_e_cpu)} as needing no simulator")
    # Appendix D promises a price for EACH untested claim. It listed six of eight.
    assert len(_appE) == len(_f_untested), (
        f"Appendix D prices {len(_appE)} claims; Appendix E marks {len(_f_untested)} "
        "untested, and Appendix D's own opening says it prices each of them")
    _f_polhw = [r for r in _f_sim if {"policy", "hardware"} & set(_tags(r))]
    _f_model = [r for r in _f_sim if not ({"policy", "hardware"} & set(_tags(r)))]
    _n_sim = len(_f_sim)
    assert _n_sim == len(_f_untested) - len(_e_cpu)
    put("appE_n_sim", _n_sim, "PAPER.template.md, Appendix D + F tables")
    put("appE_n_sim_word", WORDS.get(_n_sim, str(_n_sim)).lower(),
        "PAPER.template.md, Appendix D + F tables")
    put("appF_n_polhw", len(_f_polhw), "PAPER.template.md, Appendix E verdict tags")
    put("appF_n_polhw_word", WORDS.get(len(_f_polhw), str(len(_f_polhw))),
        "PAPER.template.md, Appendix E verdict tags")
    # Same count, lower-cased, for the mid-sentence use in S4. WORDS is capitalised
    # for sentence-initial substitution; dropping it into "then named {{...}}" put
    # "named Five" in the PDF, which reads as a proper noun rather than a count.
    put("appF_n_polhw_lower", WORDS.get(len(_f_polhw), str(len(_f_polhw))).lower(),
        "PAPER.template.md, Appendix E verdict tags")
    put("appF_n_model", len(_f_model), "PAPER.template.md, Appendix E verdict tags")

    def _english(items):
        items = list(items)
        if len(items) == 1:
            return items[0]
        return ", ".join(items[:-1]) + " and " + items[-1]

    put("appF_sim_list", _english(_label(r) for r in _f_sim),
        "PAPER.template.md, Appendix E verdict tags")
    put("appF_polhw_list", _english(_label(r) for r in _f_polhw),
        "PAPER.template.md, Appendix E verdict tags")
    put("appF_model_list", _english(_label(r) for r in _f_model),
        "PAPER.template.md, Appendix E verdict tags")
    put("appF_cpu_list", _english(_label(r) for r in _f_cpu),
        "PAPER.template.md, Appendix E verdict tags")

    # A6 -- what the originals report for each claim we tested
    OP = J("original_paper_figures.json")
    put("orig_n_tested", OP["n_tested_claims"], "results/original_paper_figures.json")
    assert len(_f_tested) == OP["n_tested_claims"], (
        f"Appendix E marks {len(_f_tested)} claims tested; "
        f"original_paper_figures.json says {OP['n_tested_claims']}")
    put("orig_n_without", OP["n_without"], "results/original_paper_figures.json")
    put("orig_n_with", OP["n_with_quantitative_figure"], "results/original_paper_figures.json")
    _se = OP["sample_efficiency"]["figures"]
    put("orig_se_rwm", _se["RWM pretraining state transitions"],
        "results/original_paper_figures.json")
    put("orig_se_ppo", _se["PPO state transitions"], "results/original_paper_figures.json")
    put("orig_se_rwm_rew", _se["MBPO-PPO real tracking reward"],
        "results/original_paper_figures.json")
    put("orig_se_ppo_rew", _se["PPO real tracking reward"],
        "results/original_paper_figures.json")
    put("perm_ngroups", PM["arenas"]["out-of-sample"]["models"]["released EPISTEMIC"]["368"]["n_groups"],
        "results/task_b_permutation.json")
    # How many horizons the epistemic permutation column of 6.2 actually reports.
    # 6.2 said "these are five tests on one family" over what is now a six-row
    # column; a typed count under a generated table is the defect this whole
    # build exists to prevent.
    _nperm_h = len(PM["arenas"]["all-episodes"]["models"]["released EPISTEMIC"])
    put("perm_n_tests_col", _nperm_h, "results/task_b_permutation.json")
    put("perm_n_tests_col_word", WORDS.get(_nperm_h, str(_nperm_h)).lower(),
        "results/task_b_permutation.json")
    _r, _ar, _lab, _h, _rec = _big
    # Rendered as a power of ten. "17,592,186,044,416" is not a number a reader
    # parses; "about 10^13" is the claim being made.
    import math as _m
    put("perm_worst_factor", f"10^{round(_m.log10(_r))}", "results/task_b_permutation.json")
    put("perm_worst_factor_exact", f"{_r:.3g}", "results/task_b_permutation.json")
    put("perm_worst_model", _lab, "results/task_b_permutation.json")
    put("perm_worst_h", _h, "results/task_b_permutation.json")
    put("perm_worst_arena", _ar, "results/task_b_permutation.json")
    put("perm_worst_null", f'{_rec["null_mean"]:.1f}', "results/task_b_permutation.json")
    _nulls = [PM["arenas"][a]["models"][l][h]["null_mean"]
              for a in PM["arenas"] for l in _ptag
              for h in PM["arenas"][a]["models"][l]]
    # B8. "rates differing by about 5x" in §8's assumption table was typed; the
    # artifact that computes both rates also computes their ratio.
    put("o12_rate_ratio", f'{J("step6_3_min_logstd.json")["rate_ratio"]:.1f}',
        "results/step6_3_min_logstd.json")
    put("perm_faircoin", f'{PM["arenas"]["in-sample"]["models"]["teacher-forced armB"]["368"]["n_dims"] / 2:g}',
        "results/task_b_permutation.json")
    put("perm_null_lo", f"{min(_nulls):.1f}", "results/task_b_permutation.json")
    put("perm_null_hi", f"{max(_nulls):.1f}", "results/task_b_permutation.json")

    # Episode-boundary accounting for section 5.4. These were typed ("four of the
    # reference's nine"); correct, but typed.
    _tr = set(J("step5_armA_seed0.json")["hyperparameters"]["train_episodes"])
    _ho = set(J("step5_armA_seed0.json")["hyperparameters"]["holdout_episodes"])
    _b = [(e, e + 1) for e in range(len(_tr) + len(_ho) - 1)]
    _both = [x for x in _b if x[0] in _tr and x[1] in _tr]
    _touch = [x for x in _b if x[0] in _ho or x[1] in _ho]
    put("bound_total", len(_b), "results/step5_armA_seed0.json (split)")
    put("bound_both_train", len(_both), "results/step5_armA_seed0.json (split)")
    put("bound_touch_holdout", len(_touch), "results/step5_armA_seed0.json (split)")
    put("n_train_eps", len(_tr), "results/step5_armA_seed0.json (split)")
    put("n_holdout_eps", len(_ho), "results/step5_armA_seed0.json (split)")

    # in-sample vs out-of-sample independent-trajectory counts. An earlier draft
    # reused ab_long_cells (a CELL count) as this ratio; both happened to be 4.
    _c3 = J("task_c3_multiplicity.json")
    _bu = J("review_bootstrap_unit.json")
    _oos = next(v["n_independent_reported"] for k, v in _bu.items()
                if k != "_summary" and k.startswith("out-of-sample|400"))
    _ins = next(v["n_independent_reported"] for k, v in _bu.items()
                if k != "_summary" and k.startswith("in-sample|400"))
    put("nind_oos_400", _oos, "results/review_bootstrap_unit.json")
    put("nind_ins_400", _ins, "results/review_bootstrap_unit.json")
    put("nind_ratio", f"{_ins / _oos:.0f}", "results/review_bootstrap_unit.json")

    # R-15: the stale-action cost, so section 5.2 can quote a figure rather than
    # asserting "materially better" with nothing behind it (C1 marked it UNSUPPORTED).
    _r15 = J("step4_0a_results.json")["protocols"]
    put("stale_nrmse", f'{_r15["A_off0"]["nrmse"]["368"]:.4f}', "results/step4_0a_results.json")
    put("causal_nrmse", f'{_r15["A_off1"]["nrmse"]["368"]:.4f}', "results/step4_0a_results.json")
    put("stale_pct", f'{100*(_r15["A_off0"]["nrmse"]["368"]/_r15["A_off1"]["nrmse"]["368"]-1):.0f}',
        "results/step4_0a_results.json")
    # The SAME comparison under the metric the abstract's other headline uses.
    # §7.2's figure is nRMSE at h = 368 and nothing else -- 50.9% at h = 1, 10.9%
    # at h = 128 -- and the abstract quoted it with neither scope, so a reviewer
    # computing on relative-L1 would have got a number eight times smaller and
    # concluded the abstract was wrong. Both are printed now, in the sentence that
    # claims every abstract headline names its metric.
    put("stale_pct_rel", f'{100*(_r15["A_off0"]["e"]/_r15["A_off1"]["e"]-1):.1f}',
        "results/step4_0a_results.json")

    # D3: the hold-last floor. Section 3 quoted 0.3509 against 1.5540 with no
    # baseline, so a reader could not judge whether 0.3509 was good.
    _fl = J("task4_arenas.json")["task4a"]["out-of-sample@400"]["floor"]["368"]["l1"]
    put("floor_h368", f"{_fl:.4f}", "results/task4_arenas.json")
    _A = float(t5["gaps"]["out-of-sample|10000|h368"]["A"])
    _B = float(t5["gaps"]["out-of-sample|10000|h368"]["B"])
    put("floor_over_A", f"{_fl / _A:.1f}", "results/task4_arenas.json + task5_analysis.json")
    put("B_over_floor", f"{_B / _fl:.2f}", "results/task4_arenas.json + task5_analysis.json")

    # D2 -- post-hoc recalibration
    _d2 = J("task_d2_recalibration.json")
    def _f1(lab):
        return [f for f in _d2["models"][lab]["fits"] if f["mode"] == "c@h1"]
    for lab, tag in (("released aleatoric", "ale"),
                     ("released EPISTEMIC (used by the method)", "epi"),
                     ("faithful (mse)", "fai")):
        fs = _f1(lab)
        for h in (1, 368):
            v = [100 * f["coverage_after"][str(h)] for f in fs]
            put(f"d2_{tag}_cov{h}_lo", f"{min(v):.0f}", "results/task_d2_recalibration.json")
            put(f"d2_{tag}_cov{h}_hi", f"{max(v):.0f}", "results/task_d2_recalibration.json")
        cs = [f["scalar"] for f in fs]
        put(f"d2_{tag}_c_lo", f"{min(cs):.3g}", "results/task_d2_recalibration.json")
        put(f"d2_{tag}_c_hi", f"{max(cs):.3g}", "results/task_d2_recalibration.json")
    # C3(rev2), 3.9. This printed 68.3 while 3.1 derives and everything else quotes
    # 68.27, so the paper carried two numeric strings for one constant. The
    # recalibration artifact stores its own target to fewer places; assert the two
    # agree and then quote V3's, which is the one 3.1 derives.
    _nom1 = f'{100 * J("v3_metric_definitions.json")["coverage"]["nominal"]["pm1"]:.2f}'
    assert abs(100 * _d2["target_coverage"] - float(_nom1)) < 0.05, \
        "the recalibration target and the derived nominal coverage disagree"
    put("d2_target", _nom1, "results/v3_metric_definitions.json")

    # E2: magnitude collapse is objective-driven, input-independence is arm-driven
    import glob as _g, statistics as _st
    _mse, _nll_s = [], []
    for _f in sorted(_g.glob("results/step5_arm*.json")):
        if "_10k" in _f:
            continue
        # Released architecture only. §6.3 reports one collapse rate and calls it
        # nearly identical across runs; a run at another width is a different
        # experiment and belongs to §6.10, not here.
        if _width(_f) != _released_w:
            continue
        _d = json.load(open(_f))
        _sl = _d.get("collapse_fit", {}).get("slope_per_iter")
        if _sl is None:
            continue
        (_nll_s if _f.endswith("_nll.json") else _mse).append(_sl)
    put("e2_mse_runs", len(_mse), "results/step5_arm*.json")
    put("e2_mse_rate", f"{_st.mean(_mse):.4e}", "results/step5_arm*.json")
    put("e2_mse_sd", f"{_st.stdev(_mse):.1e}", "results/step5_arm*.json")
    put("e2_nll_runs", len(_nll_s), "results/step5_arm*.json")
    put("e2_fitted_runs", len(_mse) + len(_nll_s), "results/step5_arm*.json")
    _all = len([f for f in _g.glob("results/step5_arm*.json")
                if _width(f) == _released_w])
    put("e2_excluded_10k", _all - (len(_mse) + len(_nll_s)), "results/step5_arm*.json")
    put("e2_nll_rate", f"{_st.mean(_nll_s):+.4e}", "results/step5_arm*.json")

    # "four defects in the released pipeline" was typed. Count section 5's
    # subsections instead, so adding or removing one cannot desynchronise the abstract.
    # Bound to the section's TITLE, not its number. The first version of this
    # matched "**5.N " and silently returned 0 the moment the section was
    # renumbered to 6 -- putting "we report 0 defects" in the abstract. Counting
    # from a number that can move is the same bug as typing the number.
    _tpl = open("PAPER.template.md").read()
    _dsec = re.search(r"^## (\d+)\. Defects in the released pipeline\s*$", _tpl, re.M)
    assert _dsec, "no section titled 'Defects in the released pipeline'"
    _dnum = _dsec.group(1)
    _dbody = _tpl[_dsec.end():]
    _dbody = _dbody[:_dbody.find("\n## ")] if "\n## " in _dbody else _dbody
    _n = len(re.findall(r"^\*\*" + _dnum + r"\.\d+ ", _dbody, re.M))
    assert _n > 0, f"section {_dnum} has no bold-numbered defect subsections"
    WORD = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six"}
    put("n_defects", WORD.get(_n, str(_n)),
        f"PAPER.template.md section {_dnum} subsections")

    # D1 -- the headline over three seeds. The single-seed figures stay available
    # so the paper can say what changed rather than quietly swapping them.
    _d1 = J("task_d1_threeseed.json")
    _A, _B = _d1["aggregate"]["A"], _d1["aggregate"]["B"]
    put("d1_seeds", _A["n_seeds"], "results/task_d1_threeseed.json")
    put("d1_A_mean", f'{_A["mean"]:.4f}', "results/task_d1_threeseed.json")
    put("d1_A_sd", f'{_A["sd_ddof1"]:.4f}', "results/task_d1_threeseed.json")
    put("d1_B_mean", f'{_B["mean"]:.4f}', "results/task_d1_threeseed.json")
    put("d1_B_sd", f'{_B["sd_ddof1"]:.4f}', "results/task_d1_threeseed.json")
    put("d1_ratio", f'{_d1["aggregate"]["ratio_B_over_A"]:.2f}',
        "results/task_d1_threeseed.json")
    put("d1_A_relsd", f'{100*_A["sd_ddof1"]/_A["mean"]:.1f}', "results/task_d1_threeseed.json")
    put("d1_B_relsd", f'{100*_B["sd_ddof1"]/_B["mean"]:.1f}', "results/task_d1_threeseed.json")
    put("d1_A_lo", f'{min(_A["per_seed"].values()):.4f}', "results/task_d1_threeseed.json")
    put("d1_A_hi", f'{max(_A["per_seed"].values()):.4f}', "results/task_d1_threeseed.json")
    put("d1_B_lo", f'{min(_B["per_seed"].values()):.4f}', "results/task_d1_threeseed.json")
    put("d1_B_hi", f'{max(_B["per_seed"].values()):.4f}', "results/task_d1_threeseed.json")
    put("d1_rule_h", _d1["rule_horizon"], "results/task_d1_threeseed.json")
    # C1(rev2), 2.2. The A/B comparison at the DEPLOYMENT horizon, beside the
    # pre-registered figure at h=368. M-23 is stated over h=368 and its verdict is
    # untouched; this is the same measurement at the horizon the rest of the paper
    # is anchored to, and it is materially smaller. The abstract quoted 4.61x with
    # no horizon at all, in a revision whose central move was horizon labelling.
    for _hh, _hk in ((_d1["horizons"][0], "h100"),):
        _bh = _d1["by_horizon"][str(_hh)]
        put(f"d1_ratio_{_hk}", f'{_bh["ratio_B_over_A"]:.2f}',
            "results/task_d1_threeseed.json")
        put(f"d1_A_mean_{_hk}", f'{_bh["A"]["mean"]:.4f}', "results/task_d1_threeseed.json")
        put(f"d1_A_sd_{_hk}", f'{_bh["A"]["sd_ddof1"]:.4f}', "results/task_d1_threeseed.json")
        put(f"d1_B_mean_{_hk}", f'{_bh["B"]["mean"]:.4f}', "results/task_d1_threeseed.json")
        put(f"d1_B_sd_{_hk}", f'{_bh["B"]["sd_ddof1"]:.4f}', "results/task_d1_threeseed.json")
    # --- A1: the A/B result across the whole horizon grid --------------------
    # 5 led with h=368 while 3.1 says h=368 is not a deployment horizon, and the
    # same comparison at h=100 is 2.58x. As a line item that reads as horizon
    # shopping; as a curve it is a finding, because the advantage GROWS with
    # horizon and h=368 is the end of a trend. Everything here except h=368 was
    # computed after the data existed and carries no pre-registration weight.
    A1 = J("a1_ab_by_horizon.json")
    _a1h = A1["design"]["horizons"]
    for _h in _a1h:
        _r = A1["by_horizon"][str(_h)]
        put(f"a1_ratio_h{_h}", f'{_r["ratio_B_over_A"]:.2f}', "results/a1_ab_by_horizon.json")
        put(f"a1_A_h{_h}", f'{_r["A"]["mean"]:.4f}', "results/a1_ab_by_horizon.json")
        put(f"a1_A_sd_h{_h}", f'{_r["A"]["sd_ddof1"]:.4f}', "results/a1_ab_by_horizon.json")
        put(f"a1_B_h{_h}", f'{_r["B"]["mean"]:.4f}', "results/a1_ab_by_horizon.json")
        put(f"a1_B_sd_h{_h}", f'{_r["B"]["sd_ddof1"]:.4f}', "results/a1_ab_by_horizon.json")
        put(f"a1_gap_h{_h}", f'{_r["gap"]:+.4f}', "results/a1_ab_by_horizon.json")
        put(f"a1_gap_ci_h{_h}", f'[{_r["gap_ci"][0]:+.4f}, {_r["gap_ci"][1]:+.4f}]',
            "results/a1_ab_by_horizon.json")
        put(f"a1_excl_h{_h}", "yes" if _r["gap_excludes_zero"] else "no",
            "results/a1_ab_by_horizon.json")
        put(f"a1_floor_h{_h}", f'{_r["floor"]:.4f}', "results/a1_ab_by_horizon.json")
        put(f"a1_floor_over_A_h{_h}", f'{_r["floor_over_A"]:.1f}',
            "results/a1_ab_by_horizon.json")
        put(f"a1_B_over_floor_h{_h}", f'{_r["B_over_floor"]:.2f}',
            "results/a1_ab_by_horizon.json")
        _sg = A1["sign_test"][str(_h)]
        put(f"a1_sign_pos_h{_h}", _sg["n_positive"], "results/a1_ab_by_horizon.json")
        put(f"a1_sign_n_h{_h}", _sg["n_episodes"], "results/a1_ab_by_horizon.json")
        put(f"a1_sign_p_h{_h}", f'{_sg["exact_two_sided_p"]:.4f}',
            "results/a1_ab_by_horizon.json")
    # E8. The four trajectory values behind every n_independent = 4 interval.
    #
    # A cluster bootstrap over four units has 256 distinct resamples, quantised
    # tails and poor coverage. The paper says all three and prints the interval
    # anyway, which asks a reader to accept a summary of four numbers instead of
    # the four numbers. They are more informative than the interval -- at
    # h = 368 one trajectory carries most of the gap, which no interval shows --
    # and printing them pre-empts the objection rather than inviting it.
    for _h in _a1h:
        _g = A1["by_horizon"][str(_h)].get("gap_per_trajectory")
        if _g:
            put(f"a1_gap_traj_h{_h}",
                ", ".join(f"{v:+.4f}" for v in sorted(_g, reverse=True)),
                "results/a1_ab_by_horizon.json")
            put(f"a1_gap_traj_max_h{_h}", f"{max(_g):+.4f}",
                "results/a1_ab_by_horizon.json")
            put(f"a1_gap_traj_min_h{_h}", f"{min(_g):+.4f}",
                "results/a1_ab_by_horizon.json")
            put(f"a1_gap_traj_n_positive_h{_h}", sum(1 for v in _g if v > 0),
                "results/a1_ab_by_horizon.json")
            put(f"a1_gap_traj_n_h{_h}", len(_g), "results/a1_ab_by_horizon.json")

    _t = A1["trend"]
    put("a1_monotone", "does" if _t["monotone_increasing"] else "does not",
        "results/a1_ab_by_horizon.json")
    put("a1_n_excl", _t["n_excluding_zero"], "results/a1_ab_by_horizon.json")
    put("a1_n_horizons", _t["n_horizons"], "results/a1_ab_by_horizon.json")
    put("a1_spans_zero_at", " and ".join(f"h={h}" for h in _t["spans_zero_at"]) or "no horizon",
        "results/a1_ab_by_horizon.json")
    put("a1_nind", A1["design"]["n_independent"], "results/a1_ab_by_horizon.json")
    # Where teacher forcing loses to the trivial baseline, and where the trained
    # arm does. The second is the one nobody had looked at: at one step the
    # hold-last floor beats BOTH arms, and 5 quoted the h=368 margin as if it
    # held everywhere.
    _bwf = [h for h in _a1h if A1["by_horizon"][str(h)]["B_worse_than_floor"]]
    _awf = [h for h in _a1h if A1["by_horizon"][str(h)]["floor_over_A"] < 1]
    put("a1_B_worse_than_floor_at",
        "every horizon" if len(_bwf) == len(_a1h)
        else (" and ".join(f"h={h}" for h in _bwf) or "no horizon"),
        "results/a1_ab_by_horizon.json")
    put("a1_A_worse_than_floor_at",
        " and ".join(f"h={h}" for h in _awf) or "no horizon",
        "results/a1_ab_by_horizon.json")
    put("a1_n_A_worse_than_floor", len(_awf), "results/a1_ab_by_horizon.json")

    # Head-to-head absolute accuracy: the released checkpoint against the from-scratch
    # arms, one arena, both aggregations. Every cell of the table is a key here; the
    # verdict keys name horizons rather than restate a comparison, because the two
    # aggregations have inverted a released-checkpoint comparison before (Appendix H).
    H2 = J("head_to_head_accuracy.json")
    _h2src = "results/head_to_head_accuracy.json"
    for _row in H2["rows"]:
        for _h in H2["horizons"]:
            _c = H2["rows"][_row]["cells"][str(_h)]
            put(f"h2h_{_row}_nrmse_h{_h}", f'{_c["nrmse"]:.4f}', _h2src)
            put(f"h2h_{_row}_l1_h{_h}", f'{_c["l1"]:.4f}', _h2src)
    put("h2h_arena", H2["arena"], _h2src)
    put("h2h_episodes", " and ".join(str(e) for e in H2["arena_episodes"]), _h2src)
    put("h2h_ntraj", H2["n_trajectories"], _h2src)
    put("h2h_nind", H2["n_independent"], _h2src)
    put("h2h_unit", H2["unit_length"], _h2src)
    put("h2h_nseeds", len(H2["arm_seeds"]), _h2src)
    put("h2h_arm_ckpt", H2["arm_checkpoint"], _h2src)

    def _hs(hs):
        return " and ".join(f"h = {h}" for h in hs) or "no horizon"
    put("h2h_released_sweeps_at", _hs(H2["released_leads_both_metrics_at"]), _h2src)
    put("h2h_armA_sweeps_at", _hs(H2["armA_leads_both_metrics_at"]), _h2src)
    put("h2h_split_at", _hs(H2["metrics_disagree_at"]), _h2src)
    put("h2h_ckpt_neps_word", WORDS[H2["released_ckpt_trained_on_n_episodes"]].lower(), _h2src)

    _xc = _d1["cross_check"]
    put("d1_xc_runs", len(_xc), "results/task_d1_threeseed.json")
    put("d1_xc_values", f'{sum(r.get("values_compared", 0) for r in _xc):,}',
        "results/task_d1_threeseed.json")
    put("d1_xc_diff", sum(r.get("differing", 0) for r in _xc),
        "results/task_d1_threeseed.json")

    # A4.3: a table a reader can count. Derived from the run JSONs themselves.
    import glob as _g2
    inv = {}
    for f in sorted(_g2.glob("results/step5_arm*.json")):
        d = json.load(open(f))
        h = d["hyperparameters"]
        arm = d["arm"] if "arm" in d else ("B" if "armB" in f else "A")
        # ensemble is part of the key. Without it the ens1 and ens5 Arm A runs
        # collapsed into one row reading "6 | 0, 0, 1, 1, 2, 2" -- three seeds
        # listed twice, which reads as a duplication bug rather than as two
        # configurations.
        # rnn_hidden_size is part of the key too, for the same reason ensemble is.
        # Without it M-49's five capacity-matched runs at width 124 sat inside the
        # released-width Arm A row, which then read "10 | 0, 0, 1, 1, 2, 2, 3, 3,
        # 4, 4" -- five seeds listed twice, in a table headed "so a reader can
        # count them". Two architectures were presented as one population, in the
        # one place the paper invites a reader to audit the population by hand.
        key = (arm, h["iterations"], h.get("ensemble", 1), h.get("loss_type", "mse"),
               "contaminated" if h.get("contaminated") else
               ("duplicated" if h.get("duplicated") else "clean"), _width(f))
        inv.setdefault(key, []).append(d["seed"])
    rows = []
    for (arm, it, ens, loss, ds, w), seeds in sorted(inv.items()):
        rows.append(f"| Arm {arm} | {it:,} | {ens} | {loss} | {ds} | {w} | {len(seeds)} | "
                    f"{', '.join(str(x) for x in sorted(seeds))} |")
    put("run_table", "\n".join(rows), "results/step5_arm*.json")
    put("run_total", sum(len(v) for v in inv.values()), "results/step5_arm*.json")

    # C3 -- multiplicity
    C3 = J("task_c3_multiplicity.json")
    put("c3_family", C3["family_ab"]["n_comparisons"], "results/task_c3_multiplicity.json")
    put("c3_long", C3["family_ab"]["n_long_horizon"], "results/task_c3_multiplicity.json")
    for r in C3["long_horizon_by_level"]:
        if r["level"].startswith("Bonferroni 0.05/") and str(C3["family_ab"]["n_comparisons"]) in r["level"]:
            put("c3_bonf_excl", r["long_horizon_excluding_zero"], "results/task_c3_multiplicity.json")
    put("c3_holm_rejected", C3["holm_bonferroni"]["n_rejected"], "results/task_c3_multiplicity.json")
    put("c3_sign_pos", C3["sign_test_h368"]["n_positive"], "results/task_c3_multiplicity.json")
    put("c3_sign_n", C3["sign_test_h368"]["n_episodes"], "results/task_c3_multiplicity.json")
    put("c3_sign_p", f'{C3["sign_test_h368"]["exact_two_sided_p"]:.4f}',
        "results/task_c3_multiplicity.json")
    put("c3_resamples", C3["bootstrap_resolution_note"]["distinct_resamples"],
        "results/task_c3_multiplicity.json")
    put("c3_quant", f'{C3["bootstrap_resolution_note"]["quantisation_pct"]:.2f}',
        "results/task_c3_multiplicity.json")

    # ==================================================================
    # Pre-submission revision: V1-V4, P1, A2, T1.
    # ==================================================================

    # --- V1 / X-12: what is shared across the five ensemble members --------
    V1 = J("v1_ensemble_topology.json")
    _ref = V1["reference"]
    _mech = V1["mechanism"]
    put("v1_members", _ref["ensemble_size"], "results/v1_ensemble_topology.json")
    put("v1_shared_params", f'{_mech["shared_params_per_member"]:,}',
        "results/v1_ensemble_topology.json")
    put("v1_private_params", f'{_mech["private_params_per_member"]:,}',
        "results/v1_ensemble_topology.json")
    put("v1_member_params", f'{_ref["state_pathway_params_per_member"]:,}',
        "results/v1_ensemble_topology.json")
    put("v1_shared_pct", f'{_mech["shared_pct_of_member"]:.2f}',
        "results/v1_ensemble_topology.json")
    put("v1_private_pct", f'{_mech["private_pct_of_member"]:.2f}',
        "results/v1_ensemble_topology.json")
    put("v1_shared_pct_model", f'{100 * _ref["shared_fraction_of_model"]:.2f}',
        "results/v1_ensemble_topology.json")
    put("v1_total_params", f'{_ref["total_params"]:,}', "results/v1_ensemble_topology.json")
    put("v1_hidden_states", _ref["n_independent_recurrent_states"],
        "results/v1_ensemble_topology.json")
    # Rendered as a word too: "There is 1 hidden-state trajectory" reads badly and
    # "one" cannot be typed under this paper's own rule. Same pattern as
    # n_retractions_word.
    # WORDS is capitalised for sentence-initial use; both of these render
    # mid-sentence, so lower them.
    put("v1_hidden_states_word",
        WORDS.get(_ref["n_independent_recurrent_states"],
                  str(_ref["n_independent_recurrent_states"])).lower(),
        "results/v1_ensemble_topology.json")
    put("v1_members_word",
        WORDS.get(_ref["ensemble_size"], str(_ref["ensemble_size"])).lower(),
        "results/v1_ensemble_topology.json")
    put("v1_n_citations", len(V1["source_citations"]), "results/v1_ensemble_topology.json")
    put("v1_our_arms_match",
        "yes" if V1["gate"]["our_arms_match_reference_topology"] else "NO",
        "results/v1_ensemble_topology.json")
    put("v1_n_arms_checked", len(V1["our_arms"]), "results/v1_ensemble_topology.json")
    # C4(rev2), 4.3 -- the capacity confound in 6.10's contrast, measured from the
    # checkpoints rather than estimated.
    _cc = V1["capacity_confound"]
    put("v1_cap_shared", f'{_cc["shared_trunk_arm_params"]:,}',
        "results/v1_ensemble_topology.json")
    put("v1_cap_indep", f'{_cc["independent_ensemble_params"]:,}',
        "results/v1_ensemble_topology.json")
    put("v1_cap_ratio", f'{_cc["ratio_independent_over_shared"]:.2f}',
        "results/v1_ensemble_topology.json")

    # --- V2 / X-13: which horizon is the deployment horizon ----------------
    V2 = J("v2_deployment_horizon.json")
    put("v2_deploy_h", V2["verdict"]["deployment_horizon_is"],
        "results/v2_deployment_horizon.json")
    put("v2_diag_h", V2["horizons"]["open_loop_diagnostic"]["value"],
        "results/v2_deployment_horizon.json")
    put("v2_ratio", f'{V2["verdict"]["h368_over_deployment"]:.2f}',
        "results/v2_deployment_horizon.json")
    put("v2_lite_cap", V2["horizons"]["imagination_episode_cap_lite_release"]["value"],
        "results/v2_deployment_horizon.json")
    put("v2_len_eval",
        V2["horizons"]["open_loop_diagnostic"]["arithmetic"]["len_eval_trajectory"],
        "results/v2_deployment_horizon.json")
    put("v2_history",
        V2["horizons"]["open_loop_diagnostic"]["arithmetic"]["history_horizon"],
        "results/v2_deployment_horizon.json")
    put("v2_fig_v1", V2["followup_figure"]["v1"]["figure"],
        "results/v2_deployment_horizon.json")
    put("v2_fig_v3", V2["followup_figure"]["v3"]["figure"],
        "results/v2_deployment_horizon.json")

    # --- V3 / X-14: the metric definitions ---------------------------------
    V3 = J("v3_metric_definitions.json")
    put("v3_n_citations", V3["n_citations_verified"], "results/v3_metric_definitions.json")
    put("v3_rel_l1", V3["metrics"]["relative_l1"]["latex_per_step"],
        "results/v3_metric_definitions.json")
    put("v3_rel_l1_agg", V3["metrics"]["relative_l1"]["latex_aggregate"],
        "results/v3_metric_definitions.json")
    put("v3_nrmse", V3["metrics"]["nrmse_pooled"]["latex"],
        "results/v3_metric_definitions.json")
    put("v3_scale", V3["constants"]["nrmse_scale"]["latex"],
        "results/v3_metric_definitions.json")
    put("v3_coverage", V3["coverage"]["latex"], "results/v3_metric_definitions.json")
    put("v3_rho", V3["metrics"]["overconfidence_factor"]["latex"],
        "results/v3_metric_definitions.json")
    put("v3_rho_calibrated",
        f'{V3["metrics"]["overconfidence_factor"]["calibrated_value_of_rho"]:.4f}',
        "results/v3_metric_definitions.json")
    put("v3_cov_nominal1", f'{100 * V3["coverage"]["nominal"]["pm1"]:.2f}',
        "results/v3_metric_definitions.json")
    put("v3_cov_nominal2", f'{100 * V3["coverage"]["nominal"]["pm2"]:.2f}',
        "results/v3_metric_definitions.json")

    # --- V4 / X-15: the follow-up's version map ----------------------------
    _fv = J("original_paper_figures.json")["followup_version_map"]
    put("v4_read", _fv["we_read"], "results/original_paper_figures.json")
    put("v4_read_date", _fv["we_read_dated"], "results/original_paper_figures.json")
    put("v4_current", _fv["current"], "results/original_paper_figures.json")
    put("v4_current_date", _fv["current_dated"], "results/original_paper_figures.json")
    put("v4_n_moved", len(_fv["moved"]), "results/original_paper_figures.json")
    put("v4_n_unchanged", len(_fv["unchanged"]), "results/original_paper_figures.json")
    # C4(rev2), 4.4. The rename was asserted in two places and challenged as
    # possibly being two model variants. It is a rename: the two names never
    # co-occur in any version, and only the expansion of the letter changed.
    _nm = next(m for m in _fv["moved"] if m["what"] == "the model's name")
    put("v4_name_v1", _nm["v1"], "results/original_paper_figures.json")
    put("v4_name_v3", _nm["v3"], "results/original_paper_figures.json")
    put("v4_exp_v1", _nm["v1_expansion"], "results/original_paper_figures.json")
    put("v4_exp_v3", _nm["v3_expansion"], "results/original_paper_figures.json")
    put("v4_name_n_v1", _nm["occurrences"]["v1"][_nm["v1"]],
        "results/original_paper_figures.json")
    put("v4_name_n_v3", _nm["occurrences"]["v3"][_nm["v3"]],
        "results/original_paper_figures.json")
    assert _nm["occurrences"]["v1"][_nm["v3"]] == 0 and _nm["occurrences"]["v3"][_nm["v1"]] == 0, \
        "the two model names co-occur in a version; the rename claim does not hold"

    # --- P1: what the two new rules can detect -----------------------------
    P1 = J("p1_power_check.json")
    put("p1_m45_n", P1["m45"]["n_independent_faced"], "results/p1_power_check.json")
    put("p1_m45_mde", f'{P1["m45"]["mde_80pct_power"]:.3f}', "results/p1_power_check.json")
    put("p1_m44_n", P1["m44"]["n_independent_faced"], "results/p1_power_check.json")
    put("p1_m44_mde_ratio",
        f'{P1["m44"]["mde_80pct_power"]["overconfidence_ratio_multiplicative"]:.2f}',
        "results/p1_power_check.json")
    put("p1_m44_mde_cov", f'{P1["m44"]["mde_80pct_power"]["coverage_pts"]:.2f}',
        "results/p1_power_check.json")
    put("p1_m44_mde_ratio_opt",
        f'{P1["m44"]["null_calibration_same_architecture"]["mde_ratio_multiplicative"]:.2f}',
        "results/p1_power_check.json")
    put("p1_m44_resamples", P1["m44"]["distinct_bootstrap_resamples"],
        "results/p1_power_check.json")
    # the dilution levels that bracket M-45's detection threshold, read off the
    # curve rather than asserted
    _pc = P1["m45"]["power_curve"]
    _miss = max((c for c in _pc if c["detection_rate"] < 0.5),
                key=lambda c: c["true_effect_mean"])
    _hit = min((c for c in _pc if c["detection_rate"] >= 0.8),
               key=lambda c: c["true_effect_mean"])
    put("p1_m45_undetected", f'{_miss["true_effect_mean"]:.3f}',
        "results/p1_power_check.json")
    put("p1_m45_detected", f'{_hit["true_effect_mean"]:.3f}', "results/p1_power_check.json")

    # --- A2 / M-45: the trajectory-level control ---------------------------
    A2 = J("a2_trajectory_level_control.json")
    _vd, _dd, _h1 = A2["variance_decomposition"], A2["double_demeaning"], A2["h1_diagnostic"]
    _ci = lambda c: f"[{c[0]:+.3f}, {c[1]:+.3f}]"
    put("a2_nind", A2["design"]["n_independent"], "results/a2_trajectory_level_control.json")
    put("a2_r_pooled", f'{_vd["r_pooled"]:+.3f}', "results/a2_trajectory_level_control.json")
    put("a2_r_pooled_ci", _ci(_vd["r_pooled_ci"]), "results/a2_trajectory_level_control.json")
    put("a2_r_between", f'{_vd["r_between_trajectory"]:+.3f}',
        "results/a2_trajectory_level_control.json")
    put("a2_r_between_ci", _ci(_vd["r_between_ci"]),
        "results/a2_trajectory_level_control.json")
    put("a2_r_within", f'{_vd["r_within_trajectory"]:+.3f}',
        "results/a2_trajectory_level_control.json")
    put("a2_r_within_ci", _ci(_vd["r_within_ci"]), "results/a2_trajectory_level_control.json")
    put("a2_share_between", f'{100 * _vd["share_between"]:.1f}',
        "results/a2_trajectory_level_control.json")
    put("a2_share_within", f'{100 * _vd["share_within"]:.1f}',
        "results/a2_trajectory_level_control.json")
    put("a2_rdd", f'{_dd["r_dd"]:+.3f}', "results/a2_trajectory_level_control.json")
    put("a2_rdd_ci", _ci(_dd["ci"]), "results/a2_trajectory_level_control.json")
    put("a2_step_only", f'{_dd["r_step_demeaned_only"]:+.3f}',
        "results/a2_trajectory_level_control.json")
    put("a2_h1_r", f'{_h1["r_h1"]:+.3f}', "results/a2_trajectory_level_control.json")
    put("a2_h1_ci", _ci(_h1["r_h1_ci"]), "results/a2_trajectory_level_control.json")
    put("a2_h1_partial_both", f'{_h1["partial_on_both"]:+.3f}',
        "results/a2_trajectory_level_control.json")
    put("a2_h1_speed_r",
        f'{_h1["confounders"]["commanded_speed"]["r_disagreement_vs_confounder"]:+.3f}',
        "results/a2_trajectory_level_control.json")
    put("a2_h1_diff_r",
        f'{_h1["confounders"]["episode_difficulty_D12"]["r_disagreement_vs_confounder"]:+.3f}',
        "results/a2_trajectory_level_control.json")
    put("a2_h1_npoints", _h1["n_points"], "results/a2_trajectory_level_control.json")
    # D-12's per-episode difficulty range, seed-averaged, as A2 uses it. The
    # ledger's D-12 quotes the range over all (seed, episode) cells and is
    # therefore slightly wider; this is the quantity 6.7 partials out, so this is
    # the one 6.7 quotes.
    put("d12_lo", f'{_h1["episode_difficulty_range"][0]:.3f}',
        "results/a2_trajectory_level_control.json")
    put("d12_hi", f'{_h1["episode_difficulty_range"][1]:.3f}',
        "results/a2_trajectory_level_control.json")
    put("a2_win_existing", f'{A2["reconciliation"]["existing_within_step_mean_r"]:+.3f}',
        "results/a2_trajectory_level_control.json")
    _hd = A2["horizon_dependence"]
    put("a2_excl_h", ", ".join(f"h={h}" for h in _hd["r_dd_excludes_zero_at"]),
        "results/a2_trajectory_level_control.json")
    put("a2_spans_h", " and ".join(f"h={h}" for h in _hd["r_dd_spans_zero_at"]),
        "results/a2_trajectory_level_control.json")
    put("a2_n_excl", len(_hd["r_dd_excludes_zero_at"]),
        "results/a2_trajectory_level_control.json")
    put("m45_verdict", "SUPPORTED" if A2["m45"]["supported"] else "NOT SUPPORTED",
        "results/a2_trajectory_level_control.json")
    # the per-horizon partial on trajectory level, for the 6.7 table
    for h in (8, 32, 100, 128, 368):
        _p = A2["partial_by_horizon"][str(h)]
        if _p["r_partial_trajectory_level"] is not None:
            put(f"a2_par_h{h}", f'{_p["r_partial_trajectory_level"]:+.3f}',
                "results/a2_trajectory_level_control.json")
            put(f"a2_par_ci_h{h}", _ci(_p["r_partial_ci"]),
                "results/a2_trajectory_level_control.json")
        if _p["r_dd"] is not None:
            put(f"a2_rdd_h{h}", f'{_p["r_dd"]:+.3f}',
                "results/a2_trajectory_level_control.json")
            put(f"a2_rdd_ci_h{h}", _ci(_p["r_dd_ci"]),
                "results/a2_trajectory_level_control.json")

    # --- the compiled PDF, so the README cannot quote a stale page count ----
    # (compile_paper.py runs AFTER this in the pipeline, so on a first-ever build
    # the key is absent; the README's line is optional for that reason.)
    _cp = os.path.join(R.RESULTS, "compile_paper.json")
    if os.path.exists(_cp):
        CP = J("compile_paper.json")
        put("pdf_pages", CP["pages"], "results/compile_paper.json")
        put("pdf_overfull", CP["overfull_hboxes"], "results/compile_paper.json")
        # This put the LIST here, so the README read "0 overfull boxes, [] LaTeX
        # warnings". The sentence wants a count.
        put("pdf_warnings", len(CP["latex_warnings"]), "results/compile_paper.json")

    # --- Figure 4: the pre-registration record -------------------------------
    # Counted from the figure's own data, so the prose cannot describe a bar by a
    # position that moves when a rule is added. "The fifth bar is negative" became
    # wrong the moment M-43, M-44 and M-45 joined the panel.
    _f4 = J("paper_figures.json")["fig4"]
    # M-48: purging the correspondence transcript from history rewrote every
    # commit from the one that introduced it onward, and two of Figure 4's cited
    # identifiers changed with it. The figure resolves them by commit SUBJECT now
    # (subjects survive a path filter, hashes do not), and the paper discloses the
    # rewrite because a reviewer checking those hashes is exactly who would notice.
    _f4c = J("paper_figures.json")["fig4_commits"]
    put("f4_n_commits", len({c["rule_commit"] for c in _f4c}
                            | {c["data_commit"] for c in _f4c}),
        "results/paper_figures.json")
    put("f4_n_rules", len(_f4), "results/paper_figures.json")
    put("f4_n_positive", sum(1 for v in _f4.values() if v["lead_hours"] > 0),
        "results/paper_figures.json")
    put("f4_n_negative", sum(1 for v in _f4.values() if v["lead_hours"] <= 0),
        "results/paper_figures.json")

    # --- R2 / M-44: the independent-initialisation ensemble ------------------
    R2 = J("r2_independent_ensemble.json")
    _m44, _dec = R2["m44"], R2["decomposition"]
    put("r2_nind", R2["design"]["n_independent"], "results/r2_independent_ensemble.json")
    put("r2_n_indep", len(R2["design"]["independent_seeds"]),
        "results/r2_independent_ensemble.json")
    put("r2_n_shared", len(R2["design"]["shared_trunk_seeds"]),
        "results/r2_independent_ensemble.json")
    put("m44_verdict", _m44["verdict"], "results/r2_independent_ensemble.json")
    put("m44_supported", "yes" if _m44["supported"] else "no",
        "results/r2_independent_ensemble.json")
    put("m44_h", _m44["horizon"], "results/r2_independent_ensemble.json")
    put("m44_ratio_gain", f'{_m44["mean_ratio_improvement"]:.2f}',
        "results/r2_independent_ensemble.json")
    put("m44_cov_gain", f'{_m44["mean_coverage_gain_pts"]:+.2f}',
        "results/r2_independent_ensemble.json")
    put("m44_mde_ratio", f'{_m44["mde_ratio"]:.2f}', "results/r2_independent_ensemble.json")
    put("m44_mde_cov", f'{_m44["mde_coverage_pts"]:.2f}',
        "results/r2_independent_ensemble.json")
    put("m44_n_conditions", len(_m44["conditions"]), "results/r2_independent_ensemble.json")
    put("m44_n_conditions_met", sum(1 for v in _m44["conditions"].values() if v),
        "results/r2_independent_ensemble.json")
    # the paired range across the three shared-trunk seeds
    _pp = list(R2["comparison"]["per_shared_seed"].values())
    put("r2_ratio_lo", f'{min(p["ratio"] for p in _pp):.3f}',
        "results/r2_independent_ensemble.json")
    put("r2_ratio_hi", f'{max(p["ratio"] for p in _pp):.3f}',
        "results/r2_independent_ensemble.json")
    put("r2_cov_lo", f'{min(p["coverage_diff_pts"] for p in _pp):.2f}',
        "results/r2_independent_ensemble.json")
    put("r2_cov_hi", f'{max(p["coverage_diff_pts"] for p in _pp):.2f}',
        "results/r2_independent_ensemble.json")
    _R2H = sorted(int(h) for h in R2["independent"])
    for h in _R2H:
        i = R2["independent"][str(h)]
        sh = R2["shared_trunk"][str(h)]
        d_ = _dec[str(h)]
        put(f"r2_indep_ratio_h{h}", f'{i["ratio_err_over_sigma"]:.1f}',
            "results/r2_independent_ensemble.json")
        put(f"r2_indep_cov1_h{h}", f'{100 * i["coverage_pm1"]:.2f}',
            "results/r2_independent_ensemble.json")
        put(f"r2_indep_cov2_h{h}", f'{100 * i["coverage_pm2"]:.2f}',
            "results/r2_independent_ensemble.json")
        put(f"r2_shared_ratio_h{h}", f'{sh["mean_ratio"]:.1f}',
            "results/r2_independent_ensemble.json")
        put(f"r2_shared_cov1_h{h}", f'{100 * sh["mean_cov1"]:.2f}',
            "results/r2_independent_ensemble.json")
        put(f"r2_sigma_x_h{h}", f'{d_["sigma_ratio_indep_over_shared"]:.2f}',
            "results/r2_independent_ensemble.json")
        put(f"r2_acc_x_h{h}", f'{d_["error_ratio_shared_over_indep"]:.2f}',
            "results/r2_independent_ensemble.json")
        put(f"r2_total_x_h{h}", f'{d_["total_rho_improvement"]:.2f}',
            "results/r2_independent_ensemble.json")
        if d_["share_from_sigma"] is not None:
            put(f"r2_from_sigma_h{h}", f'{100 * d_["share_from_sigma"]:.0f}',
                "results/r2_independent_ensemble.json")
            put(f"r2_from_acc_h{h}", f'{100 * d_["share_from_accuracy"]:.0f}',
                "results/r2_independent_ensemble.json")
    # The RANGE of the sigma gain across horizons. 6.10 wrote it as
    # "{{r2_sigma_x_h1}}-{{r2_sigma_x_h8}}x at every horizon" -- two named
    # horizons standing in for a range they do not span: h=368's 1.49 sits below
    # the stated lower bound. Found by the horizon sweep, which flagged the
    # sentence for carrying h=1 and h=8 figures while naming h=100 and h=368.
    _sx = [R2["decomposition"][str(h)]["sigma_ratio_indep_over_shared"] for h in _R2H]
    put("r2_sigma_x_lo", f"{min(_sx):.2f}", "results/r2_independent_ensemble.json")
    put("r2_sigma_x_hi", f"{max(_sx):.2f}", "results/r2_independent_ensemble.json")
    put("r2_sigma_x_lo_h", min(_R2H, key=lambda h: _sx[_R2H.index(h)]),
        "results/r2_independent_ensemble.json")
    put("r2_sigma_x_hi_h", max(_R2H, key=lambda h: _sx[_R2H.index(h)]),
        "results/r2_independent_ensemble.json")

    # --- M-68: the combined arm ---------------------------------------------
    # Five independently-initialised full models trained under gaussian_nll:
    # 6.10's topology AND the corrected objective on the same models. Same
    # harness, same arena, same bootstrap, same horizon grid as R2 above, so the
    # keys mirror R2's exactly and the two artifacts can be read side by side.
    C = J("r2_combined_arm.json")
    _m68, _cdec = C["m68"], C["decomposition"]
    _CSRC = "results/r2_combined_arm.json"
    put("m68_nind", C["design"]["n_independent"], _CSRC)
    put("m68_n_indep", len(C["design"]["independent_seeds"]), _CSRC)
    put("m68_n_shared", len(C["design"]["shared_trunk_seeds"]), _CSRC)
    put("m68_verdict", _m68["verdict"], _CSRC)
    put("m68_branch", _m68["branch"], _CSRC)
    put("m68_h", _m68["horizon"], _CSRC)
    put("m68_mde_ratio", f'{_m68["mde_ratio"]:.3f}', _CSRC)
    put("m68_mde_cov", f'{_m68["mde_coverage_pts"]:.2f}', _CSRC)
    put("m68_mde_source", _m68["mde_source"], _CSRC)
    put("m68_sigma_used", _m68["sigma_used_for_coverage"], _CSRC)
    put("m68_n_conditions", len(_m68["conditions"]), _CSRC)
    put("m68_n_conditions_met", sum(1 for v in _m68["conditions"].values() if v), _CSRC)
    put("m68_n_dir", _m68["n_horizons_both_improve_vs_all_three"], _CSRC)
    put("m68_n_horizons", len(_m68["direction_by_horizon"]), _CSRC)
    put("m68_ratio_gain", f'{C["m44"]["mean_ratio_improvement"]:.2f}', _CSRC)
    put("m68_cov_gain", f'{C["m44"]["mean_coverage_gain_pts"]:+.2f}', _CSRC)
    _cpp = list(C["comparison"]["per_shared_seed"].values())
    put("m68_ratio_lo", f'{min(p["ratio"] for p in _cpp):.3f}', _CSRC)
    put("m68_ratio_hi", f'{max(p["ratio"] for p in _cpp):.3f}', _CSRC)
    put("m68_cov_lo", f'{min(p["coverage_diff_pts"] for p in _cpp):.2f}', _CSRC)
    put("m68_cov_hi", f'{max(p["coverage_diff_pts"] for p in _cpp):.2f}', _CSRC)
    _C68H = sorted(int(h) for h in C["independent"])
    for h in _C68H:
        i, sh, d_ = C["independent"][str(h)], C["shared_trunk"][str(h)], _cdec[str(h)]
        put(f"m68_indep_ratio_h{h}", f'{i["ratio_err_over_sigma"]:.1f}', _CSRC)
        put(f"m68_indep_cov1_h{h}", f'{100 * i["coverage_pm1"]:.2f}', _CSRC)
        put(f"m68_indep_cov2_h{h}", f'{100 * i["coverage_pm2"]:.2f}', _CSRC)
        put(f"m68_shared_ratio_h{h}", f'{sh["mean_ratio"]:.1f}', _CSRC)
        put(f"m68_shared_cov1_h{h}", f'{100 * sh["mean_cov1"]:.2f}', _CSRC)
        put(f"m68_shared_cov2_h{h}", f'{100 * sh["mean_cov2"]:.2f}', _CSRC)
        put(f"m68_sigma_x_h{h}", f'{d_["sigma_ratio_indep_over_shared"]:.2f}', _CSRC)
        put(f"m68_acc_x_h{h}", f'{d_["error_ratio_shared_over_indep"]:.2f}', _CSRC)
        put(f"m68_total_x_h{h}", f'{d_["total_rho_improvement"]:.2f}', _CSRC)
        if d_["share_from_sigma"] is not None:
            put(f"m68_from_sigma_h{h}", f'{100 * d_["share_from_sigma"]:.0f}', _CSRC)
            put(f"m68_from_acc_h{h}", f'{100 * d_["share_from_accuracy"]:.0f}', _CSRC)
    # THE OBJECTIVE'S OWN CONTRIBUTION, reported alongside and unable to move the
    # verdict. M-68 scores the combined arm against the SHARED-TRUNK arms, so its
    # verdict measures the pair of fixes together. The isolating comparison is
    # against 6.10's independent arm, which differs from this one only in the
    # objective, and both come from the same script on the same trajectories.
    # It is computed here rather than typed.
    _mse_h = R2["independent"][str(_m68["horizon"])]
    _nll_h = C["independent"][str(_m68["horizon"])]
    _both = _CSRC + " + results/r2_independent_ensemble.json"
    put("m68_vs_mse_ratio",
        f'{_nll_h["ratio_err_over_sigma"] / _mse_h["ratio_err_over_sigma"]:.3f}', _both)
    put("m68_vs_mse_cov_pts",
        f'{100 * (_nll_h["coverage_pm1"] - _mse_h["coverage_pm1"]):+.2f}', _both)
    put("m68_vs_mse_sigma_x",
        f'{_nll_h["mean_sigma"] / _mse_h["mean_sigma"]:.3f}', _both)
    # AND ITS INTERVAL, and whether the design can resolve it. The point estimates
    # above were published bare, and read as "the objective contributes nothing" --
    # a null asserted from an effect SMALLER than the minimum detectable effect the
    # same subsection quotes. That is the M-24 / M-43 failure this paper exists to
    # record, so the isolating comparison now carries the same 95% cluster bootstrap
    # over whole trajectories every governing comparison in 6.11 carries, and the
    # artifact says whether the effect clears the MDE.
    _oi = _m68["objective_isolated"]
    assert abs(_oi["ratio_multiplicative"]
               - _nll_h["ratio_err_over_sigma"] / _mse_h["ratio_err_over_sigma"]) < 1e-9
    put("m68_vs_mse_ratio_ci",
        f'[{_oi["ratio_ci"][0]:.3f}, {_oi["ratio_ci"][1]:.3f}]', _CSRC)
    put("m68_vs_mse_cov_ci",
        f'[{_oi["coverage_ci_pts"][0]:+.2f}, {_oi["coverage_ci_pts"][1]:+.2f}]', _CSRC)

    # --- T1: the bibliography ----------------------------------------------
    T1 = J("t1_bibliography_verified.json")

    # The §2 bibliography, GENERATED. It was a hand-typed list in the template and
    # the six entries added in the revision-3 pass never reached it: §2 cited
    # Malik, Lee, Fort, Wen, Havasi and Seitzer in prose, the footnote under the
    # list claimed "16 of 16 entries verified", and the list itself held ten. A
    # reader could not resolve four of the six at all -- they carried only a venue.
    # A hand-maintained list of what a paper cites is the same defect class as a
    # hand-typed count, and it failed the same way: silently, in the direction that
    # flatters.
    def _initials(name):
        parts = [x for x in name.replace(".", " ").split() if x]
        if len(parts) == 1:
            return parts[0]
        return " ".join(p[0] + "." for p in parts[:-1]) + " " + parts[-1]

    _bib = sorted(T1["entries"], key=lambda e: (e["authors"][0].split()[-1].lower(),
                                                e["year"]))
    _lines = []
    for _n, _e in enumerate(_bib, start=3):
        _au = ", ".join(_initials(a) for a in _e["authors"])
        # Two entries have no venue but the arXiv id itself (they are preprints
        # with no recorded journal_ref), and printing both gave
        # "arXiv:1912.02757. arXiv:1912.02757."
        _ven = "" if _e["venue"].replace("arXiv:", "") == _e["arxiv"] \
            else f'{_e["venue"]}. '
        _lines.append(f'{_n}. {_au}. *{_e["title"]}.* {_ven}'
                      f'arXiv:{_e["arxiv"]}, {_e["year"]}.')
    put("t1_reference_list", "\n".join(_lines), "results/t1_bibliography_verified.json")
    put("t1_first_entry_n", 3, "results/t1_bibliography_verified.json")
    put("t1_last_entry_n", len(_bib) + 2, "results/t1_bibliography_verified.json")
    put("t1_n_refs", T1["n_entries"], "results/t1_bibliography_verified.json")
    put("t1_refs_before", T1["n_references_before"], "results/t1_bibliography_verified.json")
    put("t1_refs_after", T1["n_references_after"], "results/t1_bibliography_verified.json")
    put("t1_n_verified", T1["verification"]["n_metadata_verified"],
        "results/t1_bibliography_verified.json")
    put("t1_n_frag", T1["verification"]["n_fragments_checked"],
        "results/t1_bibliography_verified.json")
    put("t1_n_frag_ok", T1["verification"]["n_fragments_verbatim"],
        "results/t1_bibliography_verified.json")

    # ------------------------------------------------------------------
    # Sessions 2 and 3: M-62, M-63, M-64, M-65, M-66 and the 20-seed
    # corroboration. Every value is read from its artifact; none is typed.
    # ------------------------------------------------------------------
    M62 = J("m62_episode_clustering.json")
    _c3 = M62["cells"]["3_section_6_7_pooled_and_rdd"]["statistics"]
    put("m62_verdict", M62["verdict"]["result"], "results/m62_episode_clustering.json")
    put("m62_n_traj", M62["design"]["all ten"]["n_trajectory_level"],
        "results/m62_episode_clustering.json")
    put("m62_n_ep", M62["design"]["all ten"]["n_episode_level"],
        "results/m62_episode_clustering.json")
    put("m62_width_pct",
        f'{100 * (_c3["pooled_r"]["width_ratio_episode_over_trajectory"] - 1):.0f}',
        "results/m62_episode_clustering.json")
    put("m62_rdd_width_ratio",
        f'{_c3["r_dd"]["width_ratio_episode_over_trajectory"]:.2f}',
        "results/m62_episode_clustering.json")
    put("m62_n_uninformative", M62["verdict"]["n_uninformative_by_construction"],
        "results/m62_episode_clustering.json")
    # Two numerals §6.2 and §6.6 were typing by hand, caught by the typed-numeral audit:
    # the out-of-sample episode count and the 400-step unit's row count. Both are design
    # facts an artifact already records, so they are read rather than typed (rule 4).
    put("m62_n_ep_oos", M62["design"]["out-of-sample"]["n_episode_level"],
        "results/m62_episode_clustering.json")
    put("long_unit_rows", J("task_d_nind20.json")["design"]["traj_len"],
        "results/task_d_nind20.json")

    M63 = J("m63_per_dimension_coverage.json")
    _g63 = M63["arenas"]["released_ckpt_all_ten_h1"]
    put("m63_verdict", M63["verdict"]["result"], "results/m63_per_dimension_coverage.json")
    put("m63_iqr", f'{_g63["iqr_points"]:.1f}', "results/m63_per_dimension_coverage.json")
    put("m63_iqr_thr", "15", "results/m63_per_dimension_coverage.json")
    put("m63_median", f'{_g63["median_pct"]:.1f}', "results/m63_per_dimension_coverage.json")
    put("m63_worst_share", f'{100 * _g63["five_worst_share_of_shortfall"]:.0f}',
        "results/m63_per_dimension_coverage.json")
    put("m63_quant", f'{_g63["quantisation_points"]:.0f}',
        "results/m63_per_dimension_coverage.json")

    M65 = J("m65_gaussian_nominal.json")
    _g65 = M65["cases"]["released_ckpt_ens5 [epistemic] all ten episodes"]["by_horizon"]
    put("m65_c_h1", f'{_g65["1"]["oracle_constant_c"]:.1f}',
        "results/m65_gaussian_nominal.json")
    put("m65_c_h368", f'{_g65["368"]["oracle_constant_c"]:.1f}',
        "results/m65_gaussian_nominal.json")
    put("m65_c_growth", f'{_g65["368"]["oracle_constant_c"] / _g65["1"]["oracle_constant_c"]:.0f}',
        "results/m65_gaussian_nominal.json")
    put("m65_n_heavy", M65["verdict"]["counts"].get("HEAVY-TAILED", 0),
        "results/m65_gaussian_nominal.json")
    put("m65_n_cells", sum(M65["verdict"]["counts"].values()),
        "results/m65_gaussian_nominal.json")
    put("m65_calib_ratio", f'{M65["calibrated_ratio_sqrt_2_over_pi"]:.4f}',
        "results/m65_gaussian_nominal.json")

    M64 = J("m64_short_units.json")
    _c = M64["cells"]["C_section_5_ab_gap"]["out-of-sample held-out pair"]["1"]
    _b = M64["cells"]["B_section_6_7_ranking"]["all ten episodes"]["128"]
    _oos = M64["index"]["out-of-sample held-out pair"]
    put("m64_verdict", M64["verdict"]["result"], "results/m64_short_units.json")
    put("m64_h1_unit", _c["unit_length"], "results/m64_short_units.json")
    put("m64_h1_n", _c["n_independent_unit_level"], "results/m64_short_units.json")
    put("m64_h1_gap", f'{_c["gap"]:+.4f}', "results/m64_short_units.json")
    put("m64_h1_ci",
        f'[{_c["gap_ci_unit_level"][0]:+.4f}, {_c["gap_ci_unit_level"][1]:+.4f}]',
        "results/m64_short_units.json")
    put("m64_h1_ratio", f'{_c["ratio_B_over_A"]:.2f}', "results/m64_short_units.json")
    put("m64_h128_n", _b["n_independent_unit_level"], "results/m64_short_units.json")
    put("m64_h128_lo", f'{_b["paired_diff_ci_unit_level"][0]:+.3f}',
        "results/m64_short_units.json")
    put("m64_h128_ci",
        f'[{_b["paired_diff_ci_unit_level"][0]:+.3f}, {_b["paired_diff_ci_unit_level"][1]:+.3f}]',
        "results/m64_short_units.json")
    put("m64_gate_n", J("m64_free_gate.json")["n_pass"], "results/m64_free_gate.json")
    for _h in ("1", "8", "32", "100", "128"):
        put(f"m64_oos_n_h{_h}", _oos[_h]["n_units"], "results/m64_short_units.json")

    _corr = J("e5_synthetic_sigma.json")["corroboration_20_seeds"]
    _sd = _corr["slope_distribution"]["gaussian_nll"]
    put("e5s_corrob_seeds", _corr["n_seeds"], "results/e5_synthetic_sigma.json")
    put("e5s_corrob_clearing", _sd["n_seeds"] - _sd["n_below_slope_threshold"],
        "results/e5_synthetic_sigma.json")
    put("e5s_corrob_below", _sd["n_below_slope_threshold"],
        "results/e5_synthetic_sigma.json")

    IFR = J("insample_framing.json")
    put("insample_n_overlap", IFR["n_overlap"], "results/insample_framing.json")
    put("insample_n_arena", IFR["n_arena_episodes"], "results/insample_framing.json")

    # 3.2's evidence summary. One row per headline claim, generated by
    # scripts/evidence_summary.py so no arena label and no n_independent in that
    # table is typed; the arena_consistency check compares each row against the
    # section that owns the claim.
    put("evidence_table", J("evidence_summary.json")["table_markdown"],
        "results/evidence_summary.json")

    AUD = J("input_set_audit.json")
    put("audit_n_hits", AUD["n_hits"], "results/input_set_audit.json")
    put("audit_n_frozen", AUD["n_frozen"], "results/input_set_audit.json")

    # ------------------------------------------------------------------
    # Surface every value that is a LITERAL in this file rather than read from
    # an artifact.
    #
    # This revision hit the same defect three times: n_lessons split on the
    # literal "## 9." and silently moved to the Method section; the worst
    # recalibration cell was pinned to h=128 and moved to h=100; and agree_nh was
    # a literal 5 that stayed 5 when the horizon grid grew to six, so the paper
    # said "5 of 5" over a six-row table AND named the wrong horizon.
    #
    # Each was found by a different accident. A literal here is not always wrong
    # -- a tolerance, a nominal, a fixed convention -- but it is always worth
    # LOOKING at, which is what build_paper.py's typed-numeral report does for
    # prose. This does it for the collector, so the class has to be looked at
    # rather than rediscovered.
    import ast as _ast
    _src = _ast.parse(open(__file__).read())
    _lits = []
    for _n in _ast.walk(_src):
        if (isinstance(_n, _ast.Call) and isinstance(_n.func, _ast.Name)
                and _n.func.id == "put" and len(_n.args) >= 2):
            _k, _v = _n.args[0], _n.args[1]
            if isinstance(_v, _ast.Constant) and isinstance(_v.value, (int, float)) \
                    and not isinstance(_v.value, bool) \
                    and isinstance(_k, _ast.Constant):
                _lits.append((_k.value, _v.value, _v.lineno))
    if _lits:
        print(f"\n  LITERAL VALUES ({len(_lits)}) — each is typed here, not read from an "
              f"artifact. Check that none is bound to something that can move:")
        for _k, _v, _ln in sorted(_lits):
            print(f"    line {_ln:>5}  {_k:<24} = {_v}")

    op = os.path.join(R.RESULTS, "paper_numbers.json")
    json.dump(N, open(op, "w"), indent=2, sort_keys=True)
    print(f"collected {len(N)} keyed numbers -> {R.rel(op)}")
    for k in sorted(N):
        print(f"  {k:<28} {str(N[k]['value']):<16} {N[k]['source']}")


if __name__ == "__main__":
    main()
