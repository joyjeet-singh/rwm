"""
Ledger consistency check (release brief 1.1) -- also the claims-to-evidence map (3.4).

Every CONTRIB entry must carry an evidence class of SRC, DATA or RUN, and every
artifact it names must exist. An INFER-only CONTRIB entry is a blocker.

Third invariant, added after the review found R-27 still tagged CONFIRMED / CONTRIB
while S-10 retracted it, and rendered as CONFIRMED in the release-facing claims map:
every S-* entry declares a **Retracts** line naming the IDs it supersedes, and each
named ID must carry SUPERSEDED or RETRACTED in its own Status line and must not still
be tagged CONTRIB. A retraction that only exists in the retracting entry is invisible
to anyone reading the claim it retracts.
"""
import os, re, sys, json

# The artifact this check writes, as a module constant so scripts/pipeline_coverage.py can see the
# write (it resolves constants; a "results/..." literal it does not). Round 2, T8.
CLAIMS_OUT = "claims_to_evidence.json"
LEDGER="FINDINGS_LEDGER.md"
txt=open(LEDGER).read()
blocks=re.split(r'\n### ', txt)
rows=[]
for b in blocks[1:]:
    m=re.match(r'([A-Z]-\d+)\s+—\s+(.*?)(?:\s+·|\n)', b)
    if not m: continue
    eid, claim = m.group(1), m.group(2).strip().rstrip('·').strip()
    body=b
    rel=re.search(r'\*\*Relevance\*\*\s*([A-Z]+)', body)
    relevance=rel.group(1) if rel else ""
    if not relevance:
        rel2=re.search(r'·\s*\*\*Relevance\*\*\s*([A-Z]+)', body)
        relevance=rel2.group(1) if rel2 else ""
    st=re.search(r'\*\*Status\*\*\s*(.+)', body)
    status=st.group(1).split('·')[0].strip() if st else ""
    ev=re.findall(r'`(SRC|DATA|RUN|EXT|INFER)`', body)
    arts=set(re.findall(r'`(results/[\w./-]+|figures/[\w./-]+|src/[\w./-]+|scripts/[\w./-]+)`', body))
    retr=re.search(r'\*\*Retracts\*\*\s*(.+)', body)
    rows.append({"id":eid,"claim":claim[:88],"relevance":relevance,"status":status,
                 "evidence":sorted(set(ev)),"artifacts":sorted(arts),
                 "retracts":sorted(set(re.findall(r'\b([A-Z]-\d+)\b', retr.group(1)))) if retr else []})
contrib=[r for r in rows if r["relevance"]=="CONTRIB"]
print("="*100); print("LEDGER CONSISTENCY CHECK"); print("="*100)
print(f"  entries parsed: {len(rows)}   tagged CONTRIB: {len(contrib)}")
hard={"SRC","DATA","RUN"}
flagged=[r for r in contrib if not (set(r["evidence"]) & hard)]
missing=[]
pending=[]
for r in rows:
    # A rule that is pre-registered but not yet discharged names the artifact that
    # WILL discharge it, and that artifact does not exist yet -- that is the whole
    # point of pre-registering. Such an entry is listed as pending rather than
    # flagged as a blocker; anything else would make it impossible to commit a rule
    # before the data, which is the standard this project holds itself to (M-24,
    # M-43, S-12). Every other entry's artifacts must exist.
    prereg = "NOT YET DISCHARGED" in r["status"].upper()
    for a in r["artifacts"]:
        if os.path.exists(a): continue
        (pending if prereg else missing).append((r["id"],a))
print(f"\n  CONTRIB entries lacking SRC/DATA/RUN evidence: {len(flagged)}")
for r in flagged:
    print(f"    !! {r['id']}  evidence={r['evidence'] or 'NONE PARSED'}  {r['claim'][:60]}")
print(f"\n  named artifacts that do not exist: {len(missing)}")
for eid,a in missing[:20]: print(f"    !! {eid} -> {a}")
prereg_ids=sorted({r["id"] for r in rows if "NOT YET DISCHARGED" in r["status"].upper()})
print(f"\n  pre-registered rules not yet discharged: {len(prereg_ids)}"
      + (f"  ({', '.join(prereg_ids)})" if prereg_ids else ""))
for eid,a in pending: print(f"     - {eid} awaits {a}")

by_id={r["id"]:r for r in rows}
supersessions=[(r["id"],t) for r in rows for t in r["retracts"]]
unmarked=[]
for sid,tid in supersessions:
    t=by_id.get(tid)
    if t is None:
        unmarked.append((sid,tid,"target does not exist")); continue
    st=t["status"].upper()
    if "SUPERSEDED" not in st and "RETRACTED" not in st:
        unmarked.append((sid,tid,f"target Status is {t['status'][:40]!r}"))
    elif t["relevance"]=="CONTRIB" and "IN PART" not in st:
        # a wholly superseded claim must not still be advertised as a contribution;
        # SUPERSEDED IN PART may, because part of it still stands.
        unmarked.append((sid,tid,"target still tagged CONTRIB"))
declared=[r["id"] for r in rows if r["id"].startswith("S-") and not r["retracts"]
          and not re.search(r'\*\*Retracts\*\*', txt.split("### "+r["id"])[1].split("\n### ")[0])]
print(f"\n  supersessions declared: {len(supersessions)}")
print(f"  retractions not reflected in the retracted entry: {len(unmarked)}")
for sid,tid,why in unmarked: print(f"    !! {sid} retracts {tid} but {why}")
if declared:
    print(f"  S-* entries with no **Retracts** line: {len(declared)}")
    for d in declared: print(f"    !! {d}")
# Fifth (pre-submission S5): the three retraction counts the paper prints. Every S-
# entry is exactly one of: a claim withdrawn on evidence (its **Retracts** line names the
# IDs it supersedes); a framing withdrawn (the line opens with an em dash -- a sentence
# withdrawn, not a numbered claim); or an early hypothesis closed as housekeeping (an
# em-dash line saying "early hypothesis"). paper_numbers.py reads the counts from the JSON
# below, so the introduction, section 8, the README and the supplement cannot count them
# two ways. This classification used to live in paper_numbers.py.
classes={"evidence":[], "framing":[], "early_hypothesis":[]}
unclassed=[]
for r in rows:
    if not r["id"].startswith("S-"): continue
    blk=txt.split("### "+r["id"]+" ",1)[1].split("\n### ")[0]
    m=re.search(r'^\*\*Retracts\*\* (.+)$', blk, re.M)
    if not m:
        unclassed.append(r["id"]); continue
    line=m.group(1).lstrip()
    if not line.startswith("\u2014"): classes["evidence"].append(r["id"])
    elif "early hypothesis" in line: classes["early_hypothesis"].append(r["id"])
    else: classes["framing"].append(r["id"])
# Sixth (round 2, ruling U1): a later entry may RECLASSIFY an S- entry. The ledger is append-only,
# so an S- entry's own **Retracts** line can never be edited; the reclassifying entry carries
#     **Reclassifies** `S-NN` as evidence | framing | early hypothesis
# Each S- entry may be reclassified at most once; the target must exist, must be classed above,
# and must change class. The reclassification is applied after the classification it corrects and
# is written to results/claims_to_evidence.json beside the classes.
reclassified=[]
_ckey={"evidence":"evidence","framing":"framing","early hypothesis":"early_hypothesis"}
for r in rows:
    blk=txt.split("### "+r["id"]+" ",1)[1].split("\n### ")[0]
    for m in re.finditer(r'^\*\*Reclassifies\*\* `(S-\d+)` as (evidence|framing|early hypothesis)\s*$', blk, re.M):
        tgt,to=m.group(1),_ckey[m.group(2)]
        frm=next((c for c,ids in classes.items() if tgt in ids),None)
        if frm is None: unclassed.append(f"{r['id']} reclassifies {tgt}, which no class holds"); continue
        if frm==to: unclassed.append(f"{r['id']} reclassifies {tgt} into the class it is already in"); continue
        if any(x["target"]==tgt for x in reclassified): unclassed.append(f"{tgt} is reclassified twice"); continue
        classes[frm].remove(tgt); classes[to].append(tgt)
        reclassified.append({"target":tgt,"from":frm,"to":to,"by":r["id"]})
for x in reclassified:
    print(f"\n  reclassified: {x['target']} {x['from']} -> {x['to']}, by {x['by']}")
n_sup=sum(1 for r in rows if r["id"].startswith("S-"))
if sum(len(v) for v in classes.values())!=n_sup and not unclassed:
    unclassed.append("the classes do not partition the S- entries")
print(f"\n  retraction classes: {len(classes['evidence'])} claims withdrawn on evidence, "
      f"{len(classes['framing'])} framings withdrawn, {len(classes['early_hypothesis'])} early "
      f"hypotheses closed; {n_sup} superseded entries in all")
for u in unclassed: print(f"    !! {u}: no **Retracts** line the classes can read")
# Fourth invariant: RESULTS.md's discrepancy table is a hand-maintained count of
# ledger entries by prefix. It had drifted 11 entries across four rows before anyone
# noticed, and it is trivially derivable. Check it.
import collections
counts=collections.Counter(r["id"].split("-")[0] for r in rows)
stale=[]
try:
    res=open("RESULTS.md").read()
    for pfx,n in sorted(counts.items()):
        m=re.search(r'^\|\s*`'+pfx+r'-`[^|]*\|\s*(\d+)\s*\|', res, re.M)
        if m and int(m.group(1))!=n:
            stale.append((pfx,int(m.group(1)),n))
except FileNotFoundError:
    pass
print(f"\n  entry counts by prefix: "
      + ", ".join(f"{k}-{v}" for k,v in sorted(counts.items())))
print(f"  RESULTS.md discrepancy-table rows out of date: {len(stale)}")
for pfx,said,real in stale:
    print(f"    !! {pfx}- : RESULTS.md says {said}, ledger has {real}")
json.dump({"entries":rows,"counts_by_prefix":dict(sorted(counts.items())),
           "retraction_classes":{**classes,"n_superseded":n_sup,"reclassified":reclassified}},
          open(os.path.join("results", CLAIMS_OUT),"w"),indent=2)
with open("results/claims_to_evidence.md","w") as f:
    f.write("# Claims-to-evidence map\n\nOne row per CONTRIB ledger entry.\n\n")
    f.write("| ID | Claim | Evidence | Status | Artifacts |\n|---|---|---|---|---|\n")
    for r in contrib:
        f.write(f"| `{r['id']}` | {r['claim']} | {', '.join('`'+e+'`' for e in r['evidence']) or '—'} "
                f"| {r['status'][:40]} | {', '.join('`'+a+'`' for a in r['artifacts'][:2]) or '—'} |\n")
print(f"\n  wrote results/claims_to_evidence.md ({len(contrib)} CONTRIB rows)")
ok = not flagged and not missing and not unmarked and not declared and not stale and not unclassed
print(f"\n  RESULT: {'PASS' if ok else 'BLOCKER -- see flags above'}")
sys.exit(0 if ok else 1)
