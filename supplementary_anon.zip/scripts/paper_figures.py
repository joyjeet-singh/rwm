"""Figures for the paper. Every number is read from results/, none is typed.

Writes figures/paper_fig{1..5}.png and results/paper_figures.json, which records
the values each panel plots so a reader can check the figure against the data.
"""
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "src"))
import matplotlib  # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import rwm_data as R  # noqa: E402

plt.rcParams.update({
    "figure.dpi": 160, "savefig.dpi": 160, "font.size": 9,
    "axes.grid": True, "grid.alpha": 0.25, "grid.linewidth": 0.5,
    "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "axes.titlesize": 10, "axes.titleweight": "bold",
})
C = {"faithful": "#1f77b4", "corrected": "#2ca02c", "armB": "#d62728", "released": "#7f4fc4"}


def J(name):
    return json.load(open(os.path.join(R.RESULTS, name)))


def fig1_calibration(rec):
    """The uncertainty output is unusable, and by how much."""
    d = J("task1_calibration.json")
    order = [("faithful (mse)", "faithful Arm A (mse)", C["faithful"]),
             ("corrected (nll)", "corrected Arm A (nll)", C["corrected"]),
             ("teacher-forced armB", "teacher-forced Arm B", C["armB"]),
             ("released ckpt", "released checkpoint", C["released"])]
    fig, ax = plt.subplots(1, 3, figsize=(10.5, 3.2))

    # (a) reliability: predicted vs observed coverage
    for k, lab, col in order:
        rel = d[k]["reliability"]
        ax[0].plot([r["predicted"] for r in rel], [r["observed"] for r in rel],
                   "o-", ms=3, lw=1.4, color=col, label=lab)
    ax[0].plot([0, 1], [0, 1], "k--", lw=1, label="calibrated")
    ax[0].set(xlabel="predicted coverage", ylabel="observed coverage",
              title="(a) reliability", xlim=(0, 1), ylim=(0, 1))
    # The main panel is unchanged: all four curves hugging the axis far below the diagonal
    # IS the finding. At this scale, though, the four are indistinguishable, so the SAME
    # points are drawn again in an inset with observed coverage on a log scale. The inset
    # sits in the upper-left triangle, above the diagonal, where this data does not fall; the
    # legend moves to the lower right, below the diagonal and above every curve. Nothing
    # plotted changes -- the inset reads the very `rel` lists the main panel reads, and no
    # observed value is zero, so a log axis drops no point.
    ins = ax[0].inset_axes([0.13, 0.59, 0.33, 0.35])
    for k, lab, col in order:
        rel = d[k]["reliability"]
        obs = [r["observed"] for r in rel]
        assert min(obs) > 0, f"{k}: a zero observed coverage cannot be drawn on a log axis"
        ins.plot([r["predicted"] for r in rel], obs, "o-", ms=2, lw=1.0, color=col)
    ins.set_yscale("log")
    ins.set_xlim(0.1, 1.06)            # a little past 1 so no marker is clipped
    ins.set_title("same data, log scale", fontsize=5.5, fontweight="normal", pad=2)
    ins.tick_params(labelsize=5, length=2, pad=1)
    ins.set_xticks([0.2, 0.6, 1.0])
    ax[0].legend(fontsize=6, loc="lower right", bbox_to_anchor=(0.995, 0.28),
                 handlelength=1.4, labelspacing=0.3, borderpad=0.3, markerscale=0.8)

    # (b) coverage at +-1 sigma against horizon
    hs = sorted(int(h) for h in d[order[0][0]]["coverage"])
    for k, lab, col in order:
        ax[1].plot(hs, [100 * d[k]["coverage"][str(h)]["pm1"] for h in hs],
                   "o-", ms=3, lw=1.4, color=col, label=lab)
    # C3(rev2), 3.9. This was a typed 68.3 while 3.1 derives 68.27 and the paper
    # quotes that everywhere else, so the figure and its caption disagreed with
    # the text about a constant. Read from V3, which is where 3.1 derives it.
    _nom1 = 100 * json.load(open(os.path.join(
        R.RESULTS, "v3_metric_definitions.json")))["coverage"]["nominal"]["pm1"]
    ax[1].axhline(_nom1, color="k", ls="--", lw=1)
    ax[1].text(hs[-1], _nom1 + 1.7, f"calibrated {_nom1:.2f}%", ha="right", fontsize=7)
    ax[1].set(xscale="log", xlabel="forecast horizon (steps)",
              ylabel=r"coverage at $\pm1\sigma$ (%)", # was "(b) coverage collapses with horizon", which rendered at 1.10x the
              # axes width and clipped. The caption carries the full statement.
              title="(b) coverage vs horizon")

    # (c) how many times too small sigma is
    labs = [lab for _, lab, _ in order]
    vals = [d[k]["ratio_err_over_sigma"] for k, _, _ in order]
    cols = [c for _, _, c in order]
    ax[2].barh(range(len(vals)), vals, color=cols, height=0.6)
    ax[2].set_yticks(range(len(vals)))
    ax[2].set_yticklabels([l.replace(" ", "\n", 1) for l in labs], fontsize=7)
    ax[2].set(xscale="log", xlabel=r"mean $|$error$|$ / mean $\sigma$",
              title="(c) overconfidence factor")
    ax[2].axvline(1.0, color="k", ls="--", lw=1)
    for i, v in enumerate(vals):
        ax[2].text(v * 1.15, i, f"{v:,.0f}×", va="center", fontsize=7)
    ax[2].invert_yaxis()
    rec["fig1"] = {"ratio_err_over_sigma": {lab: d[k]["ratio_err_over_sigma"] for k, lab, _ in order},
                   "coverage_pm1_by_horizon": {lab: {str(h): d[k]["coverage"][str(h)]["pm1"] for h in hs}
                                               for k, lab, _ in order}}
    fig.tight_layout()
    p = os.path.join(R.FIGURES, "paper_fig1_calibration.png")
    fig.savefig(p); plt.close(fig)
    return p


def fig2_sigma_profile(rec):
    """sigma is flat inside the trained horizon while error grows."""
    d = J("task2_sigma_profile.json")
    order = [("faithful armA (mse)", "faithful Arm A (mse)", C["faithful"]),
             ("corrected armA (nll)", "corrected Arm A (nll)", C["corrected"]),
             ("teacher-forced armB", "teacher-forced Arm B", C["armB"]),
             ("released checkpoint", "released checkpoint", C["released"])]
    fig, ax = plt.subplots(1, 2, figsize=(7.6, 3.2))
    for k, lab, col in order:
        s = np.array(d[k]["sigma_by_step"], float)
        e = np.array(d[k]["err_by_step"], float)
        steps = np.arange(1, len(s) + 1)
        ax[0].plot(steps, s / s[0], "o-", ms=3, lw=1.4, color=col, label=lab)
        ax[1].plot(steps, e / e[0], "o-", ms=3, lw=1.4, color=col, label=lab)
    for a, t in ((ax[0], r"(a) predicted $\sigma$"),
                 (ax[1], "(b) realised error")):
        a.axhline(1.0, color="k", ls="--", lw=1)
        a.set(xlabel="forecast step (training horizon is 8)", title=t)
    ax[0].set_ylabel(r"$\sigma_h/\sigma_1$"); ax[1].set_ylabel(r"$|e_h|/|e_1|$")
    # Lower left, which the data leave empty: the curves all start at 1.00 and only the
    # faithful arm falls, to the right. At upper left the dashed 1.00 line struck through
    # the "teacher-forced Arm B" entry and the legend covered the first four steps
    # (round 2, T8; docs/DEFERRED.md, session 28).
    ax[0].legend(fontsize=6.5, loc="lower left")
    rec["fig2"] = {k: {"sigma_growth_1_to_8": d[k]["sigma_growth_1_to_8"],
                       "err_growth_1_to_8": d[k]["err_growth_1_to_8"]} for k, _, _ in order}
    fig.tight_layout()
    p = os.path.join(R.FIGURES, "paper_fig2_sigma_profile.png")
    fig.savefig(p); plt.close(fig)
    return p


def fig6_ab_by_horizon(rec):
    """The A/B advantage as a curve, because as a point it looks selected.

    5 led with 4.61x at h=368 while 3.1 says h=368 is not a deployment horizon,
    and the same comparison at h=100 is 2.58x. The curve is the honest form: the
    advantage grows monotonically with forecast depth, it is not established at
    h=1 -- where the interval spans zero and teacher forcing is nominally ahead
    -- and h=368 is the end of a trend rather than a point someone picked.
    """
    d = J("a1_ab_by_horizon.json")
    hs = d["design"]["horizons"]
    fig, ax = plt.subplots(1, 2, figsize=(7.6, 3.2))

    r = [d["by_horizon"][str(h)]["ratio_B_over_A"] for h in hs]
    ax[0].plot(hs, r, "o-", ms=4, lw=1.6, color=C["armB"])
    ax[0].axhline(1.0, color="k", ls="--", lw=1)
    # Placement only; no plotted value depends on any of it (round 2, T8; docs/DEFERRED.md,
    # block B1). "no difference" sat above the line at h = 1, where the h = 1 value label
    # overprinted it and the curve ran through it; it now sits under the line at the
    # horizons' geometric mean, between the h = 10 gridline and the h = 100 reference,
    # where every ratio is well above 1. The floor drops by a tenth of the range so the
    # labels under the line clear the axis.
    _lo = min(min(r), 1.0)
    ax[0].set_ylim(bottom=_lo - 0.1 * (max(r) - _lo))
    ax[0].annotate("no difference", (float(np.exp(np.mean(np.log(hs)))), 1.0),
                   textcoords="offset points", xytext=(0, -3), ha="center", va="top",
                   fontsize=6.5, color="#555555")
    for i, (h, y) in enumerate(zip(hs, r)):
        crowd_next = i + 1 < len(hs) and hs[i + 1] / h < 1.5
        crowd_prev = i > 0 and h / hs[i - 1] < 1.5
        if y < 1.0:                   # below the line: label below-right, away from it
            kw = dict(xytext=(5, -3), ha="left", va="top")
        elif crowd_next:              # two horizons this close (h = 100, 128) split left...
            kw = dict(xytext=(-4, 2), ha="right", va="bottom")
        elif crowd_prev:              # ...and right, instead of both centred above
            kw = dict(xytext=(4, -2), ha="left", va="top")
        elif i == len(hs) - 1:        # the last point is the highest: left, off the top edge
            kw = dict(xytext=(-6, 0), ha="right", va="center")
        else:
            kw = dict(xytext=(0, 6), ha="center", va="bottom")
        ax[0].annotate(f"{y:.2f}x", (h, y), textcoords="offset points", fontsize=6.5, **kw)
    ax[0].set(xscale="log", xlabel="forecast horizon (steps)",
              ylabel="teacher forcing / autoregressive",
              title="(a) the advantage grows with horizon")

    # the gap and its interval, so "not established at h=1" is visible rather
    # than asserted
    g = np.array([d["by_horizon"][str(h)]["gap"] for h in hs])
    lo = np.array([d["by_horizon"][str(h)]["gap_ci"][0] for h in hs])
    hi = np.array([d["by_horizon"][str(h)]["gap_ci"][1] for h in hs])
    ax[1].errorbar(hs, g, yerr=[g - lo, hi - g], fmt="o", ms=4, lw=1.4,
                   capsize=3, color=C["faithful"])
    ax[1].axhline(0.0, color="k", ls="--", lw=1)
    ax[1].set(xscale="log", xlabel="forecast horizon (steps)",
              ylabel="Arm B $-$ Arm A (relative-L1)",
              title="(b) gap, 95% cluster bootstrap")
    # Top-left of the panel, which the data leave empty (the large gaps are all at long
    # horizons, on the right). It used to sit at axes y = 0.04, which is where the dashed
    # zero line falls, so the line struck through the annotation it was explaining.
    # Two lines, so it also stops short of the dotted h = 100 reference line.
    ax[1].text(0.02, 0.97, f"n_independent = {d['design']['n_independent']};\n"
                           f"the interval spans zero only at h=1",
               transform=ax[1].transAxes, ha="left", va="top", fontsize=6.5,
               color="#555555")

    for h in (100, 368):
        for a in ax:
            a.axvline(h, color="#bbbbbb", lw=0.8, ls=":", zorder=0)
    rec["fig6"] = {"ratios": {str(h): d["by_horizon"][str(h)]["ratio_B_over_A"] for h in hs},
                   "monotone_increasing": d["trend"]["monotone_increasing"],
                   "spans_zero_at": d["trend"]["spans_zero_at"]}
    fig.tight_layout()
    p = os.path.join(R.FIGURES, "paper_fig6_ab_by_horizon.png")
    fig.savefig(p); plt.close(fig)
    return p


def fig3_collapse(rec):
    """The variance collapse is linear, identical across every run."""
    import glob
    fig, ax = plt.subplots(1, 2, figsize=(7.6, 3.2))
    # The released architecture width, from the reference config. Panel (a) shows
    # every run; panel (b) is the family the QUOTED RATE is fitted over, and that
    # rate is §6.3's claim that the collapse is "nearly identical across runs" --
    # a claim about one architecture. paper_numbers.py was given this guard when
    # M-49's five width-124 runs appeared; this file was not, so the published
    # figure's legend read "sampled-MSE runs (n=22)" beside a text that said 17,
    # under a sentence asserting that the figure and the statistic describe the
    # same set. Same source of truth as paper_numbers.py: the width each run
    # artifact records for itself.
    _released_w = R.load_reference_config(R.repo_paths()["lite"])[
        "architecture_config"]["rnn_hidden_size"]
    runs, slopes, offwidth = [], [], []
    for f in sorted(glob.glob(os.path.join(R.RESULTS, "step5_arm*.json"))):
        tag = os.path.basename(f)[len("step5_"):-len(".json")]
        d = json.load(open(f))
        _w = d.get("hyperparameters", {}).get("rnn_hidden_size", _released_w)
        if _w != _released_w:
            offwidth.append(tag)
            continue
        col = C["armB"] if tag.startswith("armB") else (
            C["corrected"] if tag.endswith("_nll") else C["faithful"])
        it = [c["iter"] for c in d["collapse"]]
        v = [c["log_delta_logstd_mean"] for c in d["collapse"]]
        ax[0].plot(it, v, lw=0.9, alpha=0.75, color=col)
        runs.append(tag)
        if d.get("collapse_fit"):
            slopes.append((tag, d["collapse_fit"]["slope_per_iter"]))
    ax[0].set(xlabel="iteration", ylabel=r"mean $\log\Delta_{\log\sigma}$",
              title=f"(a) collapse trajectory,\nall {len(runs)} runs superimposed")
    rec["fig3_offwidth_excluded"] = sorted(offwidth)
    # Panel (b) must plot the same set the quoted rate is fitted on. The six
    # 10,000-iteration runs continue seeds already present at 2,500, so including
    # them here would show n=18 beside a statistic computed on n=12.
    fitted = [(t, s) for t, s in slopes if "_10k" not in t]
    mse = [s for t, s in fitted if not t.endswith("_nll")]
    nll = [s for t, s in fitted if t.endswith("_nll")]
    ax[1].axhline(0, color="k", lw=1)
    for vals, lab, col in ((mse, "sampled-MSE runs", C["faithful"]),
                           (nll, "gaussian_nll runs", C["corrected"])):
        if vals:
            ax[1].scatter(np.arange(len(vals)), vals, s=18, color=col, label=f"{lab} (n={len(vals)})")
    ax[1].set(xlabel="run", ylabel="fitted slope per iteration",
              # "non-double-counting subset" overran the axes and rendered as
              # "non-double-counting subse". The subset is defined in the caption
              # and in section 5.3; the title only has to name the panel.
              title="(b) fitted rate, fitted subset:\nsign flips with the objective")
    ax[1].legend(fontsize=7)
    rec["fig3"] = {"n_runs": len(runs), "slopes": dict(slopes)}
    fig.tight_layout()
    p = os.path.join(R.FIGURES, "paper_fig3_collapse.png")
    fig.savefig(p); plt.close(fig)
    return p


def fig4_timeline(rec):
    """Pre-registration lead time: rule commit minus the data it tested.

    Positive means the rule was in git before the data existed. The Task 3 rule is
    negative, and is drawn that way rather than omitted -- S-12 retracts the claim
    that it was pre-registered, and a figure that quietly dropped it would be
    making the claim the ledger withdraws.
    """
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir)

    def when(h):
        o = subprocess.run(["git", "show", "-s", "--format=%at", h],
                           capture_output=True, text=True, cwd=here)
        return int(o.stdout.strip())

    def resolve(h, subject):
        """The commit for this rule, by hash if it still exists and by SUBJECT if
        it does not.

        Figure 4's whole argument is that a reader can check these hashes against
        the published history, so a dangling one is not cosmetic. Two of them
        dangled: purging the correspondence transcript from history (M-48)
        rewrote every commit from the one that introduced it onward, and the two
        Phase-1/Phase-2 data commits took new identifiers. Nothing about the
        ordering moved -- same timestamps, same content but for the removed file
        -- but the identifiers the figure cited stopped resolving.

        Subjects are stable across a path filter and hashes are not, so the
        subject is the lookup key and the hash is what gets printed. Both are
        asserted: exactly one commit must match, and if the recorded hash still
        exists its subject must be the recorded one.
        """
        o = subprocess.run(["git", "log", "--all", "--format=%H\t%s"],
                           capture_output=True, text=True, cwd=here)
        hits = [ln.split("\t", 1) for ln in o.stdout.splitlines() if "\t" in ln]
        match = [c for c, subj in hits if subj == subject]
        assert len(match) == 1, (
            f"{len(match)} commits have the subject {subject!r}; Figure 4 needs "
            f"exactly one, because the subject is what survives a history rewrite")
        cur = subprocess.run(["git", "rev-parse", "-q", "--verify", h + "^{commit}"],
                             capture_output=True, text=True, cwd=here)
        if cur.returncode == 0:
            got = subprocess.run(["git", "show", "-s", "--format=%s", h],
                                 capture_output=True, text=True, cwd=here).stdout.strip()
            assert got == subject, (
                f"the hash recorded for {subject!r} ({h}) is a different commit: {got!r}")
        return match[0][:7]

    # (label, rule commit, its subject, data commit, its subject, data label).
    # The subjects are here because hashes do not survive a history rewrite and
    # subjects do; see resolve() above and M-48.
    CASES = [
        ("M-16\nthe A/B decision rule", "C004",
         "Step 5: pre-register the decision rule before launching any main run", "C005",
         "Step 5: Arm A seed 0 complete; collapse prediction confirmed to 3 dp",
         "first main-run data"),
        ("flip pattern\ninterpretation", "C007",
         "Pre-register interpretation of one M-16 flip pattern", "C009",
         "Step 5.4: Arms A and B, three seeds each - M-16 evaluated",
         "all six main runs"),
        ("M-22\ndifficulty-bias rule", "C013",
         "Pre-register the Task 4b difficulty-bias rule, and the two-arena convention", "C014",
         "M-16 returns CANNOT BE SETTLED under corrected measurement",
         "M-16 re-evaluated"),
        ("M-23\nlong-horizon rule", "C016",
         "5.1: pre-register M-23, the long-horizon decision rule", "C017",
         "5.2: bootstrap CIs over independent trajectories; launch the 10k runs", "10k runs launched"),
        # The ensemble-5 rule and the two rules of the pre-submission revision.
        # P1 required the last two to be committed before any Phase 1 or Phase 2
        # artifact and their hash recorded here, which is what these rows are.
        ("M-43\nensemble-5 replication", "C081",
         "PRE-REGISTER the ensemble-5 replication rule, before the runs exist", "C086",
         "Parts D and E: the ensemble-5 replication, M-43's verdict, and the cascade",
         "ens5 result committed"),
        ("M-45\nwithin-trajectory control", "C090",
         "PRE-REGISTER M-44 and M-45, with the power check M-43 was committed without",
         "C091",
         "Phases 1, 3 and 4 of the revision: intervals, the missing control, related work",
         "A2 result committed"),
        ("M-44\ntrunk-sharing mechanism", "C090",
         "PRE-REGISTER M-44 and M-45, with the power check M-43 was committed without",
         "C098",
         "Phase 2: M-44 returns MECHANISM SUPPORTED, with the part that keeps it honest",
         "R2 result committed"),
    ]
    rows = []
    resolved = []
    for lab, rule, rule_subj, data, data_subj, dlab in CASES:
        rule, data = resolve(rule, rule_subj), resolve(data, data_subj)
        resolved.append({"rule": lab.replace("\n", " "), "rule_commit": rule,
                         "data_commit": data, "tested_by": dlab})
        rows.append((lab, (when(data) - when(rule)) / 3600.0, dlab))
    # Task 3: the control runs finished before any threshold reached git. This is
    # the ONE negative bar in the figure and the one the paper's self-criticism
    # rests on (S-12), so it has to be computed at least as carefully as the seven
    # positive ones. It was not. Three defects, all fixed here:
    #
    #  1. "21:37:51" was TYPED, transcribed by hand from control_driver.log. It is
    #     parsed from that log now -- the last "done seed" line -- so the figure's
    #     own data side is read rather than remembered.
    #  2. datetime.fromtimestamp() is LOCAL time, so the same arithmetic gave
    #     -2.94 h in IST, -21.44 h in UTC and -14.44 h in US/Pacific. A reviewer
    #     rebuilding the paper outside the author's timezone got a different
    #     number, which also breaks the byte-identical rebuild this project
    #     requires. The offset now comes from the COMMIT that introduced the log,
    #     via %ci, so the conversion is the same everywhere.
    #  3. "C025" was used raw while the other seven rows go through resolve(),
    #     which asserts hash-against-subject precisely because hashes do not
    #     survive a history rewrite. It is resolved now.
    import datetime
    import re as _re
    T3_RULE_SUBJ = ("Task 3: the duplication control confirms R-47's mechanism "
                    "and refutes its statistic")
    t3_rule = resolve("C025", T3_RULE_SUBJ)

    log_path = os.path.join(R.RESULTS, "control_driver.log")
    assert os.path.exists(log_path), (
        "results/control_driver.log is missing; the Task 3 bar's data side cannot "
        "be derived and must not be typed")
    _times = _re.findall(r"^=== (\d{2}:\d{2}:\d{2}) done seed", open(log_path).read(), _re.M)
    assert _times, "no 'done seed' line in control_driver.log"
    _finish_clock = _times[-1]

    # The log records wall clock with no date and no offset. Both come from the
    # commit that introduced THAT LINE -- not the one that created the file. The
    # file was created a day earlier with partial content and the final "done
    # seed" line landed in the rule's own commit; anchoring on file creation put
    # the finish 24 hours early and turned -2.94 h into -26.94 h.
    _line_commit = subprocess.run(
        ["git", "log", "--format=%H", "-S", f"{_finish_clock} done seed",
         "--", "results/control_driver.log"],
        capture_output=True, text=True, cwd=here).stdout.split()
    assert _line_commit, (
        f"no commit introduces '{_finish_clock} done seed' into control_driver.log; "
        "the Task 3 bar's date anchor cannot be derived")
    t3_log = _line_commit[-1][:7]
    _ci = subprocess.run(["git", "show", "-s", "--format=%ci", t3_log],
                         capture_output=True, text=True, cwd=here).stdout.strip()
    _log_dt = datetime.datetime.strptime(_ci, "%Y-%m-%d %H:%M:%S %z")
    _h, _m, _sec = (int(x) for x in _finish_clock.split(":"))
    done = _log_dt.replace(hour=_h, minute=_m, second=_sec)
    # The runs finished before the log was committed; if the clock time is later
    # in the day than the commit, the run finished the previous day.
    if done > _log_dt:
        done -= datetime.timedelta(days=1)
    rows.append(("Task 3\nduplication rule",
                 (done.timestamp() - when(t3_rule)) / 3600.0,
                 f"control runs finished {_finish_clock}"))
    resolved.append({"rule": "Task 3 duplication rule", "rule_commit": t3_rule,
                     "data_commit": t3_log,
                     "tested_by": f"control runs finished {_finish_clock}",
                     "data_side": "results/control_driver.log, parsed; date and UTC "
                                  "offset from the commit that introduced it"})

    # The eight lead times above are this figure's own record ("fig4"), which Appendix E reads for the rules it
    # covers; they are kept, unchanged, below.
    rec["fig4_commits"] = resolved
    rec["fig4"] = {lab.replace("\n", " "): {"lead_hours": v, "tested_by": dlab}
                   for lab, v, dlab in rows}

    # Round 3, R4 (S3, ruling V6): the figure plots EVERY pre-registered rule Appendix E lists
    # (results/appendix_g_rules.json), not the eight it was first drawn over, plus M-16's annotation, a bar of the
    # original set that is not a rule of its own. Appendix E's lead time is the one plotted; for the rules the
    # eight-row record covers it must equal that record's, and for the others it is recomputed here from the same two
    # commits (the rule's ledger heading, the artifact that discharged it) and must agree.
    AG = json.load(open(os.path.join(R.RESULTS, "appendix_g_rules.json")))
    rec_by_lab = {r["rule"]: r for r in resolved}

    def ct(h):
        return int(subprocess.run(["git", "show", "-s", "--format=%ct", h], capture_output=True, text=True,
                                  cwd=here).stdout.strip())

    def first_add(path):
        out = subprocess.run(["git", "log", "--diff-filter=A", "--format=%h", "--abbrev=7", "--", path],
                             capture_output=True, text=True, cwd=here).stdout.split()
        return out[-1] if out else None

    # The history rewrite (ledger M-48): every commit from the one that introduced the correspondence transcript to
    # the force-push got a new identifier. The introducing commit was P001 (M-48), M-45's data commit; the commit
    # that re-pointed this figure after the purge records that it became the commit with that row's data subject, and
    # the purge's last rewritten commit is that commit's parent. A cited commit inside the window does not keep the
    # identifier it had when first cited.
    import make_anon_bundle as _AB
    assert _AB.PREPURGE_COMMITS[0].startswith("P001")
    _repoint = resolve("C110", "Figure 4 resolves its commits by subject, because two hashes moved")
    _w0 = ct(rec_by_lab["M-45 within-trajectory control"]["data_commit"])
    _w1 = ct(_repoint + "^")
    rewritten = lambda h: _w0 <= ct(h) <= _w1

    bars = []
    for r in AG["rules"]:
        lab = next((k for k in rec_by_lab if k.split(" ")[0] == r["id"]), None)
        if r["id"] == "S-12":
            lab = "Task 3 duplication rule"
        if lab is not None:
            v = next(vv for kk, vv, _ in rows if kk.replace("\n", " ") == lab)
            assert abs(v - float(r["lead_hours"])) < 1e-9, (r["id"], v, r["lead_hours"])
            rc, dc = rec_by_lab[lab]["rule_commit"], rec_by_lab[lab]["data_commit"]
            tested = rec_by_lab[lab]["tested_by"]
        else:
            rc, dc = r["rule_commit"], first_add(r["tested_by"])
            v = (ct(dc) - ct(rc)) / 3600.0
            assert abs(v - float(r["lead_hours"])) < 1e-9, (r["id"], v, r["lead_hours"])
            tested = os.path.splitext(os.path.basename(r["tested_by"]))[0]
        bars.append({"id": r["id"], "label": r["id"] + (" (withdrawn)" if r["id"] == "S-12" else ""),
                     "lead_hours": v, "tested_by": tested, "rule_commit": rc, "data_commit": dc})
        if r["id"] == "M-16":                     # the annotation, kept beside its rule
            a = rec_by_lab["flip pattern interpretation"]
            av = next(vv for kk, vv, _ in rows if kk.startswith("flip pattern"))
            bars.append({"id": "M-16 annotation", "label": "M-16 annotation", "lead_hours": av,
                         "tested_by": a["tested_by"], "rule_commit": a["rule_commit"], "data_commit": a["data_commit"]})
    assert len(bars) == AG["n_rules"] + 1
    for b in bars:
        b["rewritten_by_purge"] = [h for h in (b["rule_commit"], b["data_commit"]) if rewritten(h)]
    cited = sorted({h for b in bars for h in (b["rule_commit"], b["data_commit"])})
    moved = sorted({h for b in bars for h in b["rewritten_by_purge"]})
    rec["fig1_bars"] = bars
    rec["fig1_commits"] = {"cited": cited, "rewritten_by_purge": moved, "window_ct": [_w0, _w1],
                           "method": "a cited commit is rewritten if its committer time lies between the rewritten "
                                     "counterpart of the commit that introduced the transcript (M-48: P001, M-45's "
                                     "data commit) and the parent of the commit that re-pointed this figure after "
                                     "the purge"}

    fig, ax = plt.subplots(figsize=(7.8, 0.27 * len(bars) + 1.2))
    vals = [b["lead_hours"] for b in bars]
    cols = ["#2ca02c" if v > 0 else "#d62728" for v in vals]
    y = np.arange(len(bars))
    ax.barh(y, vals, color=cols, height=0.6)
    ax.axvline(0, color="k", lw=1.2)
    ax.set_yticks(y); ax.set_yticklabels([b["label"] for b in bars], fontsize=7)
    ax.invert_yaxis()
    # Lead times run from minutes to days, so the axis is symmetric-logarithmic beyond one hour; every bar's exact
    # value is printed beside it.
    ax.set_xscale("symlog", linthresh=1.0)

    def fmt(v):
        # sub-hour leads are real and must not render as "+0.0 h"
        return f"{v*60:+.0f} min" if abs(v) < 1 else f"{v:+.1f} h"
    for i, b in enumerate(bars):
        v = b["lead_hours"]
        x = v * 1.15 + 0.1 if v > 0 else 0.15
        ax.text(x, i, f"{fmt(v)}  ({b['tested_by']})", va="center", ha="left", fontsize=6.3)
    ax.set(xlabel="hours the rule preceded the data it tested  (symmetric log scale; negative = written afterwards)",
           title="Pre-registration lead time for every pre-registered rule, from git")
    ax.set_xlim(min(vals) * 1.6, max(vals) * 60)
    ax.text(0.99, 0.02, "green: rule in git before the data existed\n"
                        "red: rule written once the answer was known (S-12)",
            transform=ax.transAxes, ha="right", fontsize=6.3, color="#555555")
    fig.tight_layout()
    p = os.path.join(R.FIGURES, "paper_fig4_prereg_timeline.png")
    fig.savefig(p); plt.close(fig)
    return p


def fig5_three_way(rec):
    """The contamination arms, both resampling units."""
    d = J("task3_three_way.json"); S = d["_summary"]
    pairs = [("duplicated_minus_clean", "duplicated\n− clean"),
             ("contaminated_minus_clean", "contaminated\n− clean"),
             ("contaminated_minus_duplicated", "contaminated\n− duplicated")]
    fig, ax = plt.subplots(1, 2, figsize=(8.4, 3.2))
    w = 0.35
    for j, unit in enumerate(("naive", "cluster")):
        hurt = [S[p][unit]["hurt"] for p, _ in pairs]
        help_ = [S[p][unit]["helped"] for p, _ in pairs]
        none = [S[p][unit]["no_effect"] for p, _ in pairs]
        x = np.arange(len(pairs)) + (j - 0.5) * w
        ax[0].bar(x, hurt, w, color="#d62728", label="hurt" if j == 0 else None)
        ax[0].bar(x, help_, w, bottom=hurt, color="#2ca02c", label="helped" if j == 0 else None)
        ax[0].bar(x, none, w, bottom=np.array(hurt) + np.array(help_), color="#dddddd",
                  label="no effect" if j == 0 else None)
    ax[0].set_xticks(np.arange(len(pairs)))
    ax[0].set_xticklabels([l for _, l in pairs], fontsize=7)
    ax[0].set(ylabel="cells (of 32)", title="(a) three-way outcome\nleft bar naive, right bar cluster")
    # Headroom above the bars for a one-row legend. Inside the bars' range it sat on the
    # grey "no effect" bar, which hid that entry's own grey swatch (round 2, T8;
    # docs/DEFERRED.md, session 28). The ticks stop at the bars' height.
    _top = max(S[p][unit]["hurt"] + S[p][unit]["helped"] + S[p][unit]["no_effect"]
               for p, _ in pairs for unit in ("naive", "cluster"))
    ax[0].set_ylim(0, _top * 1.3)
    ax[0].set_yticks(np.arange(0, _top + 1, 5))
    ax[0].legend(fontsize=7, ncol=3, loc="upper center")
    u = J("review_bootstrap_unit.json")
    cells = {k: v for k, v in u.items() if k != "_summary"}
    ratios = [v["width_ratio_cluster_over_naive"] for v in cells.values()]
    _n, _, _ = ax[1].hist(ratios, bins=10, color="#1f77b4", alpha=0.85)
    ax[1].axvline(1.0, color="k", ls="--", lw=1)
    ax[1].axvline(float(np.mean(ratios)), color="#d62728", lw=1.4,
                  label=f"mean {np.mean(ratios):.2f}×")
    ax[1].set(xlabel="CI width, cluster ÷ naive", ylabel="cells",
              title=f"(b) the wrong unit narrows\n{sum(1 for r in ratios if r > 1)} of {len(ratios)} intervals")
    # Headroom, so the legend clears the tallest bar it used to sit on (same entry).
    ax[1].set_ylim(0, _n.max() * 1.25)
    ax[1].legend(fontsize=7, loc="upper right")
    rec["fig5"] = {"summary": S, "width_ratio_mean": float(np.mean(ratios))}
    fig.tight_layout()
    p = os.path.join(R.FIGURES, "paper_fig5_three_way.png")
    fig.savefig(p); plt.close(fig)
    return p


def main():
    rec = {}
    made = [fig1_calibration(rec), fig2_sigma_profile(rec), fig3_collapse(rec),
            fig4_timeline(rec), fig5_three_way(rec), fig6_ab_by_horizon(rec)]
    op = os.path.join(R.RESULTS, "paper_figures.json")
    json.dump(rec, open(op, "w"), indent=2)
    print("PAPER FIGURES")
    print("=" * 70)
    for p in made:
        print(f"  wrote {R.rel(p)}")
    print(f"  wrote {R.rel(op)}  (the values each panel plots)")


if __name__ == "__main__":
    main()
